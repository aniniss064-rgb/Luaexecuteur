import { t as __commonJSMin } from "../_runtime.mjs";
//#region node_modules/fengari-web/dist/fengari-web.bundle.js
var require_fengari_web_bundle = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = function(t) {
		var e = {};
		function n(r) {
			if (e[r]) return e[r].exports;
			var a = e[r] = {
				i: r,
				l: !1,
				exports: {}
			};
			return t[r].call(a.exports, a, a.exports, n), a.l = !0, a.exports;
		}
		return n.m = t, n.c = e, n.d = function(t, e, r) {
			n.o(t, e) || Object.defineProperty(t, e, {
				enumerable: !0,
				get: r
			});
		}, n.r = function(t) {
			"undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(t, "__esModule", { value: !0 });
		}, n.t = function(t, e) {
			if (1 & e && (t = n(t)), 8 & e) return t;
			if (4 & e && "object" == typeof t && t && t.__esModule) return t;
			var r = Object.create(null);
			if (n.r(r), Object.defineProperty(r, "default", {
				enumerable: !0,
				value: t
			}), 2 & e && "string" != typeof t) for (var a in t) n.d(r, a, function(e) {
				return t[e];
			}.bind(null, a));
			return r;
		}, n.n = function(t) {
			var e = t && t.__esModule ? function() {
				return t.default;
			} : function() {
				return t;
			};
			return n.d(e, "a", e), e;
		}, n.o = function(t, e) {
			return Object.prototype.hasOwnProperty.call(t, e);
		}, n.p = "", n(n.s = 34);
	}([
		function(t, e, n) {
			"use strict";
			/**
			@license MIT
			
			Copyright © 2017-2018 Benoit Giannangeli
			Copyright © 2017-2018 Daurnimator
			Copyright © 1994–2017 Lua.org, PUC-Rio.
			*/ const r = n(5);
			t.exports.FENGARI_AUTHORS = r.FENGARI_AUTHORS, t.exports.FENGARI_COPYRIGHT = r.FENGARI_COPYRIGHT, t.exports.FENGARI_RELEASE = r.FENGARI_RELEASE, t.exports.FENGARI_VERSION = r.FENGARI_VERSION, t.exports.FENGARI_VERSION_MAJOR = r.FENGARI_VERSION_MAJOR, t.exports.FENGARI_VERSION_MINOR = r.FENGARI_VERSION_MINOR, t.exports.FENGARI_VERSION_NUM = r.FENGARI_VERSION_NUM, t.exports.FENGARI_VERSION_RELEASE = r.FENGARI_VERSION_RELEASE, t.exports.luastring_eq = r.luastring_eq, t.exports.luastring_indexOf = r.luastring_indexOf, t.exports.luastring_of = r.luastring_of, t.exports.to_jsstring = r.to_jsstring, t.exports.to_luastring = r.to_luastring, t.exports.to_uristring = r.to_uristring;
			const a = n(3), u = n(2), l = n(7), s = n(17);
			t.exports.luaconf = a, t.exports.lua = u, t.exports.lauxlib = l, t.exports.lualib = s;
		},
		function(t, e, n) {
			"use strict";
			let r, a, u;
			if (r = "function" == typeof Uint8Array.from ? Uint8Array.from.bind(Uint8Array) : function(t) {
				let e = 0, n = t.length, r = new Uint8Array(n);
				for (; n > e;) r[e] = t[e++];
				return r;
			}, "function" == typeof (/* @__PURE__ */ new Uint8Array()).indexOf) a = function(t, e, n) {
				return t.indexOf(e, n);
			};
			else {
				let t = [].indexOf;
				if (0 !== t.call(/* @__PURE__ */ new Uint8Array(1), 0)) throw Error("missing .indexOf");
				a = function(e, n, r) {
					return t.call(e, n, r);
				};
			}
			u = "function" == typeof Uint8Array.of ? Uint8Array.of.bind(Uint8Array) : function() {
				return r(arguments);
			};
			const l = function(t) {
				return t instanceof Uint8Array;
			}, s = "cannot convert invalid utf8 to javascript string", o = ";,/?:@&=+$abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,-_.!~*'()#".split("").reduce(function(t, e) {
				return t[e.charCodeAt(0)] = !0, t;
			}, {}), i = {}, c = function(t, e) {
				if ("string" != typeof t) throw new TypeError("to_luastring expects a javascript string");
				if (e) {
					let e = i[t];
					if (l(e)) return e;
				}
				let n = t.length, a = Array(n), u = 0;
				for (let e = 0; e < n; ++e) {
					let r = t.charCodeAt(e);
					if (r <= 127) a[u++] = r;
					else if (r <= 2047) a[u++] = 192 | r >> 6, a[u++] = 128 | 63 & r;
					else {
						if (r >= 55296 && r <= 56319 && e + 1 < n) {
							let n = t.charCodeAt(e + 1);
							n >= 56320 && n <= 57343 && (e++, r = 1024 * (r - 55296) + n + 9216);
						}
						r <= 65535 ? (a[u++] = 224 | r >> 12, a[u++] = 128 | r >> 6 & 63, a[u++] = 128 | 63 & r) : (a[u++] = 240 | r >> 18, a[u++] = 128 | r >> 12 & 63, a[u++] = 128 | r >> 6 & 63, a[u++] = 128 | 63 & r);
					}
				}
				return a = r(a), e && (i[t] = a), a;
			};
			t.exports.luastring_from = r, t.exports.luastring_indexOf = a, t.exports.luastring_of = u, t.exports.is_luastring = l, t.exports.luastring_eq = function(t, e) {
				if (t !== e) {
					let n = t.length;
					if (n !== e.length) return !1;
					for (let r = 0; r < n; r++) if (t[r] !== e[r]) return !1;
				}
				return !0;
			}, t.exports.to_jsstring = function(t, e, n, r) {
				if (!l(t)) throw new TypeError("to_jsstring expects a Uint8Array");
				n = void 0 === n ? t.length : Math.min(t.length, n);
				let a = "";
				for (let u = void 0 !== e ? e : 0; u < n;) {
					let e = t[u++];
					if (e < 128) a += String.fromCharCode(e);
					else if (e < 194 || e > 244) {
						if (!r) throw RangeError(s);
						a += "�";
					} else if (e <= 223) {
						if (u >= n) {
							if (!r) throw RangeError(s);
							a += "�";
							continue;
						}
						let l = t[u++];
						if (128 != (192 & l)) {
							if (!r) throw RangeError(s);
							a += "�";
							continue;
						}
						a += String.fromCharCode(((31 & e) << 6) + (63 & l));
					} else if (e <= 239) {
						if (u + 1 >= n) {
							if (!r) throw RangeError(s);
							a += "�";
							continue;
						}
						let l = t[u++];
						if (128 != (192 & l)) {
							if (!r) throw RangeError(s);
							a += "�";
							continue;
						}
						let o = t[u++];
						if (128 != (192 & o)) {
							if (!r) throw RangeError(s);
							a += "�";
							continue;
						}
						let i = ((15 & e) << 12) + ((63 & l) << 6) + (63 & o);
						if (i <= 65535) a += String.fromCharCode(i);
						else {
							let t = 55296 + ((i -= 65536) >> 10), e = i % 1024 + 56320;
							a += String.fromCharCode(t, e);
						}
					} else {
						if (u + 2 >= n) {
							if (!r) throw RangeError(s);
							a += "�";
							continue;
						}
						let l = t[u++];
						if (128 != (192 & l)) {
							if (!r) throw RangeError(s);
							a += "�";
							continue;
						}
						let o = t[u++];
						if (128 != (192 & o)) {
							if (!r) throw RangeError(s);
							a += "�";
							continue;
						}
						let i = t[u++];
						if (128 != (192 & i)) {
							if (!r) throw RangeError(s);
							a += "�";
							continue;
						}
						let c = ((7 & e) << 18) + ((63 & l) << 12) + ((63 & o) << 6) + (63 & i), _ = 55296 + ((c -= 65536) >> 10), f = c % 1024 + 56320;
						a += String.fromCharCode(_, f);
					}
				}
				return a;
			}, t.exports.to_uristring = function(t) {
				if (!l(t)) throw new TypeError("to_uristring expects a Uint8Array");
				let e = "";
				for (let n = 0; n < t.length; n++) {
					let r = t[n];
					o[r] ? e += String.fromCharCode(r) : e += "%" + (r < 16 ? "0" : "") + r.toString(16);
				}
				return e;
			}, t.exports.to_luastring = c, t.exports.from_userstring = function(t) {
				if (!l(t)) {
					if ("string" != typeof t) throw new TypeError("expects an array of bytes or javascript string");
					t = c(t);
				}
				return t;
			};
			const _ = c("\x1BLua");
			t.exports.LUA_SIGNATURE = _, t.exports.LUA_VERSION_MAJOR = "5", t.exports.LUA_VERSION_MINOR = "3", t.exports.LUA_VERSION_NUM = 503, t.exports.LUA_VERSION_RELEASE = "4", t.exports.LUA_VERSION = "Lua 5.3", t.exports.LUA_RELEASE = "Lua 5.3.4", t.exports.LUA_COPYRIGHT = "Lua 5.3.4  Copyright (C) 1994-2017 Lua.org, PUC-Rio", t.exports.LUA_AUTHORS = "R. Ierusalimschy, L. H. de Figueiredo, W. Celes";
			const f = {
				LUA_TNONE: -1,
				LUA_TNIL: 0,
				LUA_TBOOLEAN: 1,
				LUA_TLIGHTUSERDATA: 2,
				LUA_TNUMBER: 3,
				LUA_TSTRING: 4,
				LUA_TTABLE: 5,
				LUA_TFUNCTION: 6,
				LUA_TUSERDATA: 7,
				LUA_TTHREAD: 8,
				LUA_NUMTAGS: 9
			};
			f.LUA_TSHRSTR = 0 | f.LUA_TSTRING, f.LUA_TLNGSTR = 16 | f.LUA_TSTRING, f.LUA_TNUMFLT = 0 | f.LUA_TNUMBER, f.LUA_TNUMINT = 16 | f.LUA_TNUMBER, f.LUA_TLCL = 0 | f.LUA_TFUNCTION, f.LUA_TLCF = 16 | f.LUA_TFUNCTION, f.LUA_TCCL = 32 | f.LUA_TFUNCTION;
			const { LUAI_MAXSTACK: p } = n(3), L = -p - 1e3;
			t.exports.LUA_HOOKCALL = 0, t.exports.LUA_HOOKCOUNT = 3, t.exports.LUA_HOOKLINE = 2, t.exports.LUA_HOOKRET = 1, t.exports.LUA_HOOKTAILCALL = 4, t.exports.LUA_MASKCALL = 1, t.exports.LUA_MASKCOUNT = 8, t.exports.LUA_MASKLINE = 4, t.exports.LUA_MASKRET = 2, t.exports.LUA_MINSTACK = 20, t.exports.LUA_MULTRET = -1, t.exports.LUA_OPADD = 0, t.exports.LUA_OPBAND = 7, t.exports.LUA_OPBNOT = 13, t.exports.LUA_OPBOR = 8, t.exports.LUA_OPBXOR = 9, t.exports.LUA_OPDIV = 5, t.exports.LUA_OPEQ = 0, t.exports.LUA_OPIDIV = 6, t.exports.LUA_OPLE = 2, t.exports.LUA_OPLT = 1, t.exports.LUA_OPMOD = 3, t.exports.LUA_OPMUL = 2, t.exports.LUA_OPPOW = 4, t.exports.LUA_OPSHL = 10, t.exports.LUA_OPSHR = 11, t.exports.LUA_OPSUB = 1, t.exports.LUA_OPUNM = 12, t.exports.LUA_REGISTRYINDEX = L, t.exports.LUA_RIDX_GLOBALS = 2, t.exports.LUA_RIDX_LAST = 2, t.exports.LUA_RIDX_MAINTHREAD = 1, t.exports.constant_types = f, t.exports.lua_Debug = class {
				constructor() {
					this.event = NaN, this.name = null, this.namewhat = null, this.what = null, this.source = null, this.currentline = NaN, this.linedefined = NaN, this.lastlinedefined = NaN, this.nups = NaN, this.nparams = NaN, this.isvararg = NaN, this.istailcall = NaN, this.short_src = null, this.i_ci = null;
				}
			}, t.exports.lua_upvalueindex = function(t) {
				return L - t;
			}, t.exports.thread_status = {
				LUA_OK: 0,
				LUA_YIELD: 1,
				LUA_ERRRUN: 2,
				LUA_ERRSYNTAX: 3,
				LUA_ERRMEM: 4,
				LUA_ERRGCMM: 5,
				LUA_ERRERR: 6
			};
		},
		function(t, e, n) {
			"use strict";
			const r = n(1), a = n(18), u = n(11), l = n(8), s = n(12);
			t.exports.LUA_AUTHORS = r.LUA_AUTHORS, t.exports.LUA_COPYRIGHT = r.LUA_COPYRIGHT, t.exports.LUA_ERRERR = r.thread_status.LUA_ERRERR, t.exports.LUA_ERRGCMM = r.thread_status.LUA_ERRGCMM, t.exports.LUA_ERRMEM = r.thread_status.LUA_ERRMEM, t.exports.LUA_ERRRUN = r.thread_status.LUA_ERRRUN, t.exports.LUA_ERRSYNTAX = r.thread_status.LUA_ERRSYNTAX, t.exports.LUA_HOOKCALL = r.LUA_HOOKCALL, t.exports.LUA_HOOKCOUNT = r.LUA_HOOKCOUNT, t.exports.LUA_HOOKLINE = r.LUA_HOOKLINE, t.exports.LUA_HOOKRET = r.LUA_HOOKRET, t.exports.LUA_HOOKTAILCALL = r.LUA_HOOKTAILCALL, t.exports.LUA_MASKCALL = r.LUA_MASKCALL, t.exports.LUA_MASKCOUNT = r.LUA_MASKCOUNT, t.exports.LUA_MASKLINE = r.LUA_MASKLINE, t.exports.LUA_MASKRET = r.LUA_MASKRET, t.exports.LUA_MINSTACK = r.LUA_MINSTACK, t.exports.LUA_MULTRET = r.LUA_MULTRET, t.exports.LUA_NUMTAGS = r.constant_types.LUA_NUMTAGS, t.exports.LUA_OK = r.thread_status.LUA_OK, t.exports.LUA_OPADD = r.LUA_OPADD, t.exports.LUA_OPBAND = r.LUA_OPBAND, t.exports.LUA_OPBNOT = r.LUA_OPBNOT, t.exports.LUA_OPBOR = r.LUA_OPBOR, t.exports.LUA_OPBXOR = r.LUA_OPBXOR, t.exports.LUA_OPDIV = r.LUA_OPDIV, t.exports.LUA_OPEQ = r.LUA_OPEQ, t.exports.LUA_OPIDIV = r.LUA_OPIDIV, t.exports.LUA_OPLE = r.LUA_OPLE, t.exports.LUA_OPLT = r.LUA_OPLT, t.exports.LUA_OPMOD = r.LUA_OPMOD, t.exports.LUA_OPMUL = r.LUA_OPMUL, t.exports.LUA_OPPOW = r.LUA_OPPOW, t.exports.LUA_OPSHL = r.LUA_OPSHL, t.exports.LUA_OPSHR = r.LUA_OPSHR, t.exports.LUA_OPSUB = r.LUA_OPSUB, t.exports.LUA_OPUNM = r.LUA_OPUNM, t.exports.LUA_REGISTRYINDEX = r.LUA_REGISTRYINDEX, t.exports.LUA_RELEASE = r.LUA_RELEASE, t.exports.LUA_RIDX_GLOBALS = r.LUA_RIDX_GLOBALS, t.exports.LUA_RIDX_LAST = r.LUA_RIDX_LAST, t.exports.LUA_RIDX_MAINTHREAD = r.LUA_RIDX_MAINTHREAD, t.exports.LUA_SIGNATURE = r.LUA_SIGNATURE, t.exports.LUA_TNONE = r.constant_types.LUA_TNONE, t.exports.LUA_TNIL = r.constant_types.LUA_TNIL, t.exports.LUA_TBOOLEAN = r.constant_types.LUA_TBOOLEAN, t.exports.LUA_TLIGHTUSERDATA = r.constant_types.LUA_TLIGHTUSERDATA, t.exports.LUA_TNUMBER = r.constant_types.LUA_TNUMBER, t.exports.LUA_TSTRING = r.constant_types.LUA_TSTRING, t.exports.LUA_TTABLE = r.constant_types.LUA_TTABLE, t.exports.LUA_TFUNCTION = r.constant_types.LUA_TFUNCTION, t.exports.LUA_TUSERDATA = r.constant_types.LUA_TUSERDATA, t.exports.LUA_TTHREAD = r.constant_types.LUA_TTHREAD, t.exports.LUA_VERSION = r.LUA_VERSION, t.exports.LUA_VERSION_MAJOR = r.LUA_VERSION_MAJOR, t.exports.LUA_VERSION_MINOR = r.LUA_VERSION_MINOR, t.exports.LUA_VERSION_NUM = r.LUA_VERSION_NUM, t.exports.LUA_VERSION_RELEASE = r.LUA_VERSION_RELEASE, t.exports.LUA_YIELD = r.thread_status.LUA_YIELD, t.exports.lua_Debug = r.lua_Debug, t.exports.lua_upvalueindex = r.lua_upvalueindex, t.exports.lua_absindex = a.lua_absindex, t.exports.lua_arith = a.lua_arith, t.exports.lua_atpanic = a.lua_atpanic, t.exports.lua_atnativeerror = a.lua_atnativeerror, t.exports.lua_call = a.lua_call, t.exports.lua_callk = a.lua_callk, t.exports.lua_checkstack = a.lua_checkstack, t.exports.lua_close = s.lua_close, t.exports.lua_compare = a.lua_compare, t.exports.lua_concat = a.lua_concat, t.exports.lua_copy = a.lua_copy, t.exports.lua_createtable = a.lua_createtable, t.exports.lua_dump = a.lua_dump, t.exports.lua_error = a.lua_error, t.exports.lua_gc = a.lua_gc, t.exports.lua_getallocf = a.lua_getallocf, t.exports.lua_getextraspace = a.lua_getextraspace, t.exports.lua_getfield = a.lua_getfield, t.exports.lua_getglobal = a.lua_getglobal, t.exports.lua_gethook = u.lua_gethook, t.exports.lua_gethookcount = u.lua_gethookcount, t.exports.lua_gethookmask = u.lua_gethookmask, t.exports.lua_geti = a.lua_geti, t.exports.lua_getinfo = u.lua_getinfo, t.exports.lua_getlocal = u.lua_getlocal, t.exports.lua_getmetatable = a.lua_getmetatable, t.exports.lua_getstack = u.lua_getstack, t.exports.lua_gettable = a.lua_gettable, t.exports.lua_gettop = a.lua_gettop, t.exports.lua_getupvalue = a.lua_getupvalue, t.exports.lua_getuservalue = a.lua_getuservalue, t.exports.lua_insert = a.lua_insert, t.exports.lua_isboolean = a.lua_isboolean, t.exports.lua_iscfunction = a.lua_iscfunction, t.exports.lua_isfunction = a.lua_isfunction, t.exports.lua_isinteger = a.lua_isinteger, t.exports.lua_islightuserdata = a.lua_islightuserdata, t.exports.lua_isnil = a.lua_isnil, t.exports.lua_isnone = a.lua_isnone, t.exports.lua_isnoneornil = a.lua_isnoneornil, t.exports.lua_isnumber = a.lua_isnumber, t.exports.lua_isproxy = a.lua_isproxy, t.exports.lua_isstring = a.lua_isstring, t.exports.lua_istable = a.lua_istable, t.exports.lua_isthread = a.lua_isthread, t.exports.lua_isuserdata = a.lua_isuserdata, t.exports.lua_isyieldable = l.lua_isyieldable, t.exports.lua_len = a.lua_len, t.exports.lua_load = a.lua_load, t.exports.lua_newstate = s.lua_newstate, t.exports.lua_newtable = a.lua_newtable, t.exports.lua_newthread = s.lua_newthread, t.exports.lua_newuserdata = a.lua_newuserdata, t.exports.lua_next = a.lua_next, t.exports.lua_pcall = a.lua_pcall, t.exports.lua_pcallk = a.lua_pcallk, t.exports.lua_pop = a.lua_pop, t.exports.lua_pushboolean = a.lua_pushboolean, t.exports.lua_pushcclosure = a.lua_pushcclosure, t.exports.lua_pushcfunction = a.lua_pushcfunction, t.exports.lua_pushfstring = a.lua_pushfstring, t.exports.lua_pushglobaltable = a.lua_pushglobaltable, t.exports.lua_pushinteger = a.lua_pushinteger, t.exports.lua_pushjsclosure = a.lua_pushjsclosure, t.exports.lua_pushjsfunction = a.lua_pushjsfunction, t.exports.lua_pushlightuserdata = a.lua_pushlightuserdata, t.exports.lua_pushliteral = a.lua_pushliteral, t.exports.lua_pushlstring = a.lua_pushlstring, t.exports.lua_pushnil = a.lua_pushnil, t.exports.lua_pushnumber = a.lua_pushnumber, t.exports.lua_pushstring = a.lua_pushstring, t.exports.lua_pushthread = a.lua_pushthread, t.exports.lua_pushvalue = a.lua_pushvalue, t.exports.lua_pushvfstring = a.lua_pushvfstring, t.exports.lua_rawequal = a.lua_rawequal, t.exports.lua_rawget = a.lua_rawget, t.exports.lua_rawgeti = a.lua_rawgeti, t.exports.lua_rawgetp = a.lua_rawgetp, t.exports.lua_rawlen = a.lua_rawlen, t.exports.lua_rawset = a.lua_rawset, t.exports.lua_rawseti = a.lua_rawseti, t.exports.lua_rawsetp = a.lua_rawsetp, t.exports.lua_register = a.lua_register, t.exports.lua_remove = a.lua_remove, t.exports.lua_replace = a.lua_replace, t.exports.lua_resume = l.lua_resume, t.exports.lua_rotate = a.lua_rotate, t.exports.lua_setallof = l.lua_setallof, t.exports.lua_setfield = a.lua_setfield, t.exports.lua_setglobal = a.lua_setglobal, t.exports.lua_sethook = u.lua_sethook, t.exports.lua_seti = a.lua_seti, t.exports.lua_setlocal = u.lua_setlocal, t.exports.lua_setmetatable = a.lua_setmetatable, t.exports.lua_settable = a.lua_settable, t.exports.lua_settop = a.lua_settop, t.exports.lua_setupvalue = a.lua_setupvalue, t.exports.lua_setuservalue = a.lua_setuservalue, t.exports.lua_status = a.lua_status, t.exports.lua_stringtonumber = a.lua_stringtonumber, t.exports.lua_toboolean = a.lua_toboolean, t.exports.lua_todataview = a.lua_todataview, t.exports.lua_tointeger = a.lua_tointeger, t.exports.lua_tointegerx = a.lua_tointegerx, t.exports.lua_tojsstring = a.lua_tojsstring, t.exports.lua_tolstring = a.lua_tolstring, t.exports.lua_tonumber = a.lua_tonumber, t.exports.lua_tonumberx = a.lua_tonumberx, t.exports.lua_topointer = a.lua_topointer, t.exports.lua_toproxy = a.lua_toproxy, t.exports.lua_tostring = a.lua_tostring, t.exports.lua_tothread = a.lua_tothread, t.exports.lua_touserdata = a.lua_touserdata, t.exports.lua_type = a.lua_type, t.exports.lua_typename = a.lua_typename, t.exports.lua_upvalueid = a.lua_upvalueid, t.exports.lua_upvaluejoin = a.lua_upvaluejoin, t.exports.lua_version = a.lua_version, t.exports.lua_xmove = a.lua_xmove, t.exports.lua_yield = l.lua_yield, t.exports.lua_yieldk = l.lua_yieldk, t.exports.lua_tocfunction = a.lua_tocfunction;
		},
		function(t, e, n) {
			"use strict";
			const r = {}, { LUA_VERSION_MAJOR: a, LUA_VERSION_MINOR: u, to_luastring: l } = n(1);
			t.exports.LUA_PATH_SEP = ";";
			t.exports.LUA_PATH_MARK = "?";
			t.exports.LUA_EXEC_DIR = "!";
			const s = a + "." + u;
			t.exports.LUA_VDIR = s;
			{
				const e = "/";
				t.exports.LUA_DIRSEP = e;
				const n = "./lua/" + s + "/";
				t.exports.LUA_LDIR = n;
				const r = n;
				t.exports.LUA_JSDIR = r;
				const a = l(n + "?.lua;" + n + "?/init.lua;./?.lua;./?/init.lua");
				t.exports.LUA_PATH_DEFAULT = a;
				const u = l(r + "?.js;" + r + "loadall.js;./?.js");
				t.exports.LUA_JSPATH_DEFAULT = u;
			}
			const o = r.LUA_COMPAT_FLOATSTRING || !1, i = r.LUAI_MAXSTACK || 1e6, c = r.LUA_IDSIZE || 59, _ = r.LUAL_BUFFERSIZE || 8192, f = function(t, e) {
				for (var n = Math.min(3, Math.ceil(Math.abs(e) / 1023)), r = t, a = 0; a < n; a++) r *= Math.pow(2, Math.floor((e + a) / n));
				return r;
			};
			t.exports.LUAI_MAXSTACK = i, t.exports.LUA_COMPAT_FLOATSTRING = o, t.exports.LUA_IDSIZE = c, t.exports.LUA_INTEGER_FMT = "%d", t.exports.LUA_INTEGER_FRMLEN = "", t.exports.LUA_MAXINTEGER = 2147483647, t.exports.LUA_MININTEGER = -2147483648, t.exports.LUA_NUMBER_FMT = "%.14g", t.exports.LUA_NUMBER_FRMLEN = "", t.exports.LUAL_BUFFERSIZE = _, t.exports.frexp = function(t) {
				if (0 === t) return [t, 0];
				var e = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
				e.setFloat64(0, t);
				var n = e.getUint32(0) >>> 20 & 2047;
				0 === n && (e.setFloat64(0, t * Math.pow(2, 64)), n = (e.getUint32(0) >>> 20 & 2047) - 64);
				var r = n - 1022;
				return [f(t, -r), r];
			}, t.exports.ldexp = f, t.exports.lua_getlocaledecpoint = function() {
				return 46;
			}, t.exports.lua_integer2str = function(t) {
				return String(t);
			}, t.exports.lua_number2str = function(t) {
				return String(Number(t.toPrecision(14)));
			}, t.exports.lua_numbertointeger = function(t) {
				return t >= -2147483648 && t < 2147483648 && t;
			}, t.exports.luai_apicheck = function(t, e) {
				if (!e) throw Error(e);
			};
		},
		function(t, e, n) {
			"use strict";
			const { luai_apicheck: r } = n(3), a = function(t) {
				if (!t) throw Error("assertion failed");
			};
			t.exports.lua_assert = a, t.exports.luai_apicheck = r || function(t, e) {
				return a(e);
			};
			t.exports.api_check = function(t, e, n) {
				return r(t, e && n);
			};
			t.exports.LUAI_MAXCCALLS = 200;
			t.exports.LUA_MINBUFFER = 32;
			t.exports.luai_nummod = function(t, e, n) {
				let r = e % n;
				return r * n < 0 && (r += n), r;
			};
			t.exports.MAX_INT = 2147483647;
			t.exports.MIN_INT = -2147483648;
		},
		function(t, e, n) {
			const r = n(1), a = "Fengari 0.1.4  Copyright (C) 2017-2018 B. Giannangeli, Daurnimator\nBased on: " + r.LUA_COPYRIGHT;
			t.exports.FENGARI_AUTHORS = "B. Giannangeli, Daurnimator", t.exports.FENGARI_COPYRIGHT = a, t.exports.FENGARI_RELEASE = "Fengari 0.1.4", t.exports.FENGARI_VERSION = "Fengari 0.1", t.exports.FENGARI_VERSION_MAJOR = "0", t.exports.FENGARI_VERSION_MINOR = "1", t.exports.FENGARI_VERSION_NUM = 1, t.exports.FENGARI_VERSION_RELEASE = "4", t.exports.is_luastring = r.is_luastring, t.exports.luastring_eq = r.luastring_eq, t.exports.luastring_from = r.luastring_from, t.exports.luastring_indexOf = r.luastring_indexOf, t.exports.luastring_of = r.luastring_of, t.exports.to_jsstring = r.to_jsstring, t.exports.to_luastring = r.to_luastring, t.exports.to_uristring = r.to_uristring, t.exports.from_userstring = r.from_userstring;
		},
		function(t, e, n) {
			"use strict";
			const { LUA_OPADD: r, LUA_OPBAND: a, LUA_OPBNOT: u, LUA_OPBOR: l, LUA_OPBXOR: s, LUA_OPDIV: o, LUA_OPIDIV: i, LUA_OPMOD: c, LUA_OPMUL: _, LUA_OPPOW: f, LUA_OPSHL: p, LUA_OPSHR: L, LUA_OPSUB: h, LUA_OPUNM: d, constant_types: { LUA_NUMTAGS: A, LUA_TBOOLEAN: g, LUA_TCCL: T, LUA_TFUNCTION: x, LUA_TLCF: b, LUA_TLCL: O, LUA_TLIGHTUSERDATA: k, LUA_TLNGSTR: v, LUA_TNIL: E, LUA_TNUMBER: U, LUA_TNUMFLT: m, LUA_TNUMINT: N, LUA_TSHRSTR: R, LUA_TSTRING: S, LUA_TTABLE: w, LUA_TTHREAD: I, LUA_TUSERDATA: y }, from_userstring: M, luastring_indexOf: P, luastring_of: C, to_jsstring: D, to_luastring: V } = n(1), { lisdigit: B, lisprint: G, lisspace: K, lisxdigit: F } = n(22), j = n(11), H = n(8), X = n(12), { luaS_bless: z, luaS_new: Y } = n(10), J = n(9), { LUA_COMPAT_FLOATSTRING: Z, ldexp: q, lua_integer2str: W, lua_number2str: Q } = n(3), $ = n(15), { MAX_INT: tt, luai_nummod: et, lua_assert: nt } = n(4), rt = n(14), at = A, ut = A + 1;
			class lt {
				constructor(t, e) {
					this.type = t, this.value = e;
				}
				ttype() {
					return 63 & this.type;
				}
				ttnov() {
					return 15 & this.type;
				}
				checktag(t) {
					return this.type === t;
				}
				checktype(t) {
					return this.ttnov() === t;
				}
				ttisnumber() {
					return this.checktype(U);
				}
				ttisfloat() {
					return this.checktag(m);
				}
				ttisinteger() {
					return this.checktag(N);
				}
				ttisnil() {
					return this.checktag(E);
				}
				ttisboolean() {
					return this.checktag(g);
				}
				ttislightuserdata() {
					return this.checktag(k);
				}
				ttisstring() {
					return this.checktype(S);
				}
				ttisshrstring() {
					return this.checktag(R);
				}
				ttislngstring() {
					return this.checktag(v);
				}
				ttistable() {
					return this.checktag(w);
				}
				ttisfunction() {
					return this.checktype(x);
				}
				ttisclosure() {
					return (31 & this.type) === x;
				}
				ttisCclosure() {
					return this.checktag(T);
				}
				ttisLclosure() {
					return this.checktag(O);
				}
				ttislcf() {
					return this.checktag(b);
				}
				ttisfulluserdata() {
					return this.checktag(y);
				}
				ttisthread() {
					return this.checktag(I);
				}
				ttisdeadkey() {
					return this.checktag(ut);
				}
				l_isfalse() {
					return this.ttisnil() || this.ttisboolean() && !1 === this.value;
				}
				setfltvalue(t) {
					this.type = m, this.value = t;
				}
				chgfltvalue(t) {
					nt(this.type == m), this.value = t;
				}
				setivalue(t) {
					this.type = N, this.value = t;
				}
				chgivalue(t) {
					nt(this.type == N), this.value = t;
				}
				setnilvalue() {
					this.type = E, this.value = null;
				}
				setfvalue(t) {
					this.type = b, this.value = t;
				}
				setpvalue(t) {
					this.type = k, this.value = t;
				}
				setbvalue(t) {
					this.type = g, this.value = t;
				}
				setsvalue(t) {
					this.type = v, this.value = t;
				}
				setuvalue(t) {
					this.type = y, this.value = t;
				}
				setthvalue(t) {
					this.type = I, this.value = t;
				}
				setclLvalue(t) {
					this.type = O, this.value = t;
				}
				setclCvalue(t) {
					this.type = T, this.value = t;
				}
				sethvalue(t) {
					this.type = w, this.value = t;
				}
				setdeadvalue() {
					this.type = ut, this.value = null;
				}
				setfrom(t) {
					this.type = t.type, this.value = t.value;
				}
				tsvalue() {
					return nt(this.ttisstring()), this.value;
				}
				svalue() {
					return this.tsvalue().getstr();
				}
				vslen() {
					return this.tsvalue().tsslen();
				}
				jsstring(t, e) {
					return D(this.svalue(), t, e, !0);
				}
			}
			const st = function(t, e, n) {
				t.stack[e].setsvalue(n);
			}, ot = new lt(E, null);
			Object.freeze(ot), t.exports.luaO_nilobject = ot;
			class it {
				constructor(t, e) {
					this.id = t.l_G.id_counter++, this.p = null, this.nupvalues = e, this.upvals = new Array(e);
				}
			}
			class ct {
				constructor(t, e, n) {
					for (this.id = t.l_G.id_counter++, this.f = e, this.nupvalues = n, this.upvalue = new Array(n); n--;) this.upvalue[n] = new lt(E, null);
				}
			}
			class _t {
				constructor(t, e) {
					this.id = t.l_G.id_counter++, this.metatable = null, this.uservalue = new lt(E, null), this.len = e, this.data = Object.create(null);
				}
			}
			const ft = V("..."), pt = V("[string \""), Lt = V("\"]"), ht = function(t) {
				return B(t) ? t - 48 : (223 & t) - 55;
			}, dt = function(t, e) {
				let n = 1;
				if (nt(e <= 1114111), e < 128) t[7] = e;
				else {
					let r = 63;
					do
						t[8 - n++] = 128 | 63 & e, e >>= 6, r >>= 1;
					while (e > r);
					t[8 - n] = ~r << 1 | e;
				}
				return n;
			}, At = function(t, e) {
				let n = "x" === e ? function(t) {
					let e, n = 0, r = 0, a = 0, u = 0, l = 0, s = !1;
					for (; K(t[n]);) n++;
					if ((e = 45 === t[n]) ? n++ : 43 === t[n] && n++, 48 !== t[n] || 120 !== t[n + 1] && 88 !== t[n + 1]) return null;
					for (n += 2;; n++) if (46 === t[n]) {
						if (s) break;
						s = !0;
					} else {
						if (!F(t[n])) break;
						0 === a && 48 === t[n] ? u++ : ++a <= 30 ? r = 16 * r + ht(t[n]) : l++, s && l--;
					}
					if (u + a === 0) return null;
					if (l *= 4, 112 === t[n] || 80 === t[n]) {
						let e, r = 0;
						if ((e = 45 === t[++n]) ? n++ : 43 === t[n] && n++, !B(t[n])) return null;
						for (; B(t[n]);) r = 10 * r + t[n++] - 48;
						e && (r = -r), l += r;
					}
					return e && (r = -r), {
						n: q(r, l),
						i: n
					};
				}(t) : function(t) {
					try {
						t = D(t);
					} catch (t) {
						return null;
					}
					let e = /^[\t\v\f \n\r]*[+-]?(?:[0-9]+\.?[0-9]*|\.[0-9]*)(?:[eE][+-]?[0-9]+)?/.exec(t);
					if (!e) return null;
					let n = parseFloat(e[0]);
					return isNaN(n) ? null : {
						n,
						i: e[0].length
					};
				}(t);
				if (null === n) return null;
				for (; K(t[n.i]);) n.i++;
				return n.i === t.length || 0 === t[n.i] ? n : null;
			}, gt = [
				46,
				120,
				88,
				110,
				78
			], Tt = {
				46: ".",
				120: "x",
				88: "x",
				110: "n",
				78: "n"
			}, xt = Math.floor(tt / 10), bt = tt % 10, Ot = function(t, e) {
				let n;
				if (e.ttisinteger()) n = V(W(e.value));
				else {
					let t = Q(e.value);
					!Z && /^[-0123456789]+$/.test(t) && (t += ".0"), n = V(t);
				}
				e.setsvalue(z(t, n));
			}, kt = function(t, e) {
				H.luaD_inctop(t), st(t, t.top - 1, Y(t, e));
			}, vt = function(t, e, n) {
				let r, a = 0, u = 0, l = 0;
				for (; -1 != (r = P(e, 37, u));) {
					switch (kt(t, e.subarray(u, r)), e[r + 1]) {
						case 115: {
							let e = n[l++];
							if (null === e) e = V("(null)", !0);
							else {
								e = M(e);
								let t = P(e, 0);
								-1 !== t && (e = e.subarray(0, t));
							}
							kt(t, e);
							break;
						}
						case 99: {
							let e = n[l++];
							G(e) ? kt(t, C(e)) : Et(t, V("<\\%d>", !0), e);
							break;
						}
						case 100:
						case 73:
							H.luaD_inctop(t), t.stack[t.top - 1].setivalue(n[l++]), Ot(t, t.stack[t.top - 1]);
							break;
						case 102:
							H.luaD_inctop(t), t.stack[t.top - 1].setfltvalue(n[l++]), Ot(t, t.stack[t.top - 1]);
							break;
						case 112: {
							let e = n[l++];
							if (e instanceof X.lua_State || e instanceof J.Table || e instanceof _t || e instanceof it || e instanceof ct) kt(t, V("0x" + e.id.toString(16)));
							else switch (typeof e) {
								case "undefined":
									kt(t, V("undefined"));
									break;
								case "number":
									kt(t, V("Number(" + e + ")"));
									break;
								case "string":
									kt(t, V("String(" + JSON.stringify(e) + ")"));
									break;
								case "boolean":
									kt(t, V(e ? "Boolean(true)" : "Boolean(false)"));
									break;
								case "object": if (null === e) {
									kt(t, V("null"));
									break;
								}
								case "function": {
									let n = t.l_G.ids.get(e);
									n || (n = t.l_G.id_counter++, t.l_G.ids.set(e, n)), kt(t, V("0x" + n.toString(16)));
									break;
								}
								default: kt(t, V("<id NYI>"));
							}
							break;
						}
						case 85: {
							let e = /* @__PURE__ */ new Uint8Array(8), r = dt(e, n[l++]);
							kt(t, e.subarray(8 - r));
							break;
						}
						case 37:
							kt(t, V("%", !0));
							break;
						default: j.luaG_runerror(t, V("invalid option '%%%c' to 'lua_pushfstring'"), e[r + 1]);
					}
					a += 2, u = r + 2;
				}
				return H.luaD_checkstack(t, 1), kt(t, e.subarray(u)), a > 0 && $.luaV_concat(t, a + 1), t.stack[t.top - 1].svalue();
			}, Et = function(t, e, ...n) {
				return vt(t, e, n);
			}, Ut = function(t, e, n, o) {
				switch (e) {
					case r: return n + o | 0;
					case h: return n - o | 0;
					case _: return $.luaV_imul(n, o);
					case c: return $.luaV_mod(t, n, o);
					case i: return $.luaV_div(t, n, o);
					case a: return n & o;
					case l: return n | o;
					case s: return n ^ o;
					case p: return $.luaV_shiftl(n, o);
					case L: return $.luaV_shiftl(n, -o);
					case d: return 0 - n | 0;
					case u: return -1 ^ n;
					default: nt(0);
				}
			}, mt = function(t, e, n, a) {
				switch (e) {
					case r: return n + a;
					case h: return n - a;
					case _: return n * a;
					case o: return n / a;
					case f: return Math.pow(n, a);
					case i: return Math.floor(n / a);
					case d: return -n;
					case c: return et(t, n, a);
					default: nt(0);
				}
			};
			t.exports.CClosure = ct, t.exports.LClosure = it, t.exports.LUA_TDEADKEY = ut, t.exports.LUA_TPROTO = at, t.exports.LocVar = class {
				constructor() {
					this.varname = null, this.startpc = NaN, this.endpc = NaN;
				}
			}, t.exports.TValue = lt, t.exports.Udata = _t, t.exports.UTF8BUFFSZ = 8, t.exports.luaO_arith = function(t, e, n, i, c) {
				let _ = "number" == typeof c ? t.stack[c] : c;
				switch (e) {
					case a:
					case l:
					case s:
					case p:
					case L:
					case u: {
						let r, a;
						if (!1 !== (r = $.tointeger(n)) && !1 !== (a = $.tointeger(i))) return void _.setivalue(Ut(t, e, r, a));
						break;
					}
					case o:
					case f: {
						let r, a;
						if (!1 !== (r = $.tonumber(n)) && !1 !== (a = $.tonumber(i))) return void _.setfltvalue(mt(t, e, r, a));
						break;
					}
					default: {
						let r, a;
						if (n.ttisinteger() && i.ttisinteger()) return void _.setivalue(Ut(t, e, n.value, i.value));
						if (!1 !== (r = $.tonumber(n)) && !1 !== (a = $.tonumber(i))) return void _.setfltvalue(mt(t, e, r, a));
						break;
					}
				}
				nt(null !== t), rt.luaT_trybinTM(t, n, i, c, e - r + rt.TMS.TM_ADD);
			}, t.exports.luaO_chunkid = function(t, e) {
				let n, r = t.length;
				if (61 === t[0]) r < e ? (n = new Uint8Array(r - 1)).set(t.subarray(1)) : (n = new Uint8Array(e)).set(t.subarray(1, e + 1));
				else if (64 === t[0]) r <= e ? (n = new Uint8Array(r - 1)).set(t.subarray(1)) : ((n = new Uint8Array(e)).set(ft), e -= ft.length, n.set(t.subarray(r - e), ft.length));
				else {
					n = new Uint8Array(e);
					let a = P(t, 10);
					n.set(pt);
					let u = pt.length;
					r < (e -= pt.length + ft.length + Lt.length) && -1 === a ? (n.set(t, u), u += t.length) : (-1 !== a && (r = a), r > e && (r = e), n.set(t.subarray(0, r), u), u += r, n.set(ft, u), u += ft.length), n.set(Lt, u), u += Lt.length, n = n.subarray(0, u);
				}
				return n;
			}, t.exports.luaO_hexavalue = ht, t.exports.luaO_int2fb = function(t) {
				let e = 0;
				if (t < 8) return t;
				for (; t >= 128;) t = t + 15 >> 4, e += 4;
				for (; t >= 16;) t = t + 1 >> 1, e++;
				return e + 1 << 3 | t - 8;
			}, t.exports.luaO_pushfstring = Et, t.exports.luaO_pushvfstring = vt, t.exports.luaO_str2num = function(t, e) {
				let n = function(t) {
					let e, n = 0, r = 0, a = !0;
					for (; K(t[n]);) n++;
					if ((e = 45 === t[n]) ? n++ : 43 === t[n] && n++, 48 !== t[n] || 120 !== t[n + 1] && 88 !== t[n + 1]) for (; n < t.length && B(t[n]); n++) {
						let u = t[n] - 48;
						if (r >= xt && (r > xt || u > bt + e)) return null;
						r = 10 * r + u | 0, a = !1;
					}
					else for (n += 2; n < t.length && F(t[n]); n++) r = 16 * r + ht(t[n]) | 0, a = !1;
					for (; n < t.length && K(t[n]);) n++;
					return a || n !== t.length && 0 !== t[n] ? null : {
						n: 0 | (e ? -r : r),
						i: n
					};
				}(t);
				return null !== n ? (e.setivalue(n.n), n.i + 1) : null !== (n = function(t) {
					let e = t.length, n = 0;
					for (let r = 0; r < e; r++) {
						let e = t[r];
						if (-1 !== gt.indexOf(e)) {
							n = e;
							break;
						}
					}
					let r = Tt[n];
					return "n" === r ? null : At(t, r);
				}(t)) ? (e.setfltvalue(n.n), n.i + 1) : 0;
			}, t.exports.luaO_tostring = Ot, t.exports.luaO_utf8esc = dt, t.exports.numarith = mt, t.exports.pushobj2s = function(t, e) {
				t.stack[t.top++] = new lt(e.type, e.value);
			}, t.exports.pushsvalue2s = function(t, e) {
				t.stack[t.top++] = new lt(v, e);
			}, t.exports.setobjs2s = function(t, e, n) {
				t.stack[e].setfrom(t.stack[n]);
			}, t.exports.setobj2s = function(t, e, n) {
				t.stack[e].setfrom(n);
			}, t.exports.setsvalue2s = st;
		},
		function(t, e, n) {
			"use strict";
			const { LUAL_BUFFERSIZE: r } = n(3), { LUA_ERRERR: a, LUA_MULTRET: u, LUA_REGISTRYINDEX: l, LUA_SIGNATURE: s, LUA_TBOOLEAN: o, LUA_TLIGHTUSERDATA: i, LUA_TNIL: c, LUA_TNONE: _, LUA_TNUMBER: f, LUA_TSTRING: p, LUA_TTABLE: L, LUA_VERSION_NUM: h, lua_Debug: d, lua_absindex: A, lua_atpanic: g, lua_call: T, lua_checkstack: x, lua_concat: b, lua_copy: O, lua_createtable: k, lua_error: v, lua_getfield: E, lua_getinfo: U, lua_getmetatable: m, lua_getstack: N, lua_gettop: R, lua_insert: S, lua_isinteger: w, lua_isnil: I, lua_isnumber: y, lua_isstring: M, lua_istable: P, lua_len: C, lua_load: D, lua_newstate: V, lua_newtable: B, lua_next: G, lua_pcall: K, lua_pop: F, lua_pushboolean: j, lua_pushcclosure: H, lua_pushcfunction: X, lua_pushfstring: z, lua_pushinteger: Y, lua_pushliteral: J, lua_pushlstring: Z, lua_pushnil: q, lua_pushstring: W, lua_pushvalue: Q, lua_pushvfstring: $, lua_rawequal: tt, lua_rawget: et, lua_rawgeti: nt, lua_rawlen: rt, lua_rawseti: at, lua_remove: ut, lua_setfield: lt, lua_setglobal: st, lua_setmetatable: ot, lua_settop: it, lua_toboolean: ct, lua_tointeger: _t, lua_tointegerx: ft, lua_tojsstring: pt, lua_tolstring: Lt, lua_tonumber: ht, lua_tonumberx: dt, lua_topointer: At, lua_tostring: gt, lua_touserdata: Tt, lua_type: xt, lua_typename: bt, lua_version: Ot } = n(2), { from_userstring: kt, luastring_eq: vt, to_luastring: Et, to_uristring: Ut } = n(5), mt = a + 1, Nt = Et("_LOADED"), Rt = Et("_PRELOAD"), St = Et("FILE*"), wt = Et("__name"), It = Et("__tostring"), yt = /* @__PURE__ */ new Uint8Array(0);
			class Mt {
				constructor() {
					this.L = null, this.b = yt, this.n = 0;
				}
			}
			const Pt = function(t, e, n) {
				if (0 === n || !P(t, -1)) return 0;
				for (q(t); G(t, -2);) {
					if (xt(t, -2) === p) {
						if (tt(t, e, -1)) return F(t, 1), 1;
						if (Pt(t, e, n - 1)) return ut(t, -2), J(t, "."), S(t, -2), b(t, 3), 1;
					}
					F(t, 1);
				}
				return 0;
			}, Ct = function(t, e) {
				let n = R(t);
				if (U(t, Et("f"), e), E(t, l, Nt), Pt(t, n + 1, 2)) {
					let e = gt(t, -1);
					return 95 === e[0] && 71 === e[1] && 46 === e[2] && (W(t, e.subarray(3)), ut(t, -2)), O(t, -1, n + 1), F(t, 2), 1;
				}
				return it(t, n), 0;
			}, Dt = function(t, e) {
				Ct(t, e) ? (z(t, Et("function '%s'"), gt(t, -1)), ut(t, -2)) : 0 !== e.namewhat.length ? z(t, Et("%s '%s'"), e.namewhat, e.name) : e.what && 109 === e.what[0] ? J(t, "main chunk") : e.what && 76 === e.what[0] ? z(t, Et("function <%s:%d>"), e.short_src, e.linedefined) : J(t, "?");
			}, Vt = function(t) {
				let e = "PANIC: unprotected error in call to Lua API (" + pt(t, -1) + ")";
				throw new Error(e);
			}, Bt = function(t, e, n) {
				let r = new d();
				return N(t, 0, r) ? (U(t, Et("n"), r), vt(r.namewhat, Et("method")) && 0 === --e ? Ft(t, Et("calling '%s' on bad self (%s)"), r.name, n) : (null === r.name && (r.name = Ct(t, r) ? gt(t, -1) : Et("?")), Ft(t, Et("bad argument #%d to '%s' (%s)"), e, r.name, n))) : Ft(t, Et("bad argument #%d (%s)"), e, n);
			}, Gt = function(t, e, n) {
				let r;
				r = _e(t, e, wt) === p ? gt(t, -1) : xt(t, e) === i ? Et("light userdata", !0) : Yt(t, e);
				let a = z(t, Et("%s expected, got %s"), n, r);
				return Bt(t, e, a);
			}, Kt = function(t, e) {
				let n = new d();
				N(t, e, n) && (U(t, Et("Sl", !0), n), n.currentline > 0) ? z(t, Et("%s:%d: "), n.short_src, n.currentline) : W(t, Et(""));
			}, Ft = function(t, e, ...n) {
				return Kt(t, 1), $(t, e, n), b(t, 2), v(t);
			}, jt = function(t, e, n, r) {
				if (e) return j(t, 1), 1;
				{
					let e, a;
					return q(t), r ? (e = r.message, a = -r.errno) : (e = "Success", a = 0), n ? z(t, Et("%s: %s"), n, Et(e)) : W(t, Et(e)), Y(t, a), 3;
				}
			}, Ht = function(t, e) {
				return E(t, l, e);
			}, Xt = function(t, e, n) {
				let r = Tt(t, e);
				return null !== r && m(t, e) ? (Ht(t, n), tt(t, -1, -2) || (r = null), F(t, 2), r) : null;
			}, zt = function(t, e, n) {
				Gt(t, e, bt(t, n));
			}, Yt = function(t, e) {
				return bt(t, xt(t, e));
			}, Jt = function(t, e) {
				let n = Lt(t, e);
				return null !== n && void 0 !== n || zt(t, e, p), n;
			}, Zt = Jt, qt = function(t, e, n) {
				return xt(t, e) <= 0 ? null === n ? null : kt(n) : Jt(t, e);
			}, Wt = qt, Qt = function(t, e) {
				let n = dt(t, e);
				return !1 === n && zt(t, e, f), n;
			}, $t = function(t, e) {
				let n = ft(t, e);
				return !1 === n && function(t, e) {
					y(t, e) ? Bt(t, e, Et("number has no integer representation", !0)) : zt(t, e, f);
				}(t, e), n;
			}, te = function(t, e) {
				let n = t.n + e;
				if (t.b.length < n) {
					let e = Math.max(2 * t.b.length, n), r = new Uint8Array(e);
					r.set(t.b), t.b = r;
				}
				return t.b.subarray(t.n, n);
			}, ee = function(t, e) {
				e.L = t, e.b = yt;
			}, ne = function(t, e, n) {
				if (n > 0) e = kt(e), te(t, n).set(e.subarray(0, n)), ue(t, n);
			}, re = function(t, e) {
				e = kt(e), ne(t, e, e.length);
			}, ae = function(t) {
				Z(t.L, t.b, t.n), t.n = 0, t.b = yt;
			}, ue = function(t, e) {
				t.n += e;
			}, le = function(t, e, n, r) {
				return xt(t, n) <= 0 ? r : e(t, n);
			}, se = function(t, e) {
				let n = e.string;
				return e.string = null, n;
			}, oe = function(t, e, n, r, a) {
				return D(t, se, { string: e }, r, a);
			}, ie = function(t, e, n, r) {
				return oe(t, e, 0, r, null);
			}, ce = function(t, e) {
				return ie(t, e, e.length, e);
			}, _e = function(t, e, n) {
				if (m(t, e)) {
					W(t, n);
					let e = et(t, -2);
					return e === c ? F(t, 2) : ut(t, -2), e;
				}
				return c;
			}, fe = function(t, e, n) {
				return e = A(t, e), _e(t, e, n) !== c && (Q(t, e), T(t, 1, 1), !0);
			}, pe = Et("%I"), Le = Et("%f"), he = function(t, e, n) {
				var r = n >>> 0, a = e.length, u = t.length + 1 - a;
				t: for (; r < u; r++) {
					for (let n = 0; n < a; n++) if (t[r + n] !== e[n]) continue t;
					return r;
				}
				return -1;
			}, de = function(t, e, n) {
				return E(t, e, n) === L || (F(t, 1), e = A(t, e), B(t), Q(t, -1), lt(t, e, n), !1);
			}, Ae = function(t, e, n) {
				ge(t, n, Et("too many upvalues", !0));
				for (let r in e) {
					for (let e = 0; e < n; e++) Q(t, -n);
					H(t, e[r], n), lt(t, -(n + 2), Et(r));
				}
				F(t, n);
			}, ge = function(t, e, n) {
				x(t, e) || (n ? Ft(t, Et("stack overflow (%s)"), n) : Ft(t, Et("stack overflow", !0)));
			}, Te = function(t, e, n, r) {
				let a = r.message, u = gt(t, n).subarray(1);
				return z(t, Et("cannot %s %s: %s"), Et(e), u, Et(a)), ut(t, n), mt;
			};
			let xe;
			const be = [
				239,
				187,
				191
			], Oe = function(t) {
				let e = function(t) {
					let e;
					t.n = 0;
					let n = 0;
					do {
						if (null === (e = xe(t)) || e !== be[n]) return e;
						n++, t.buff[t.n++] = e;
					} while (n < be.length);
					return t.n = 0, xe(t);
				}(t);
				if (35 === e) {
					do
						e = xe(t);
					while (e && 10 !== e);
					return {
						skipped: !0,
						c: xe(t)
					};
				}
				return {
					skipped: !1,
					c: e
				};
			};
			let ke;
			{
				class t {
					constructor() {
						this.n = NaN, this.f = null, this.buff = /* @__PURE__ */ new Uint8Array(1024), this.pos = 0, this.err = void 0;
					}
				}
				const e = function(t, e) {
					let n = e;
					if (null !== n.f && n.n > 0) {
						let t = n.n;
						return n.n = 0, n.f = n.f.subarray(n.pos), n.buff.subarray(0, t);
					}
					let r = n.f;
					return n.f = null, r;
				};
				xe = function(t) {
					return t.pos < t.f.length ? t.f[t.pos++] : null;
				}, ke = function(n, r, a) {
					let u = new t(), l = R(n) + 1;
					if (null === r) throw new Error("Can't read stdin in the browser");
					{
						z(n, Et("@%s"), r);
						let t = Ut(r), e = new XMLHttpRequest();
						if (e.open("GET", t, !1), "undefined" == typeof window && (e.responseType = "arraybuffer"), e.send(), !(e.status >= 200 && e.status <= 299)) return u.err = e.status, Te(n, "open", l, { message: `${e.status}: ${e.statusText}` });
						"string" == typeof e.response ? u.f = Et(e.response) : u.f = new Uint8Array(e.response);
					}
					let o = Oe(u);
					o.c === s[0] && r || o.skipped && (u.buff[u.n++] = 10), null !== o.c && (u.buff[u.n++] = o.c);
					let i = D(n, e, u, gt(n, -1), a), c = u.err;
					return c ? (it(n, l), Te(n, "read", l, c)) : (ut(n, l), i);
				};
			}
			const ve = function(t, e) {
				return ke(t, e, null);
			}, Ee = function(t, e, n) {
				let r = Ot(t);
				72 != n && Ft(t, Et("core and library have incompatible numeric types")), r != Ot(null) ? Ft(t, Et("multiple Lua VMs detected")) : r !== e && Ft(t, Et("version mismatch: app. needs %f, Lua core provides %f"), e, r);
			};
			t.exports.LUA_ERRFILE = mt, t.exports.LUA_FILEHANDLE = St, t.exports.LUA_LOADED_TABLE = Nt, t.exports.LUA_NOREF = -2, t.exports.LUA_PRELOAD_TABLE = Rt, t.exports.LUA_REFNIL = -1, t.exports.luaL_Buffer = Mt, t.exports.luaL_addchar = function(t, e) {
				te(t, 1), t.b[t.n++] = e;
			}, t.exports.luaL_addlstring = ne, t.exports.luaL_addsize = ue, t.exports.luaL_addstring = re, t.exports.luaL_addvalue = function(t) {
				let e = t.L, n = gt(e, -1);
				ne(t, n, n.length), F(e, 1);
			}, t.exports.luaL_argcheck = function(t, e, n, r) {
				e || Bt(t, n, r);
			}, t.exports.luaL_argerror = Bt, t.exports.luaL_buffinit = ee, t.exports.luaL_buffinitsize = function(t, e, n) {
				return ee(t, e), te(e, n);
			}, t.exports.luaL_callmeta = fe, t.exports.luaL_checkany = function(t, e) {
				xt(t, e) === _ && Bt(t, e, Et("value expected", !0));
			}, t.exports.luaL_checkinteger = $t, t.exports.luaL_checklstring = Jt, t.exports.luaL_checknumber = Qt, t.exports.luaL_checkoption = function(t, e, n, r) {
				let a = null !== n ? Wt(t, e, n) : Zt(t, e);
				for (let t = 0; r[t]; t++) if (vt(r[t], a)) return t;
				return Bt(t, e, z(t, Et("invalid option '%s'"), a));
			}, t.exports.luaL_checkstack = ge, t.exports.luaL_checkstring = Zt, t.exports.luaL_checktype = function(t, e, n) {
				xt(t, e) !== n && zt(t, e, n);
			}, t.exports.luaL_checkudata = function(t, e, n) {
				let r = Xt(t, e, n);
				return null === r && Gt(t, e, n), r;
			}, t.exports.luaL_checkversion = function(t) {
				Ee(t, h, 72);
			}, t.exports.luaL_checkversion_ = Ee, t.exports.luaL_dofile = function(t, e) {
				return ve(t, e) || K(t, 0, u, 0);
			}, t.exports.luaL_dostring = function(t, e) {
				return ce(t, e) || K(t, 0, u, 0);
			}, t.exports.luaL_error = Ft, t.exports.luaL_execresult = function(t, e) {
				let n, r;
				if (null === e) return j(t, 1), J(t, "exit"), Y(t, 0), 3;
				if (e.status) n = "exit", r = e.status;
				else {
					if (!e.signal) return jt(t, 0, null, e);
					n = "signal", r = e.signal;
				}
				return q(t), J(t, n), Y(t, r), 3;
			}, t.exports.luaL_fileresult = jt, t.exports.luaL_getmetafield = _e, t.exports.luaL_getmetatable = Ht, t.exports.luaL_getsubtable = de, t.exports.luaL_gsub = function(t, e, n, r) {
				let a, u = new Mt();
				for (ee(t, u); (a = he(e, n)) >= 0;) ne(u, e, a), re(u, r), e = e.subarray(a + n.length);
				return re(u, e), ae(u), gt(t, -1);
			}, t.exports.luaL_len = function(t, e) {
				C(t, e);
				let n = ft(t, -1);
				return !1 === n && Ft(t, Et("object length is not an integer", !0)), F(t, 1), n;
			}, t.exports.luaL_loadbuffer = ie, t.exports.luaL_loadbufferx = oe, t.exports.luaL_loadfile = ve, t.exports.luaL_loadfilex = ke, t.exports.luaL_loadstring = ce, t.exports.luaL_newlib = function(t, e) {
				k(t), Ae(t, e, 0);
			}, t.exports.luaL_newlibtable = function(t) {
				k(t);
			}, t.exports.luaL_newmetatable = function(t, e) {
				return Ht(t, e) !== c ? 0 : (F(t, 1), k(t, 0, 2), W(t, e), lt(t, -2, wt), Q(t, -1), lt(t, l, e), 1);
			}, t.exports.luaL_newstate = function() {
				let t = V();
				return t && g(t, Vt), t;
			}, t.exports.luaL_opt = le, t.exports.luaL_optinteger = function(t, e, n) {
				return le(t, $t, e, n);
			}, t.exports.luaL_optlstring = qt, t.exports.luaL_optnumber = function(t, e, n) {
				return le(t, Qt, e, n);
			}, t.exports.luaL_optstring = Wt, t.exports.luaL_prepbuffer = function(t) {
				return te(t, r);
			}, t.exports.luaL_prepbuffsize = te, t.exports.luaL_pushresult = ae, t.exports.luaL_pushresultsize = function(t, e) {
				ue(t, e), ae(t);
			}, t.exports.luaL_ref = function(t, e) {
				let n;
				return I(t, -1) ? (F(t, 1), -1) : (e = A(t, e), nt(t, e, 0), n = _t(t, -1), F(t, 1), 0 !== n ? (nt(t, e, n), at(t, e, 0)) : n = rt(t, e) + 1, at(t, e, n), n);
			}, t.exports.luaL_requiref = function(t, e, n, r) {
				de(t, l, Nt), E(t, -1, e), ct(t, -1) || (F(t, 1), X(t, n), W(t, e), T(t, 1, 1), Q(t, -1), lt(t, -3, e)), ut(t, -2), r && (Q(t, -1), st(t, e));
			}, t.exports.luaL_setfuncs = Ae, t.exports.luaL_setmetatable = function(t, e) {
				Ht(t, e), ot(t, -2);
			}, t.exports.luaL_testudata = Xt, t.exports.luaL_tolstring = function(t, e) {
				if (fe(t, e, It)) M(t, -1) || Ft(t, Et("'__tostring' must return a string"));
				else switch (xt(t, e)) {
					case f:
						w(t, e) ? z(t, pe, _t(t, e)) : z(t, Le, ht(t, e));
						break;
					case p:
						Q(t, e);
						break;
					case o:
						J(t, ct(t, e) ? "true" : "false");
						break;
					case c:
						J(t, "nil");
						break;
					default: {
						let n = _e(t, e, wt), r = n === p ? gt(t, -1) : Yt(t, e);
						z(t, Et("%s: %p"), r, At(t, e)), n !== c && ut(t, -2);
						break;
					}
				}
				return Lt(t, -1);
			}, t.exports.luaL_traceback = function(t, e, n, r) {
				let a = new d(), u = R(t), l = function(t) {
					let e = new d(), n = 1, r = 1;
					for (; N(t, r, e);) n = r, r *= 2;
					for (; n < r;) {
						let a = Math.floor((n + r) / 2);
						N(t, a, e) ? n = a + 1 : r = a;
					}
					return r - 1;
				}(e), s = l - r > 21 ? 10 : -1;
				for (n && z(t, Et("%s\n"), n), ge(t, 10, null), J(t, "stack traceback:"); N(e, r++, a);) 0 == s-- ? (J(t, "\n	..."), r = l - 11 + 1) : (U(e, Et("Slnt", !0), a), z(t, Et("\n	%s:"), a.short_src), a.currentline > 0 && J(t, `${a.currentline}:`), J(t, " in "), Dt(t, a), a.istailcall && J(t, "\n	(...tail calls..)"), b(t, R(t) - u));
				b(t, R(t) - u);
			}, t.exports.luaL_typename = Yt, t.exports.luaL_unref = function(t, e, n) {
				n >= 0 && (e = A(t, e), nt(t, e, 0), at(t, e, n), Y(t, n), at(t, e, 0));
			}, t.exports.luaL_where = Kt, t.exports.lua_writestringerror = function() {
				for (let t = 0; t < arguments.length; t++) {
					let e = arguments[t];
					do {
						let t = /([^\n]*)\n?([\d\D]*)/.exec(e);
						console.error(t[1]), e = t[2];
					} while ("" !== e);
				}
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_HOOKCALL: r, LUA_HOOKRET: a, LUA_HOOKTAILCALL: u, LUA_MASKCALL: l, LUA_MASKLINE: s, LUA_MASKRET: o, LUA_MINSTACK: i, LUA_MULTRET: c, LUA_SIGNATURE: _, constant_types: { LUA_TCCL: f, LUA_TLCF: p, LUA_TLCL: L, LUA_TNIL: h }, thread_status: { LUA_ERRMEM: d, LUA_ERRERR: A, LUA_ERRRUN: g, LUA_ERRSYNTAX: T, LUA_OK: x, LUA_YIELD: b }, lua_Debug: O, luastring_indexOf: k, to_luastring: v } = n(1), E = n(18), U = n(11), m = n(13), { api_check: N, lua_assert: R, LUAI_MAXCCALLS: S } = n(4), w = n(6), I = n(16), y = n(23), M = n(12), { luaS_newliteral: P } = n(10), C = n(14), { LUAI_MAXSTACK: D } = n(3), V = n(36), B = n(15), { MBuffer: G } = n(19), K = function(t, e) {
				if (t.top < e) for (; t.top < e;) t.stack[t.top++] = new w.TValue(h, null);
				else for (; t.top > e;) delete t.stack[--t.top];
			}, F = function(t, e, n) {
				let r = t.top;
				for (; t.top < n + 1;) t.stack[t.top++] = new w.TValue(h, null);
				switch (e) {
					case d:
						w.setsvalue2s(t, n, P(t, "not enough memory"));
						break;
					case A:
						w.setsvalue2s(t, n, P(t, "error in error handling"));
						break;
					default: w.setobjs2s(t, n, r - 1);
				}
				for (; t.top > n + 1;) delete t.stack[--t.top];
			}, j = D + 200, H = function(t, e) {
				R(e <= D || e == j), R(t.stack_last == t.stack.length - M.EXTRA_STACK), t.stack.length = e, t.stack_last = e - M.EXTRA_STACK;
			}, X = function(t, e) {
				let n = t.stack.length;
				if (n > D) nt(t, A);
				else {
					let r = t.top + e + M.EXTRA_STACK, a = 2 * n;
					a > D && (a = D), a < r && (a = r), a > D ? (H(t, j), U.luaG_runerror(t, v("stack overflow", !0))) : H(t, a);
				}
			}, z = function(t, e) {
				t.stack_last - t.top <= e && X(t, e);
			}, Y = function(t) {
				let e = function(t) {
					let e = t.top;
					for (let n = t.ci; null !== n; n = n.previous) e < n.top && (e = n.top);
					return R(e <= t.stack_last), e + 1;
				}(t), n = e + Math.floor(e / 8) + 2 * M.EXTRA_STACK;
				n > D && (n = D), t.stack.length > D && M.luaE_freeCI(t), e <= D - M.EXTRA_STACK && n < t.stack.length && H(t, n);
			}, J = function(t, e, n) {
				let a = t.stack[e];
				switch (a.type) {
					case f:
					case p: {
						let u = a.type === f ? a.value.f : a.value;
						z(t, i);
						let s = M.luaE_extendCI(t);
						s.funcOff = e, s.nresults = n, s.func = a, s.top = t.top + i, R(s.top <= t.stack_last), s.callstatus = 0, t.hookmask & l && W(t, r, -1);
						let o = u(t);
						if ("number" != typeof o || o < 0 || (0 | o) !== o) throw Error("invalid return value from JS function (expected integer)");
						return E.api_checknelems(t, o), Z(t, s, t.top - o, o), !0;
					}
					case L: {
						let r, u = a.value.p, s = t.top - e - 1, o = u.maxstacksize;
						if (z(t, o), u.is_vararg) r = $(t, u, s);
						else {
							for (; s < u.numparams; s++) t.stack[t.top++] = new w.TValue(h, null);
							r = e + 1;
						}
						let i = M.luaE_extendCI(t);
						return i.funcOff = e, i.nresults = n, i.func = a, i.l_base = r, i.top = r + o, K(t, i.top), i.l_code = u.code, i.l_savedpc = 0, i.callstatus = M.CIST_LUA, t.hookmask & l && Q(t, i), !1;
					}
					default: return z(t, 1), tt(t, e, a), J(t, e, n);
				}
			}, Z = function(t, e, n, r) {
				let u = e.nresults;
				t.hookmask & (o | s) && (t.hookmask & o && W(t, a, -1), t.oldpc = e.previous.l_savedpc);
				let l = e.funcOff;
				return t.ci = e.previous, t.ci.next = null, q(t, n, l, r, u);
			}, q = function(t, e, n, r, a) {
				switch (a) {
					case 0: break;
					case 1:
						0 === r ? t.stack[n].setnilvalue() : w.setobjs2s(t, n, e);
						break;
					case c:
						for (let a = 0; a < r; a++) w.setobjs2s(t, n + a, e + a);
						for (let e = t.top; e >= n + r; e--) delete t.stack[e];
						return t.top = n + r, !1;
					default: {
						let u;
						if (a <= r) for (u = 0; u < a; u++) w.setobjs2s(t, n + u, e + u);
						else {
							for (u = 0; u < r; u++) w.setobjs2s(t, n + u, e + u);
							for (; u < a; u++) n + u >= t.top ? t.stack[n + u] = new w.TValue(h, null) : t.stack[n + u].setnilvalue();
						}
						break;
					}
				}
				let u = n + a;
				for (let e = t.top; e >= u; e--) delete t.stack[e];
				return t.top = u, !0;
			}, W = function(t, e, n) {
				let r = t.hook;
				if (r && t.allowhook) {
					let a = t.ci, u = t.top, l = a.top, s = new O();
					s.event = e, s.currentline = n, s.i_ci = a, z(t, i), a.top = t.top + i, R(a.top <= t.stack_last), t.allowhook = 0, a.callstatus |= M.CIST_HOOKED, r(t, s), R(!t.allowhook), t.allowhook = 1, a.top = l, K(t, u), a.callstatus &= ~M.CIST_HOOKED;
				}
			}, Q = function(t, e) {
				let n = r;
				e.l_savedpc++, e.previous.callstatus & M.CIST_LUA && e.previous.l_code[e.previous.l_savedpc - 1].opcode == I.OpCodesI.OP_TAILCALL && (e.callstatus |= M.CIST_TAIL, n = u), W(t, n, -1), e.l_savedpc--;
			}, $ = function(t, e, n) {
				let r, a = e.numparams, u = t.top - n, l = t.top;
				for (r = 0; r < a && r < n; r++) w.pushobj2s(t, t.stack[u + r]), t.stack[u + r].setnilvalue();
				for (; r < a; r++) t.stack[t.top++] = new w.TValue(h, null);
				return l;
			}, tt = function(t, e, n) {
				let r = C.luaT_gettmbyobj(t, n, C.TMS.TM_CALL);
				r.ttisfunction(r) || U.luaG_typeerror(t, n, v("call", !0)), w.pushobj2s(t, t.stack[t.top - 1]);
				for (let n = t.top - 2; n > e; n--) w.setobjs2s(t, n, n - 1);
				w.setobj2s(t, e, r);
			}, et = function(t, e, n) {
				++t.nCcalls >= S && function(t) {
					t.nCcalls === S ? U.luaG_runerror(t, v("JS stack overflow", !0)) : t.nCcalls >= S + (S >> 3) && nt(t, A);
				}(t), J(t, e, n) || B.luaV_execute(t), t.nCcalls--;
			}, nt = function(t, e) {
				if (t.errorJmp) throw t.errorJmp.status = e, t.errorJmp;
				{
					let n = t.l_G;
					if (t.status = e, !n.mainthread.errorJmp) {
						let r = n.panic;
						throw r && (F(t, e, t.top), t.ci.top < t.top && (t.ci.top = t.top), r(t)), /* @__PURE__ */ new Error(`Aborted ${e}`);
					}
					n.mainthread.stack[n.mainthread.top++] = t.stack[t.top - 1], nt(n.mainthread, e);
				}
			}, rt = function(t, e, n) {
				let r = t.nCcalls, a = {
					status: x,
					previous: t.errorJmp
				};
				t.errorJmp = a;
				try {
					e(t, n);
				} catch (e) {
					if (a.status === x) {
						let n = t.l_G.atnativeerror;
						if (n) try {
							if (a.status = x, E.lua_pushcfunction(t, n), E.lua_pushlightuserdata(t, e), _t(t, t.top - 2, 1), 0 !== t.errfunc) {
								let e = t.errfunc;
								w.pushobj2s(t, t.stack[t.top - 1]), w.setobjs2s(t, t.top - 2, e), _t(t, t.top - 2, 1);
							}
							a.status = g;
						} catch (t) {
							a.status === x && (a.status = -1);
						}
						else a.status = -1;
					}
				}
				return t.errorJmp = a.previous, t.nCcalls = r, a.status;
			}, at = function(t, e) {
				let n = t.ci;
				R(null !== n.c_k && 0 === t.nny), R(n.callstatus & M.CIST_YPCALL || e === b), n.callstatus & M.CIST_YPCALL && (n.callstatus &= ~M.CIST_YPCALL, t.errfunc = n.c_old_errfunc), n.nresults === c && t.ci.top < t.top && (t.ci.top = t.top);
				let r = (0, n.c_k)(t, e, n.c_ctx);
				E.api_checknelems(t, r), Z(t, n, t.top - r, r);
			}, ut = function(t, e) {
				for (null !== e && at(t, e); t.ci !== t.base_ci;) t.ci.callstatus & M.CIST_LUA ? (B.luaV_finishOp(t), B.luaV_execute(t)) : at(t, b);
			}, lt = function(t, e) {
				let n = function(t) {
					for (let e = t.ci; null !== e; e = e.previous) if (e.callstatus & M.CIST_YPCALL) return e;
					return null;
				}(t);
				if (null === n) return 0;
				let r = n.extra;
				return m.luaF_close(t, r), F(t, e, r), t.ci = n, t.allowhook = n.callstatus & M.CIST_OAH, t.nny = 0, Y(t), t.errfunc = n.c_old_errfunc, 1;
			}, st = function(t, e, n) {
				let r = P(t, e);
				if (0 === n) w.pushsvalue2s(t, r), N(t, t.top <= t.ci.top, "stack overflow");
				else {
					for (let e = 1; e < n; e++) delete t.stack[--t.top];
					w.setsvalue2s(t, t.top - 1, r);
				}
				return g;
			}, ot = function(t, e) {
				let n = t.top - e, r = t.ci;
				t.status === x ? J(t, n - 1, c) || B.luaV_execute(t) : (R(t.status === b), t.status = x, r.funcOff = r.extra, r.func = t.stack[r.funcOff], r.callstatus & M.CIST_LUA ? B.luaV_execute(t) : (null !== r.c_k && (e = r.c_k(t, b, r.c_ctx), E.api_checknelems(t, e), n = t.top - e), Z(t, r, n, e)), ut(t, null));
			}, it = function(t, e, n, r) {
				let a = t.ci;
				return E.api_checknelems(t, e), t.nny > 0 && (t !== t.l_G.mainthread ? U.luaG_runerror(t, v("attempt to yield across a JS-call boundary", !0)) : U.luaG_runerror(t, v("attempt to yield from outside a coroutine", !0))), t.status = b, a.extra = a.funcOff, a.callstatus & M.CIST_LUA ? N(t, null === r, "hooks cannot continue after yielding") : (a.c_k = r, null !== r && (a.c_ctx = n), a.funcOff = t.top - e - 1, a.func = t.stack[a.funcOff], nt(t, b)), R(a.callstatus & M.CIST_HOOKED), 0;
			}, ct = function(t, e, n, r, a) {
				let u = t.ci, l = t.allowhook, s = t.nny, o = t.errfunc;
				t.errfunc = a;
				let i = rt(t, e, n);
				return i !== x && (m.luaF_close(t, r), F(t, i, r), t.ci = u, t.allowhook = l, t.nny = s, Y(t)), t.errfunc = o, i;
			}, _t = function(t, e, n) {
				t.nny++, et(t, e, n), t.nny--;
			};
			const ft = function(t, e, n) {
				e && -1 === k(e, n[0]) && (w.luaO_pushfstring(t, v("attempt to load a %s chunk (mode is '%s')"), n, e), nt(t, T));
			}, pt = function(t, e) {
				let n, r = e.z.zgetc();
				r === _[0] ? (ft(t, e.mode, v("binary", !0)), n = V.luaU_undump(t, e.z, e.name)) : (ft(t, e.mode, v("text", !0)), n = y.luaY_parser(t, e.z, e.buff, e.dyd, e.name, r)), R(n.nupvalues === n.p.upvalues.length), m.luaF_initupvals(t, n);
			};
			t.exports.adjust_top = K, t.exports.luaD_call = et, t.exports.luaD_callnoyield = _t, t.exports.luaD_checkstack = z, t.exports.luaD_growstack = X, t.exports.luaD_hook = W, t.exports.luaD_inctop = function(t) {
				z(t, 1), t.stack[t.top++] = new w.TValue(h, null);
			}, t.exports.luaD_pcall = ct, t.exports.luaD_poscall = Z, t.exports.luaD_precall = J, t.exports.luaD_protectedparser = function(t, e, n, r) {
				let a = new class {
					constructor(t, e, n) {
						this.z = t, this.buff = new G(), this.dyd = new y.Dyndata(), this.mode = n, this.name = e;
					}
				}(e, n, r);
				t.nny++;
				let u = ct(t, pt, a, t.top, t.errfunc);
				return t.nny--, u;
			}, t.exports.luaD_rawrunprotected = rt, t.exports.luaD_reallocstack = H, t.exports.luaD_throw = nt, t.exports.lua_isyieldable = function(t) {
				return 0 === t.nny;
			}, t.exports.lua_resume = function(t, e, n) {
				let r = t.nny;
				if (t.status === x) {
					if (t.ci !== t.base_ci) return st(t, "cannot resume non-suspended coroutine", n);
				} else if (t.status !== b) return st(t, "cannot resume dead coroutine", n);
				if (t.nCcalls = e ? e.nCcalls + 1 : 1, t.nCcalls >= S) return st(t, "JS stack overflow", n);
				t.nny = 0, E.api_checknelems(t, t.status === x ? n + 1 : n);
				let a = rt(t, ot, n);
				if (-1 === a) a = g;
				else {
					for (; a > b && lt(t, a);) a = rt(t, ut, a);
					a > b ? (t.status = a, F(t, a, t.top), t.ci.top = t.top) : R(a === t.status);
				}
				return t.nny = r, t.nCcalls--, R(t.nCcalls === (e ? e.nCcalls : 0)), a;
			}, t.exports.lua_yield = function(t, e) {
				it(t, e, 0, null);
			}, t.exports.lua_yieldk = it;
		},
		function(t, e, n) {
			"use strict";
			const { constant_types: { LUA_TBOOLEAN: r, LUA_TCCL: a, LUA_TLCF: u, LUA_TLCL: l, LUA_TLIGHTUSERDATA: s, LUA_TLNGSTR: o, LUA_TNIL: i, LUA_TNUMFLT: c, LUA_TNUMINT: _, LUA_TSHRSTR: f, LUA_TTABLE: p, LUA_TTHREAD: L, LUA_TUSERDATA: h }, to_luastring: d } = n(1), { lua_assert: A } = n(4), g = n(11), T = n(6), { luaS_hashlongstr: x, TString: b } = n(10), O = n(12);
			let k = /* @__PURE__ */ new WeakMap();
			const v = function(t) {
				let e = k.get(t);
				return e || (e = {}, k.set(t, e)), e;
			}, E = function(t, e) {
				switch (e.type) {
					case i: return g.luaG_runerror(t, d("table index is nil", !0));
					case c: if (isNaN(e.value)) return g.luaG_runerror(t, d("table index is NaN", !0));
					case _:
					case r:
					case p:
					case l:
					case u:
					case a:
					case h:
					case L: return e.value;
					case f:
					case o: return x(e.tsvalue());
					case s: {
						let n = e.value;
						switch (typeof n) {
							case "string": return "*" + n;
							case "number": return "#" + n;
							case "boolean": return n ? "?true" : "?false";
							case "function": return v(n);
							case "object": if (n instanceof O.lua_State && n.l_G === t.l_G || n instanceof U || n instanceof T.Udata || n instanceof T.LClosure || n instanceof T.CClosure) return v(n);
							default: return n;
						}
					}
					default: throw new Error("unknown key type: " + e.type);
				}
			};
			class U {
				constructor(t) {
					this.id = t.l_G.id_counter++, this.strong = /* @__PURE__ */ new Map(), this.dead_strong = /* @__PURE__ */ new Map(), this.dead_weak = void 0, this.f = void 0, this.l = void 0, this.metatable = null, this.flags = -1;
				}
			}
			const m = function(t, e, n, r) {
				t.dead_strong.clear(), t.dead_weak = void 0;
				let a = null, u = {
					key: n,
					value: r,
					p: a = t.l,
					n: void 0
				};
				t.f || (t.f = u), a && (a.n = u), t.strong.set(e, u), t.l = u;
			}, N = function(t, e) {
				let n = t.strong.get(e);
				if (n) {
					n.key.setdeadvalue(), n.value = void 0;
					let r = n.n, a = n.p;
					n.p = void 0, a && (a.n = r), r && (r.p = a), t.f === n && (t.f = r), t.l === n && (t.l = a), t.strong.delete(e), !function(t) {
						return "object" == typeof t ? null !== t : "function" == typeof t;
					}(e) ? t.dead_strong.set(e, n) : (t.dead_weak || (t.dead_weak = /* @__PURE__ */ new WeakMap()), t.dead_weak.set(e, n));
				}
			}, R = function(t, e) {
				let n = t.strong.get(e);
				return n ? n.value : T.luaO_nilobject;
			}, S = function(t, e) {
				return A("number" == typeof e && (0 | e) === e), R(t, e);
			};
			t.exports.invalidateTMcache = function(t) {
				t.flags = 0;
			}, t.exports.luaH_get = function(t, e, n) {
				return A(n instanceof T.TValue), n.ttisnil() || n.ttisfloat() && isNaN(n.value) ? T.luaO_nilobject : R(e, E(t, n));
			}, t.exports.luaH_getint = S, t.exports.luaH_getn = function(t) {
				let e = 0, n = t.strong.size + 1;
				for (; n - e > 1;) {
					let r = Math.floor((e + n) / 2);
					S(t, r).ttisnil() ? n = r : e = r;
				}
				return e;
			}, t.exports.luaH_getstr = function(t, e) {
				return A(e instanceof b), R(t, x(e));
			}, t.exports.luaH_setfrom = function(t, e, n, r) {
				A(n instanceof T.TValue);
				let a = E(t, n);
				if (r.ttisnil()) return void N(e, a);
				let u = e.strong.get(a);
				if (u) u.value.setfrom(r);
				else {
					let t, u = n.value;
					t = n.ttisfloat() && (0 | u) === u ? new T.TValue(_, u) : new T.TValue(n.type, u);
					let l = new T.TValue(r.type, r.value);
					m(e, a, t, l);
				}
			}, t.exports.luaH_setint = function(t, e, n) {
				A("number" == typeof e && (0 | e) === e && n instanceof T.TValue);
				let r = e;
				if (n.ttisnil()) return void N(t, r);
				let a = t.strong.get(r);
				if (a) a.value.setfrom(n);
				else {
					let a = new T.TValue(_, e), u = new T.TValue(n.type, n.value);
					m(t, r, a, u);
				}
			}, t.exports.luaH_new = function(t) {
				return new U(t);
			}, t.exports.luaH_next = function(t, e, n) {
				let r, a = t.stack[n];
				if (a.type === i) {
					if (!(r = e.f)) return !1;
				} else {
					let n = E(t, a);
					if (r = e.strong.get(n)) {
						if (!(r = r.n)) return !1;
					} else {
						if (!(r = e.dead_weak && e.dead_weak.get(n) || e.dead_strong.get(n))) return g.luaG_runerror(t, d("invalid key to 'next'"));
						do
							if (!(r = r.n)) return !1;
						while (r.key.ttisdeadkey());
					}
				}
				return T.setobj2s(t, n, r.key), T.setobj2s(t, n + 1, r.value), !0;
			}, t.exports.Table = U;
		},
		function(t, e, n) {
			"use strict";
			const { is_luastring: r, luastring_eq: a, luastring_from: u, to_luastring: l } = n(1), { lua_assert: s } = n(4);
			class o {
				constructor(t, e) {
					this.hash = null, this.realstring = e;
				}
				getstr() {
					return this.realstring;
				}
				tsslen() {
					return this.realstring.length;
				}
			}
			const i = function(t) {
				s(r(t));
				let e = t.length, n = "|";
				for (let r = 0; r < e; r++) n += t[r].toString(16);
				return n;
			}, c = function(t, e) {
				return s(e instanceof Uint8Array), new o(t, e);
			};
			t.exports.luaS_eqlngstr = function(t, e) {
				return s(t instanceof o), s(e instanceof o), t == e || a(t.realstring, e.realstring);
			}, t.exports.luaS_hash = i, t.exports.luaS_hashlongstr = function(t) {
				return s(t instanceof o), null === t.hash && (t.hash = i(t.getstr())), t.hash;
			}, t.exports.luaS_bless = c, t.exports.luaS_new = function(t, e) {
				return c(t, u(e));
			}, t.exports.luaS_newliteral = function(t, e) {
				return c(t, l(e));
			}, t.exports.TString = o;
		},
		function(t, e, n) {
			"use strict";
			const { LUA_HOOKCOUNT: r, LUA_HOOKLINE: a, LUA_MASKCOUNT: u, LUA_MASKLINE: l, constant_types: { LUA_TBOOLEAN: s, LUA_TNIL: o, LUA_TTABLE: i }, thread_status: { LUA_ERRRUN: c, LUA_YIELD: _ }, from_userstring: f, luastring_eq: p, luastring_indexOf: L, to_luastring: h } = n(1), { api_check: d, lua_assert: A } = n(4), { LUA_IDSIZE: g } = n(3), T = n(18), x = n(8), b = n(13), O = n(20), k = n(6), v = n(16), E = n(12), U = n(9), m = n(14), N = n(15), R = function(t) {
				return A(t.callstatus & E.CIST_LUA), t.l_savedpc - 1;
			}, S = function(t) {
				return 0 !== t.func.value.p.lineinfo.length ? t.func.value.p.lineinfo[R(t)] : -1;
			}, w = function(t) {
				if (t.status === _) {
					let e = t.ci, n = e.funcOff;
					e.func = t.stack[e.extra], e.funcOff = e.extra, e.extra = n;
				}
			}, I = function(t, e) {
				A(e < t.upvalues.length);
				let n = t.upvalues[e].name;
				return null === n ? h("?", !0) : n.getstr();
			}, y = function(t, e, n) {
				let r, a = null;
				if (e.callstatus & E.CIST_LUA) {
					if (n < 0) return function(t, e) {
						let n = t.func.value.p.numparams;
						return e >= t.l_base - t.funcOff - n ? null : {
							pos: t.funcOff + n + e,
							name: h("(*vararg)", !0)
						};
					}(e, -n);
					r = e.l_base, a = b.luaF_getlocalname(e.func.value.p, n, R(e));
				} else r = e.funcOff + 1;
				if (null === a) {
					if (!((e === t.ci ? t.top : e.next.funcOff) - r >= n && n > 0)) return null;
					a = h("(*temporary)", !0);
				}
				return {
					pos: r + (n - 1),
					name: a
				};
			}, M = function(t, e) {
				if (null === e || e instanceof k.CClosure) t.source = h("=[JS]", !0), t.linedefined = -1, t.lastlinedefined = -1, t.what = h("J", !0);
				else {
					let n = e.p;
					t.source = n.source ? n.source.getstr() : h("=?", !0), t.linedefined = n.linedefined, t.lastlinedefined = n.lastlinedefined, t.what = 0 === t.linedefined ? h("main", !0) : h("Lua", !0);
				}
				t.short_src = k.luaO_chunkid(t.source, g);
			}, P = function(t, e) {
				let n = {
					name: null,
					funcname: null
				};
				return null === e ? null : e.callstatus & E.CIST_FIN ? (n.name = h("__gc", !0), n.funcname = h("metamethod", !0), n) : !(e.callstatus & E.CIST_TAIL) && e.previous.callstatus & E.CIST_LUA ? B(t, e.previous) : null;
			}, C = function(t, e, n) {
				let r = {
					name: null,
					funcname: null
				};
				if (v.ISK(n)) {
					let e = t.k[v.INDEXK(n)];
					if (e.ttisstring()) return r.name = e.svalue(), r;
				} else {
					let r = V(t, e, n);
					if (r && 99 === r.funcname[0]) return r;
				}
				return r.name = h("?", !0), r;
			}, D = function(t, e) {
				return t < e ? -1 : t;
			}, V = function(t, e, n) {
				let r = {
					name: b.luaF_getlocalname(t, n + 1, e),
					funcname: null
				};
				if (r.name) return r.funcname = h("local", !0), r;
				let a = function(t, e, n) {
					let r = -1, a = 0, u = v.OpCodesI;
					for (let l = 0; l < e; l++) {
						let s = t.code[l], o = s.A;
						switch (s.opcode) {
							case u.OP_LOADNIL: {
								let t = s.B;
								o <= n && n <= o + t && (r = D(l, a));
								break;
							}
							case u.OP_TFORCALL:
								n >= o + 2 && (r = D(l, a));
								break;
							case u.OP_CALL:
							case u.OP_TAILCALL:
								n >= o && (r = D(l, a));
								break;
							case u.OP_JMP: {
								let t = l + 1 + s.sBx;
								l < t && t <= e && t > a && (a = t);
								break;
							}
							default: v.testAMode(s.opcode) && n === o && (r = D(l, a));
						}
					}
					return r;
				}(t, e, n), u = v.OpCodesI;
				if (-1 !== a) {
					let e = t.code[a];
					switch (e.opcode) {
						case u.OP_MOVE: {
							let n = e.B;
							if (n < e.A) return V(t, a, n);
							break;
						}
						case u.OP_GETTABUP:
						case u.OP_GETTABLE: {
							let n = e.C, l = e.B, s = e.opcode === u.OP_GETTABLE ? b.luaF_getlocalname(t, l + 1, a) : I(t, l);
							return r.name = C(t, a, n).name, r.funcname = s && p(s, O.LUA_ENV) ? h("global", !0) : h("field", !0), r;
						}
						case u.OP_GETUPVAL: return r.name = I(t, e.B), r.funcname = h("upvalue", !0), r;
						case u.OP_LOADK:
						case u.OP_LOADKX: {
							let n = e.opcode === u.OP_LOADK ? e.Bx : t.code[a + 1].Ax;
							if (t.k[n].ttisstring()) return r.name = t.k[n].svalue(), r.funcname = h("constant", !0), r;
							break;
						}
						case u.OP_SELF: {
							let n = e.C;
							return r.name = C(t, a, n).name, r.funcname = h("method", !0), r;
						}
					}
				}
				return null;
			}, B = function(t, e) {
				let n = {
					name: null,
					funcname: null
				}, r = 0, a = e.func.value.p, u = R(e), l = a.code[u], s = v.OpCodesI;
				if (e.callstatus & E.CIST_HOOKED) return n.name = h("?", !0), n.funcname = h("hook", !0), n;
				switch (l.opcode) {
					case s.OP_CALL:
					case s.OP_TAILCALL: return V(a, u, l.A);
					case s.OP_TFORCALL: return n.name = h("for iterator", !0), n.funcname = h("for iterator", !0), n;
					case s.OP_SELF:
					case s.OP_GETTABUP:
					case s.OP_GETTABLE:
						r = m.TMS.TM_INDEX;
						break;
					case s.OP_SETTABUP:
					case s.OP_SETTABLE:
						r = m.TMS.TM_NEWINDEX;
						break;
					case s.OP_ADD:
						r = m.TMS.TM_ADD;
						break;
					case s.OP_SUB:
						r = m.TMS.TM_SUB;
						break;
					case s.OP_MUL:
						r = m.TMS.TM_MUL;
						break;
					case s.OP_MOD:
						r = m.TMS.TM_MOD;
						break;
					case s.OP_POW:
						r = m.TMS.TM_POW;
						break;
					case s.OP_DIV:
						r = m.TMS.TM_DIV;
						break;
					case s.OP_IDIV:
						r = m.TMS.TM_IDIV;
						break;
					case s.OP_BAND:
						r = m.TMS.TM_BAND;
						break;
					case s.OP_BOR:
						r = m.TMS.TM_BOR;
						break;
					case s.OP_BXOR:
						r = m.TMS.TM_BXOR;
						break;
					case s.OP_SHL:
						r = m.TMS.TM_SHL;
						break;
					case s.OP_SHR:
						r = m.TMS.TM_SHR;
						break;
					case s.OP_UNM:
						r = m.TMS.TM_UNM;
						break;
					case s.OP_BNOT:
						r = m.TMS.TM_BNOT;
						break;
					case s.OP_LEN:
						r = m.TMS.TM_LEN;
						break;
					case s.OP_CONCAT:
						r = m.TMS.TM_CONCAT;
						break;
					case s.OP_EQ:
						r = m.TMS.TM_EQ;
						break;
					case s.OP_LT:
						r = m.TMS.TM_LT;
						break;
					case s.OP_LE:
						r = m.TMS.TM_LE;
						break;
					default: return null;
				}
				return n.name = t.l_G.tmname[r].getstr(), n.funcname = h("metamethod", !0), n;
			}, G = function(t, e) {
				let n = t.ci, r = null;
				if (n.callstatus & E.CIST_LUA) {
					r = function(t, e, n) {
						let r = e.func.value;
						for (let t = 0; t < r.nupvalues; t++) if (r.upvals[t] === n) return {
							name: I(r.p, t),
							funcname: h("upvalue", !0)
						};
						return null;
					}(0, n, e);
					let a = function(t, e, n) {
						for (let r = e.l_base; r < e.top; r++) if (t.stack[r] === n) return r;
						return !1;
					}(t, n, e);
					!r && a && (r = V(n.func.value.p, R(n), a - n.l_base));
				}
				return r ? k.luaO_pushfstring(t, h(" (%s '%s')", !0), r.funcname, r.name) : h("", !0);
			}, K = function(t, e, n) {
				let r = m.luaT_objtypename(t, e);
				j(t, h("attempt to %s a %s value%s", !0), n, r, G(t, e));
			}, F = function(t, e, n, r) {
				let a;
				return a = n ? k.luaO_chunkid(n.getstr(), g) : h("?", !0), k.luaO_pushfstring(t, h("%s:%d: %s", !0), a, r, e);
			}, j = function(t, e, ...n) {
				let r = t.ci, a = k.luaO_pushvfstring(t, e, n);
				r.callstatus & E.CIST_LUA && F(t, a, r.func.value.p.source, S(r)), H(t);
			}, H = function(t) {
				if (0 !== t.errfunc) {
					let e = t.errfunc;
					k.pushobj2s(t, t.stack[t.top - 1]), k.setobjs2s(t, t.top - 2, e), x.luaD_callnoyield(t, t.top - 2, 1);
				}
				x.luaD_throw(t, c);
			};
			t.exports.luaG_addinfo = F, t.exports.luaG_concaterror = function(t, e, n) {
				(e.ttisstring() || N.cvt2str(e)) && (e = n), K(t, e, h("concatenate", !0));
			}, t.exports.luaG_errormsg = H, t.exports.luaG_opinterror = function(t, e, n, r) {
				!1 === N.tonumber(e) && (n = e), K(t, n, r);
			}, t.exports.luaG_ordererror = function(t, e, n) {
				let r = m.luaT_objtypename(t, e), a = m.luaT_objtypename(t, n);
				p(r, a) ? j(t, h("attempt to compare two %s values", !0), r) : j(t, h("attempt to compare %s with %s", !0), r, a);
			}, t.exports.luaG_runerror = j, t.exports.luaG_tointerror = function(t, e, n) {
				!1 === N.tointeger(e) && (n = e), j(t, h("number%s has no integer representation", !0), G(t, n));
			}, t.exports.luaG_traceexec = function(t) {
				let e = t.ci, n = t.hookmask, s = 0 == --t.hookcount && n & u;
				if (s) t.hookcount = t.basehookcount;
				else if (!(n & l)) return;
				if (e.callstatus & E.CIST_HOOKYIELD) e.callstatus &= ~E.CIST_HOOKYIELD;
				else {
					if (s && x.luaD_hook(t, r, -1), n & l) {
						let n = e.func.value.p, r = e.l_savedpc - 1, u = 0 !== n.lineinfo.length ? n.lineinfo[r] : -1;
						(0 === r || e.l_savedpc <= t.oldpc || u !== (0 !== n.lineinfo.length ? n.lineinfo[t.oldpc - 1] : -1)) && x.luaD_hook(t, a, u);
					}
					t.oldpc = e.l_savedpc, t.status === _ && (s && (t.hookcount = 1), e.l_savedpc--, e.callstatus |= E.CIST_HOOKYIELD, e.funcOff = t.top - 1, e.func = t.stack[e.funcOff], x.luaD_throw(t, _));
				}
			}, t.exports.luaG_typeerror = K, t.exports.lua_gethook = function(t) {
				return t.hook;
			}, t.exports.lua_gethookcount = function(t) {
				return t.basehookcount;
			}, t.exports.lua_gethookmask = function(t) {
				return t.hookmask;
			}, t.exports.lua_getinfo = function(t, e, n) {
				let r, a, u, l;
				return e = f(e), w(t), 62 === e[0] ? (u = null, l = t.stack[t.top - 1], d(t, l.ttisfunction(), "function expected"), e = e.subarray(1), t.top--) : (l = (u = n.i_ci).func, A(u.func.ttisfunction())), r = function(t, e, n, r, a) {
					let u = 1;
					for (; e.length > 0; e = e.subarray(1)) switch (e[0]) {
						case 83:
							M(n, r);
							break;
						case 108:
							n.currentline = a && a.callstatus & E.CIST_LUA ? S(a) : -1;
							break;
						case 117:
							n.nups = null === r ? 0 : r.nupvalues, null === r || r instanceof k.CClosure ? (n.isvararg = !0, n.nparams = 0) : (n.isvararg = r.p.is_vararg, n.nparams = r.p.numparams);
							break;
						case 116:
							n.istailcall = a ? a.callstatus & E.CIST_TAIL : 0;
							break;
						case 110: {
							let e = P(t, a);
							null === e ? (n.namewhat = h("", !0), n.name = null) : (n.namewhat = e.funcname, n.name = e.name);
							break;
						}
						case 76:
						case 102: break;
						default: u = 0;
					}
					return u;
				}(t, e, n, a = l.ttisclosure() ? l.value : null, u), L(e, 102) >= 0 && (k.pushobj2s(t, l), d(t, t.top <= t.ci.top, "stack overflow")), w(t), L(e, 76) >= 0 && function(t, e) {
					if (null === e || e instanceof k.CClosure) t.stack[t.top] = new k.TValue(o, null), T.api_incr_top(t);
					else {
						let n = e.p.lineinfo, r = U.luaH_new(t);
						t.stack[t.top] = new k.TValue(i, r), T.api_incr_top(t);
						let a = new k.TValue(s, !0);
						for (let t = 0; t < n.length; t++) U.luaH_setint(r, n[t], a);
					}
				}(t, a), r;
			}, t.exports.lua_getlocal = function(t, e, n) {
				let r;
				if (w(t), null === e) r = t.stack[t.top - 1].ttisLclosure() ? b.luaF_getlocalname(t.stack[t.top - 1].value.p, n, 0) : null;
				else {
					let a = y(t, e.i_ci, n);
					a ? (r = a.name, k.pushobj2s(t, t.stack[a.pos]), d(t, t.top <= t.ci.top, "stack overflow")) : r = null;
				}
				return w(t), r;
			}, t.exports.lua_getstack = function(t, e, n) {
				let r, a;
				if (e < 0) return 0;
				for (r = t.ci; e > 0 && r !== t.base_ci; r = r.previous) e--;
				return 0 === e && r !== t.base_ci ? (a = 1, n.i_ci = r) : a = 0, a;
			}, t.exports.lua_sethook = function(t, e, n, r) {
				null !== e && 0 !== n || (n = 0, e = null), t.ci.callstatus & E.CIST_LUA && (t.oldpc = t.ci.l_savedpc), t.hook = e, t.basehookcount = r, t.hookcount = t.basehookcount, t.hookmask = n;
			}, t.exports.lua_setlocal = function(t, e, n) {
				let r;
				w(t);
				let a = y(t, e.i_ci, n);
				return a ? (r = a.name, k.setobjs2s(t, a.pos, t.top - 1), delete t.stack[--t.top]) : r = null, w(t), r;
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_MINSTACK: r, LUA_RIDX_GLOBALS: a, LUA_RIDX_MAINTHREAD: u, constant_types: { LUA_NUMTAGS: l, LUA_TNIL: s, LUA_TTABLE: o, LUA_TTHREAD: i }, thread_status: { LUA_OK: c } } = n(1), _ = n(6), f = n(8), p = n(18), L = n(9), h = n(14), d = 2 * r;
			class A {
				constructor() {
					this.func = null, this.funcOff = NaN, this.top = NaN, this.previous = null, this.next = null, this.l_base = NaN, this.l_code = null, this.l_savedpc = NaN, this.c_k = null, this.c_old_errfunc = null, this.c_ctx = null, this.nresults = NaN, this.callstatus = NaN;
				}
			}
			class g {
				constructor(t) {
					this.id = t.id_counter++, this.base_ci = new A(), this.top = NaN, this.stack_last = NaN, this.oldpc = NaN, this.l_G = t, this.stack = null, this.ci = null, this.errorJmp = null, this.nCcalls = 0, this.hook = null, this.hookmask = 0, this.basehookcount = 0, this.allowhook = 1, this.hookcount = this.basehookcount, this.nny = 1, this.status = c, this.errfunc = 0;
				}
			}
			const T = function(t) {
				t.ci.next = null;
			}, x = function(t, e) {
				t.stack = new Array(d), t.top = 0, t.stack_last = d - 5;
				let n = t.base_ci;
				n.next = n.previous = null, n.callstatus = 0, n.funcOff = t.top, n.func = t.stack[t.top], t.stack[t.top++] = new _.TValue(s, null), n.top = t.top + r, t.ci = n;
			}, b = function(t) {
				t.ci = t.base_ci, T(t), t.stack = null;
			}, O = function(t) {
				let e = t.l_G;
				x(t), function(t, e) {
					let n = L.luaH_new(t);
					e.l_registry.sethvalue(n), L.luaH_setint(n, u, new _.TValue(i, t)), L.luaH_setint(n, a, new _.TValue(o, L.luaH_new(t)));
				}(t, e), h.luaT_init(t), e.version = p.lua_version(null);
			};
			t.exports.lua_State = g, t.exports.CallInfo = A, t.exports.CIST_OAH = 1, t.exports.CIST_LUA = 2, t.exports.CIST_HOOKED = 4, t.exports.CIST_FRESH = 8, t.exports.CIST_YPCALL = 16, t.exports.CIST_TAIL = 32, t.exports.CIST_HOOKYIELD = 64, t.exports.CIST_LEQ = 128, t.exports.CIST_FIN = 256, t.exports.EXTRA_STACK = 5, t.exports.lua_close = function(t) {
				(function(t) {
					b(t);
				})(t = t.l_G.mainthread);
			}, t.exports.lua_newstate = function() {
				let t = new class {
					constructor() {
						this.id_counter = 1, this.ids = /* @__PURE__ */ new WeakMap(), this.mainthread = null, this.l_registry = new _.TValue(s, null), this.panic = null, this.atnativeerror = null, this.version = null, this.tmname = new Array(h.TMS.TM_N), this.mt = new Array(l);
					}
				}(), e = new g(t);
				return t.mainthread = e, f.luaD_rawrunprotected(e, O, null) !== c && (e = null), e;
			}, t.exports.lua_newthread = function(t) {
				let e = t.l_G, n = new g(e);
				return t.stack[t.top] = new _.TValue(i, n), p.api_incr_top(t), n.hookmask = t.hookmask, n.basehookcount = t.basehookcount, n.hook = t.hook, n.hookcount = n.basehookcount, x(n), n;
			}, t.exports.luaE_extendCI = function(t) {
				let e = new A();
				return t.ci.next = e, e.previous = t.ci, e.next = null, t.ci = e, e;
			}, t.exports.luaE_freeCI = T, t.exports.luaE_freethread = function(t, e) {
				b(e);
			};
		},
		function(t, e, n) {
			"use strict";
			const { constant_types: { LUA_TNIL: r } } = n(1), a = n(6);
			t.exports.MAXUPVAL = 255, t.exports.Proto = class {
				constructor(t) {
					this.id = t.l_G.id_counter++, this.k = [], this.p = [], this.code = [], this.cache = null, this.lineinfo = [], this.upvalues = [], this.numparams = 0, this.is_vararg = !1, this.maxstacksize = 0, this.locvars = [], this.linedefined = 0, this.lastlinedefined = 0, this.source = null;
				}
			}, t.exports.luaF_findupval = function(t, e) {
				return t.stack[e];
			}, t.exports.luaF_close = function(t, e) {
				for (let n = e; n < t.top; n++) {
					let e = t.stack[n];
					t.stack[n] = new a.TValue(e.type, e.value);
				}
			}, t.exports.luaF_getlocalname = function(t, e, n) {
				for (let r = 0; r < t.locvars.length && t.locvars[r].startpc <= n; r++) if (n < t.locvars[r].endpc && 0 == --e) return t.locvars[r].varname.getstr();
				return null;
			}, t.exports.luaF_initupvals = function(t, e) {
				for (let t = 0; t < e.nupvalues; t++) e.upvals[t] = new a.TValue(r, null);
			}, t.exports.luaF_newLclosure = function(t, e) {
				return new a.LClosure(t, e);
			};
		},
		function(t, e, n) {
			"use strict";
			const { constant_types: { LUA_TTABLE: r, LUA_TUSERDATA: a }, to_luastring: u } = n(1), { lua_assert: l } = n(4), s = n(6), o = n(8), i = n(12), { luaS_bless: c, luaS_new: _ } = n(10), f = n(9), p = n(11), L = n(15), h = [
				"no value",
				"nil",
				"boolean",
				"userdata",
				"number",
				"string",
				"table",
				"function",
				"userdata",
				"thread",
				"proto"
			].map((t) => u(t)), d = function(t) {
				return h[t + 1];
			}, A = {
				TM_INDEX: 0,
				TM_NEWINDEX: 1,
				TM_GC: 2,
				TM_MODE: 3,
				TM_LEN: 4,
				TM_EQ: 5,
				TM_ADD: 6,
				TM_SUB: 7,
				TM_MUL: 8,
				TM_MOD: 9,
				TM_POW: 10,
				TM_DIV: 11,
				TM_IDIV: 12,
				TM_BAND: 13,
				TM_BOR: 14,
				TM_BXOR: 15,
				TM_SHL: 16,
				TM_SHR: 17,
				TM_UNM: 18,
				TM_BNOT: 19,
				TM_LT: 20,
				TM_LE: 21,
				TM_CONCAT: 22,
				TM_CALL: 23,
				TM_N: 24
			}, g = u("__name", !0), T = function(t, e, n, r, a, u) {
				let l = t.top;
				if (s.pushobj2s(t, e), s.pushobj2s(t, n), s.pushobj2s(t, r), u || s.pushobj2s(t, a), t.ci.callstatus & i.CIST_LUA ? o.luaD_call(t, l, u) : o.luaD_callnoyield(t, l, u), u) {
					let e = t.stack[t.top - 1];
					delete t.stack[--t.top], a.setfrom(e);
				}
			}, x = function(t, e, n, r, a) {
				let u = O(t, e, a);
				return u.ttisnil() && (u = O(t, n, a)), !u.ttisnil() && (T(t, u, e, n, r, 1), !0);
			}, b = function(t, e, n) {
				const r = f.luaH_getstr(t, n);
				return l(e <= A.TM_EQ), r.ttisnil() ? (t.flags |= 1 << e, null) : r;
			}, O = function(t, e, n) {
				let u;
				switch (e.ttnov()) {
					case r:
					case a:
						u = e.value.metatable;
						break;
					default: u = t.l_G.mt[e.ttnov()];
				}
				return u ? f.luaH_getstr(u, t.l_G.tmname[n]) : s.luaO_nilobject;
			};
			t.exports.fasttm = function(t, e, n) {
				return null === e ? null : e.flags & 1 << n ? null : b(e, n, t.l_G.tmname[n]);
			}, t.exports.TMS = A, t.exports.luaT_callTM = T, t.exports.luaT_callbinTM = x, t.exports.luaT_trybinTM = function(t, e, n, r, a) {
				if (!x(t, e, n, r, a)) switch (a) {
					case A.TM_CONCAT: return p.luaG_concaterror(t, e, n);
					case A.TM_BAND:
					case A.TM_BOR:
					case A.TM_BXOR:
					case A.TM_SHL:
					case A.TM_SHR:
					case A.TM_BNOT: {
						let r = L.tonumber(e), a = L.tonumber(n);
						return !1 !== r && !1 !== a ? p.luaG_tointerror(t, e, n) : p.luaG_opinterror(t, e, n, u("perform bitwise operation on", !0));
					}
					default: return p.luaG_opinterror(t, e, n, u("perform arithmetic on", !0));
				}
			}, t.exports.luaT_callorderTM = function(t, e, n, r) {
				let a = new s.TValue();
				return x(t, e, n, a, r) ? !a.l_isfalse() : null;
			}, t.exports.luaT_gettm = b, t.exports.luaT_gettmbyobj = O, t.exports.luaT_init = function(t) {
				t.l_G.tmname[A.TM_INDEX] = new _(t, u("__index", !0)), t.l_G.tmname[A.TM_NEWINDEX] = new _(t, u("__newindex", !0)), t.l_G.tmname[A.TM_GC] = new _(t, u("__gc", !0)), t.l_G.tmname[A.TM_MODE] = new _(t, u("__mode", !0)), t.l_G.tmname[A.TM_LEN] = new _(t, u("__len", !0)), t.l_G.tmname[A.TM_EQ] = new _(t, u("__eq", !0)), t.l_G.tmname[A.TM_ADD] = new _(t, u("__add", !0)), t.l_G.tmname[A.TM_SUB] = new _(t, u("__sub", !0)), t.l_G.tmname[A.TM_MUL] = new _(t, u("__mul", !0)), t.l_G.tmname[A.TM_MOD] = new _(t, u("__mod", !0)), t.l_G.tmname[A.TM_POW] = new _(t, u("__pow", !0)), t.l_G.tmname[A.TM_DIV] = new _(t, u("__div", !0)), t.l_G.tmname[A.TM_IDIV] = new _(t, u("__idiv", !0)), t.l_G.tmname[A.TM_BAND] = new _(t, u("__band", !0)), t.l_G.tmname[A.TM_BOR] = new _(t, u("__bor", !0)), t.l_G.tmname[A.TM_BXOR] = new _(t, u("__bxor", !0)), t.l_G.tmname[A.TM_SHL] = new _(t, u("__shl", !0)), t.l_G.tmname[A.TM_SHR] = new _(t, u("__shr", !0)), t.l_G.tmname[A.TM_UNM] = new _(t, u("__unm", !0)), t.l_G.tmname[A.TM_BNOT] = new _(t, u("__bnot", !0)), t.l_G.tmname[A.TM_LT] = new _(t, u("__lt", !0)), t.l_G.tmname[A.TM_LE] = new _(t, u("__le", !0)), t.l_G.tmname[A.TM_CONCAT] = new _(t, u("__concat", !0)), t.l_G.tmname[A.TM_CALL] = new _(t, u("__call", !0));
			}, t.exports.luaT_objtypename = function(t, e) {
				let n;
				if (e.ttistable() && null !== (n = e.value.metatable) || e.ttisfulluserdata() && null !== (n = e.value.metatable)) {
					let e = f.luaH_getstr(n, c(t, g));
					if (e.ttisstring()) return e.svalue();
				}
				return d(e.ttnov());
			}, t.exports.ttypename = d;
		},
		function(t, e, n) {
			"use strict";
			const { LUA_MASKLINE: r, LUA_MASKCOUNT: a, LUA_MULTRET: u, constant_types: { LUA_TBOOLEAN: l, LUA_TLCF: s, LUA_TLIGHTUSERDATA: o, LUA_TLNGSTR: i, LUA_TNIL: c, LUA_TNUMBER: _, LUA_TNUMFLT: f, LUA_TNUMINT: p, LUA_TSHRSTR: L, LUA_TTABLE: h, LUA_TUSERDATA: d }, to_luastring: A } = n(1), { INDEXK: g, ISK: T, LFIELDS_PER_FLUSH: x, OpCodesI: { OP_ADD: b, OP_BAND: O, OP_BNOT: k, OP_BOR: v, OP_BXOR: E, OP_CALL: U, OP_CLOSURE: m, OP_CONCAT: N, OP_DIV: R, OP_EQ: S, OP_EXTRAARG: w, OP_FORLOOP: I, OP_FORPREP: y, OP_GETTABLE: M, OP_GETTABUP: P, OP_GETUPVAL: C, OP_IDIV: D, OP_JMP: V, OP_LE: B, OP_LEN: G, OP_LOADBOOL: K, OP_LOADK: F, OP_LOADKX: j, OP_LOADNIL: H, OP_LT: X, OP_MOD: z, OP_MOVE: Y, OP_MUL: J, OP_NEWTABLE: Z, OP_NOT: q, OP_POW: W, OP_RETURN: Q, OP_SELF: $, OP_SETLIST: tt, OP_SETTABLE: et, OP_SETTABUP: nt, OP_SETUPVAL: rt, OP_SHL: at, OP_SHR: ut, OP_SUB: lt, OP_TAILCALL: st, OP_TEST: ot, OP_TESTSET: it, OP_TFORCALL: ct, OP_TFORLOOP: _t, OP_UNM: ft, OP_VARARG: pt } } = n(16), { LUA_MAXINTEGER: Lt, LUA_MININTEGER: ht, lua_numbertointeger: dt } = n(3), { lua_assert: At, luai_nummod: gt } = n(4), Tt = n(6), xt = n(13), bt = n(12), { luaS_bless: Ot, luaS_eqlngstr: kt, luaS_hashlongstr: vt } = n(10), Et = n(8), Ut = n(14), mt = n(9), Nt = n(11), Rt = function(t, e, n) {
				return e + n.A;
			}, St = function(t, e, n) {
				return e + n.B;
			}, wt = function(t, e, n, r) {
				return T(r.B) ? n[g(r.B)] : t.stack[e + r.B];
			}, It = function(t, e, n, r) {
				return T(r.C) ? n[g(r.C)] : t.stack[e + r.C];
			}, yt = function(t, e, n, r) {
				let a = n.A;
				0 !== a && xt.luaF_close(t, e.l_base + a - 1), e.l_savedpc += n.sBx + r;
			}, Mt = function(t, e) {
				yt(t, e, e.l_code[e.l_savedpc], 1);
			}, Pt = function(t, e, n) {
				if (e.ttisnumber() && n.ttisnumber()) return Ft(e, n) ? 1 : 0;
				if (e.ttisstring() && n.ttisstring()) return Ht(e.tsvalue(), n.tsvalue()) < 0 ? 1 : 0;
				{
					let r = Ut.luaT_callorderTM(t, e, n, Ut.TMS.TM_LT);
					return null === r && Nt.luaG_ordererror(t, e, n), r ? 1 : 0;
				}
			}, Ct = function(t, e, n) {
				let r;
				return e.ttisnumber() && n.ttisnumber() ? jt(e, n) ? 1 : 0 : e.ttisstring() && n.ttisstring() ? Ht(e.tsvalue(), n.tsvalue()) <= 0 ? 1 : 0 : null !== (r = Ut.luaT_callorderTM(t, e, n, Ut.TMS.TM_LE)) ? r ? 1 : 0 : (t.ci.callstatus |= bt.CIST_LEQ, r = Ut.luaT_callorderTM(t, n, e, Ut.TMS.TM_LT), t.ci.callstatus ^= bt.CIST_LEQ, null === r && Nt.luaG_ordererror(t, e, n), r ? 0 : 1);
			}, Dt = function(t, e, n) {
				if (e.ttype() !== n.ttype()) return e.ttnov() !== n.ttnov() || e.ttnov() !== _ ? 0 : e.value === n.value ? 1 : 0;
				let r;
				switch (e.ttype()) {
					case c: return 1;
					case l: return e.value == n.value ? 1 : 0;
					case o:
					case p:
					case f:
					case s: return e.value === n.value ? 1 : 0;
					case L:
					case i: return kt(e.tsvalue(), n.tsvalue()) ? 1 : 0;
					case d:
					case h:
						if (e.value === n.value) return 1;
						if (null === t) return 0;
						null === (r = Ut.fasttm(t, e.value.metatable, Ut.TMS.TM_EQ)) && (r = Ut.fasttm(t, n.value.metatable, Ut.TMS.TM_EQ));
						break;
					default: return e.value === n.value ? 1 : 0;
				}
				if (null === r) return 0;
				let a = new Tt.TValue();
				return Ut.luaT_callTM(t, r, e, n, a, 1), a.l_isfalse() ? 0 : 1;
			}, Vt = function(t, e) {
				let n = !1, r = Bt(t, e < 0 ? 2 : 1);
				if (!1 === r) {
					let a = Kt(t);
					if (!1 === a) return !1;
					0 < a ? (r = Lt, e < 0 && (n = !0)) : (r = ht, e >= 0 && (n = !0));
				}
				return {
					stopnow: n,
					ilimit: r
				};
			}, Bt = function(t, e) {
				if (t.ttisfloat()) {
					let n = t.value, r = Math.floor(n);
					if (n !== r) {
						if (0 === e) return !1;
						e > 1 && (r += 1);
					}
					return dt(r);
				}
				if (t.ttisinteger()) return t.value;
				if ($t(t)) {
					let n = new Tt.TValue();
					if (Tt.luaO_str2num(t.svalue(), n) === t.vslen() + 1) return Bt(n, e);
				}
				return !1;
			}, Gt = function(t) {
				return t.ttisinteger() ? t.value : Bt(t, 0);
			}, Kt = function(t) {
				if (t.ttnov() === _) return t.value;
				if ($t(t)) {
					let e = new Tt.TValue();
					if (Tt.luaO_str2num(t.svalue(), e) === t.vslen() + 1) return e.value;
				}
				return !1;
			}, Ft = function(t, e) {
				return t.value < e.value;
			}, jt = function(t, e) {
				return t.value <= e.value;
			}, Ht = function(t, e) {
				let n = vt(t), r = vt(e);
				return n === r ? 0 : n < r ? -1 : 1;
			}, Xt = function(t, e, n) {
				let r;
				switch (n.ttype()) {
					case h: {
						let a = n.value;
						if (null !== (r = Ut.fasttm(t, a.metatable, Ut.TMS.TM_LEN))) break;
						e.setivalue(mt.luaH_getn(a));
						return;
					}
					case L:
					case i:
						e.setivalue(n.vslen());
						return;
					default: (r = Ut.luaT_gettmbyobj(t, n, Ut.TMS.TM_LEN)).ttisnil() && Nt.luaG_typeerror(t, n, A("get length of", !0));
				}
				Ut.luaT_callTM(t, r, n, n, e, 1);
			}, zt = Math.imul || function(t, e) {
				let n = 65535 & t, r = 65535 & e;
				return n * r + ((t >>> 16 & 65535) * r + n * (e >>> 16 & 65535) << 16 >>> 0) | 0;
			}, Yt = function(t, e, n) {
				return 0 === n && Nt.luaG_runerror(t, A("attempt to divide by zero")), 0 | Math.floor(e / n);
			}, Jt = function(t, e, n) {
				return 0 === n && Nt.luaG_runerror(t, A("attempt to perform 'n%%0'")), e - Math.floor(e / n) * n | 0;
			}, Zt = function(t, e) {
				return e < 0 ? e <= -32 ? 0 : t >>> -e : e >= 32 ? 0 : t << e;
			}, qt = function(t, e, n, r) {
				let a = t.cache;
				if (null !== a) {
					let u = t.upvalues, l = u.length;
					for (let t = 0; t < l; t++) {
						let l = u[t].instack ? n[r + u[t].idx] : e[u[t].idx];
						if (a.upvals[t] !== l) return null;
					}
				}
				return a;
			}, Wt = function(t, e, n, r, a) {
				let u = e.upvalues.length, l = e.upvalues, s = new Tt.LClosure(t, u);
				s.p = e, t.stack[a].setclLvalue(s);
				for (let e = 0; e < u; e++) l[e].instack ? s.upvals[e] = xt.luaF_findupval(t, r + l[e].idx) : s.upvals[e] = n[l[e].idx];
				e.cache = s;
			}, Qt = function(t) {
				return t.ttisnumber();
			}, $t = function(t) {
				return t.ttisstring();
			}, te = function(t, e) {
				let n = t.stack[e];
				return !!n.ttisstring() || !!Qt(n) && (Tt.luaO_tostring(t, n), !0);
			}, ee = function(t) {
				return t.ttisstring() && 0 === t.vslen();
			}, ne = function(t, e, n, r) {
				let a = 0;
				do {
					let u = t.stack[e - n], l = u.vslen(), s = u.svalue();
					r.set(s, a), a += l;
				} while (--n > 0);
			}, re = function(t, e) {
				At(e >= 2);
				do {
					let n = t.top, r = 2;
					if ((t.stack[n - 2].ttisstring() || Qt(t.stack[n - 2])) && te(t, n - 1)) if (ee(t.stack[n - 1])) te(t, n - 2);
					else if (ee(t.stack[n - 2])) Tt.setobjs2s(t, n - 2, n - 1);
					else {
						let a = t.stack[n - 1].vslen();
						for (r = 1; r < e && te(t, n - r - 1); r++) a += t.stack[n - r - 1].vslen();
						let u = new Uint8Array(a);
						ne(t, n, r, u);
						let l = Ot(t, u);
						Tt.setsvalue2s(t, n - r, l);
					}
					else Ut.luaT_trybinTM(t, t.stack[n - 2], t.stack[n - 1], t.stack[n - 2], Ut.TMS.TM_CONCAT);
					for (e -= r - 1; t.top > n - (r - 1);) delete t.stack[--t.top];
				} while (e > 1);
			}, ae = function(t, e, n, r) {
				for (let a = 0; a < 2e3; a++) {
					let a;
					if (e.ttistable()) {
						let u = mt.luaH_get(t, e.value, n);
						if (!u.ttisnil()) return void Tt.setobj2s(t, r, u);
						if (null === (a = Ut.fasttm(t, e.value.metatable, Ut.TMS.TM_INDEX))) return void t.stack[r].setnilvalue();
					} else (a = Ut.luaT_gettmbyobj(t, e, Ut.TMS.TM_INDEX)).ttisnil() && Nt.luaG_typeerror(t, e, A("index", !0));
					if (a.ttisfunction()) return void Ut.luaT_callTM(t, a, e, n, t.stack[r], 1);
					e = a;
				}
				Nt.luaG_runerror(t, A("'__index' chain too long; possible loop", !0));
			}, ue = function(t, e, n, r) {
				for (let a = 0; a < 2e3; a++) {
					let a;
					if (e.ttistable()) {
						let u = e.value;
						if (!mt.luaH_get(t, u, n).ttisnil() || null === (a = Ut.fasttm(t, u.metatable, Ut.TMS.TM_NEWINDEX))) return mt.luaH_setfrom(t, u, n, r), void mt.invalidateTMcache(u);
					} else (a = Ut.luaT_gettmbyobj(t, e, Ut.TMS.TM_NEWINDEX)).ttisnil() && Nt.luaG_typeerror(t, e, A("index", !0));
					if (a.ttisfunction()) return void Ut.luaT_callTM(t, a, e, n, r, 0);
					e = a;
				}
				Nt.luaG_runerror(t, A("'__newindex' chain too long; possible loop", !0));
			};
			t.exports.cvt2str = Qt, t.exports.cvt2num = $t, t.exports.luaV_gettable = ae, t.exports.luaV_concat = re, t.exports.luaV_div = Yt, t.exports.luaV_equalobj = Dt, t.exports.luaV_execute = function(t) {
				let e = t.ci;
				e.callstatus |= bt.CIST_FRESH;
				t: for (;;) {
					At(e === t.ci);
					let n = e.func.value, l = n.p.k, s = e.l_base, o = e.l_code[e.l_savedpc++];
					t.hookmask & (r | a) && Nt.luaG_traceexec(t);
					let i = Rt(0, s, o);
					switch (o.opcode) {
						case Y:
							Tt.setobjs2s(t, i, St(0, s, o));
							break;
						case F: {
							let e = l[o.Bx];
							Tt.setobj2s(t, i, e);
							break;
						}
						case j: {
							At(e.l_code[e.l_savedpc].opcode === w);
							let n = l[e.l_code[e.l_savedpc++].Ax];
							Tt.setobj2s(t, i, n);
							break;
						}
						case K:
							t.stack[i].setbvalue(0 !== o.B), 0 !== o.C && e.l_savedpc++;
							break;
						case H:
							for (let e = 0; e <= o.B; e++) t.stack[i + e].setnilvalue();
							break;
						case C: {
							let e = o.B;
							Tt.setobj2s(t, i, n.upvals[e]);
							break;
						}
						case P: {
							let e = n.upvals[o.B], r = It(t, s, l, o);
							ae(t, e, r, i);
							break;
						}
						case M: {
							let e = t.stack[St(0, s, o)], n = It(t, s, l, o);
							ae(t, e, n, i);
							break;
						}
						case nt: {
							let e = n.upvals[o.A], r = wt(t, s, l, o), a = It(t, s, l, o);
							ue(t, e, r, a);
							break;
						}
						case rt:
							n.upvals[o.B].setfrom(t.stack[i]);
							break;
						case et: {
							let e = t.stack[i], n = wt(t, s, l, o), r = It(t, s, l, o);
							ue(t, e, n, r);
							break;
						}
						case Z:
							t.stack[i].sethvalue(mt.luaH_new(t));
							break;
						case $: {
							let e = St(0, s, o), n = It(t, s, l, o);
							Tt.setobjs2s(t, i + 1, e), ae(t, t.stack[e], n, i);
							break;
						}
						case b: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							r.ttisinteger() && a.ttisinteger() ? t.stack[i].setivalue(r.value + a.value | 0) : !1 !== (e = Kt(r)) && !1 !== (n = Kt(a)) ? t.stack[i].setfltvalue(e + n) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_ADD);
							break;
						}
						case lt: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							r.ttisinteger() && a.ttisinteger() ? t.stack[i].setivalue(r.value - a.value | 0) : !1 !== (e = Kt(r)) && !1 !== (n = Kt(a)) ? t.stack[i].setfltvalue(e - n) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_SUB);
							break;
						}
						case J: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							r.ttisinteger() && a.ttisinteger() ? t.stack[i].setivalue(zt(r.value, a.value)) : !1 !== (e = Kt(r)) && !1 !== (n = Kt(a)) ? t.stack[i].setfltvalue(e * n) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_MUL);
							break;
						}
						case z: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							r.ttisinteger() && a.ttisinteger() ? t.stack[i].setivalue(Jt(t, r.value, a.value)) : !1 !== (e = Kt(r)) && !1 !== (n = Kt(a)) ? t.stack[i].setfltvalue(gt(t, e, n)) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_MOD);
							break;
						}
						case W: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							!1 !== (e = Kt(r)) && !1 !== (n = Kt(a)) ? t.stack[i].setfltvalue(Math.pow(e, n)) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_POW);
							break;
						}
						case R: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							!1 !== (e = Kt(r)) && !1 !== (n = Kt(a)) ? t.stack[i].setfltvalue(e / n) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_DIV);
							break;
						}
						case D: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							r.ttisinteger() && a.ttisinteger() ? t.stack[i].setivalue(Yt(t, r.value, a.value)) : !1 !== (e = Kt(r)) && !1 !== (n = Kt(a)) ? t.stack[i].setfltvalue(Math.floor(e / n)) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_IDIV);
							break;
						}
						case O: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							!1 !== (e = Gt(r)) && !1 !== (n = Gt(a)) ? t.stack[i].setivalue(e & n) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_BAND);
							break;
						}
						case v: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							!1 !== (e = Gt(r)) && !1 !== (n = Gt(a)) ? t.stack[i].setivalue(e | n) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_BOR);
							break;
						}
						case E: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							!1 !== (e = Gt(r)) && !1 !== (n = Gt(a)) ? t.stack[i].setivalue(e ^ n) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_BXOR);
							break;
						}
						case at: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							!1 !== (e = Gt(r)) && !1 !== (n = Gt(a)) ? t.stack[i].setivalue(Zt(e, n)) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_SHL);
							break;
						}
						case ut: {
							let e, n, r = wt(t, s, l, o), a = It(t, s, l, o);
							!1 !== (e = Gt(r)) && !1 !== (n = Gt(a)) ? t.stack[i].setivalue(Zt(e, -n)) : Ut.luaT_trybinTM(t, r, a, t.stack[i], Ut.TMS.TM_SHR);
							break;
						}
						case ft: {
							let e, n = t.stack[St(0, s, o)];
							n.ttisinteger() ? t.stack[i].setivalue(0 | -n.value) : !1 !== (e = Kt(n)) ? t.stack[i].setfltvalue(-e) : Ut.luaT_trybinTM(t, n, n, t.stack[i], Ut.TMS.TM_UNM);
							break;
						}
						case k: {
							let e = t.stack[St(0, s, o)];
							e.ttisinteger() ? t.stack[i].setivalue(~e.value) : Ut.luaT_trybinTM(t, e, e, t.stack[i], Ut.TMS.TM_BNOT);
							break;
						}
						case q: {
							let e = t.stack[St(0, s, o)];
							t.stack[i].setbvalue(e.l_isfalse());
							break;
						}
						case G:
							Xt(t, t.stack[i], t.stack[St(0, s, o)]);
							break;
						case N: {
							let n = o.B, r = o.C;
							t.top = s + r + 1, re(t, r - n + 1);
							let a = s + n;
							Tt.setobjs2s(t, i, a), Et.adjust_top(t, e.top);
							break;
						}
						case V:
							yt(t, e, o, 0);
							break;
						case S:
							Dt(t, wt(t, s, l, o), It(t, s, l, o)) !== o.A ? e.l_savedpc++ : Mt(t, e);
							break;
						case X:
							Pt(t, wt(t, s, l, o), It(t, s, l, o)) !== o.A ? e.l_savedpc++ : Mt(t, e);
							break;
						case B:
							Ct(t, wt(t, s, l, o), It(t, s, l, o)) !== o.A ? e.l_savedpc++ : Mt(t, e);
							break;
						case ot:
							(o.C ? t.stack[i].l_isfalse() : !t.stack[i].l_isfalse()) ? e.l_savedpc++ : Mt(t, e);
							break;
						case it: {
							let n = St(0, s, o), r = t.stack[n];
							(o.C ? r.l_isfalse() : !r.l_isfalse()) ? e.l_savedpc++ : (Tt.setobjs2s(t, i, n), Mt(t, e));
							break;
						}
						case U: {
							let n = o.B, r = o.C - 1;
							if (0 !== n && Et.adjust_top(t, i + n), !Et.luaD_precall(t, i, r)) {
								e = t.ci;
								continue t;
							}
							r >= 0 && Et.adjust_top(t, e.top);
							break;
						}
						case st: {
							let r = o.B;
							if (0 !== r && Et.adjust_top(t, i + r), !Et.luaD_precall(t, i, u)) {
								let r = t.ci, a = r.previous, u = r.func, l = r.funcOff, s = a.funcOff, o = r.l_base + u.value.p.numparams;
								n.p.p.length > 0 && xt.luaF_close(t, a.l_base);
								for (let e = 0; l + e < o; e++) Tt.setobjs2s(t, s + e, l + e);
								a.l_base = s + (r.l_base - l), a.top = s + (t.top - l), Et.adjust_top(t, a.top), a.l_code = r.l_code, a.l_savedpc = r.l_savedpc, a.callstatus |= bt.CIST_TAIL, a.next = null, e = t.ci = a, At(t.top === a.l_base + t.stack[s].value.p.maxstacksize);
								continue t;
							}
							break;
						}
						case Q: {
							n.p.p.length > 0 && xt.luaF_close(t, s);
							let r = Et.luaD_poscall(t, e, i, 0 !== o.B ? o.B - 1 : t.top - i);
							if (e.callstatus & bt.CIST_FRESH) return;
							e = t.ci, r && Et.adjust_top(t, e.top), At(e.callstatus & bt.CIST_LUA), At(e.l_code[e.l_savedpc - 1].opcode === U);
							continue t;
						}
						case I:
							if (t.stack[i].ttisinteger()) {
								let n = t.stack[i + 2].value, r = t.stack[i].value + n | 0, a = t.stack[i + 1].value;
								(0 < n ? r <= a : a <= r) && (e.l_savedpc += o.sBx, t.stack[i].chgivalue(r), t.stack[i + 3].setivalue(r));
							} else {
								let n = t.stack[i + 2].value, r = t.stack[i].value + n, a = t.stack[i + 1].value;
								(0 < n ? r <= a : a <= r) && (e.l_savedpc += o.sBx, t.stack[i].chgfltvalue(r), t.stack[i + 3].setfltvalue(r));
							}
							break;
						case y: {
							let n, r = t.stack[i], a = t.stack[i + 1], u = t.stack[i + 2];
							if (r.ttisinteger() && u.ttisinteger() && (n = Vt(a, u.value))) {
								let t = n.stopnow ? 0 : r.value;
								a.value = n.ilimit, r.value = t - u.value | 0;
							} else {
								let e, n, l;
								!1 === (e = Kt(a)) && Nt.luaG_runerror(t, A("'for' limit must be a number", !0)), t.stack[i + 1].setfltvalue(e), !1 === (n = Kt(u)) && Nt.luaG_runerror(t, A("'for' step must be a number", !0)), t.stack[i + 2].setfltvalue(n), !1 === (l = Kt(r)) && Nt.luaG_runerror(t, A("'for' initial value must be a number", !0)), t.stack[i].setfltvalue(l - n);
							}
							e.l_savedpc += o.sBx;
							break;
						}
						case ct: {
							let n = i + 3;
							Tt.setobjs2s(t, n + 2, i + 2), Tt.setobjs2s(t, n + 1, i + 1), Tt.setobjs2s(t, n, i), Et.adjust_top(t, n + 3), Et.luaD_call(t, n, o.C), Et.adjust_top(t, e.top), o = e.l_code[e.l_savedpc++], i = Rt(0, s, o), At(o.opcode === _t);
						}
						case _t:
							t.stack[i + 1].ttisnil() || (Tt.setobjs2s(t, i, i + 1), e.l_savedpc += o.sBx);
							break;
						case tt: {
							let n = o.B, r = o.C;
							0 === n && (n = t.top - i - 1), 0 === r && (At(e.l_code[e.l_savedpc].opcode === w), r = e.l_code[e.l_savedpc++].Ax);
							let a = t.stack[i].value, u = (r - 1) * x + n;
							for (; n > 0; n--) mt.luaH_setint(a, u--, t.stack[i + n]);
							Et.adjust_top(t, e.top);
							break;
						}
						case m: {
							let e = n.p.p[o.Bx], r = qt(e, n.upvals, t.stack, s);
							null === r ? Wt(t, e, n.upvals, s, i) : t.stack[i].setclLvalue(r);
							break;
						}
						case pt: {
							let r, a = o.B - 1, u = s - e.funcOff - n.p.numparams - 1;
							for (u < 0 && (u = 0), a < 0 && (a = u, Et.luaD_checkstack(t, u), Et.adjust_top(t, i + u)), r = 0; r < a && r < u; r++) Tt.setobjs2s(t, i + r, s - u + r);
							for (; r < a; r++) t.stack[i + r].setnilvalue();
							break;
						}
						case w: throw Error("invalid opcode");
					}
				}
			}, t.exports.luaV_finishOp = function(t) {
				let e = t.ci, n = e.l_base, r = e.l_code[e.l_savedpc - 1], a = r.opcode;
				switch (a) {
					case b:
					case lt:
					case J:
					case R:
					case D:
					case O:
					case v:
					case E:
					case at:
					case ut:
					case z:
					case W:
					case ft:
					case k:
					case G:
					case P:
					case M:
					case $:
						Tt.setobjs2s(t, n + r.A, t.top - 1), delete t.stack[--t.top];
						break;
					case B:
					case X:
					case S: {
						let n = !t.stack[t.top - 1].l_isfalse();
						delete t.stack[--t.top], e.callstatus & bt.CIST_LEQ && (At(a === B), e.callstatus ^= bt.CIST_LEQ, n = !n), At(e.l_code[e.l_savedpc].opcode === V), n !== !!r.A && e.l_savedpc++;
						break;
					}
					case N: {
						let a = t.top - 1, u = a - 1 - (n + r.B);
						Tt.setobjs2s(t, a - 2, a), u > 1 && (t.top = a - 1, re(t, u)), Tt.setobjs2s(t, e.l_base + r.A, t.top - 1), Et.adjust_top(t, e.top);
						break;
					}
					case ct:
						At(e.l_code[e.l_savedpc].opcode === _t), Et.adjust_top(t, e.top);
						break;
					case U: r.C - 1 >= 0 && Et.adjust_top(t, e.top);
				}
			}, t.exports.luaV_imul = zt, t.exports.luaV_lessequal = Ct, t.exports.luaV_lessthan = Pt, t.exports.luaV_mod = Jt, t.exports.luaV_objlen = Xt, t.exports.luaV_rawequalobj = function(t, e) {
				return Dt(null, t, e);
			}, t.exports.luaV_shiftl = Zt, t.exports.luaV_tointeger = Bt, t.exports.settable = ue, t.exports.tointeger = Gt, t.exports.tonumber = Kt;
		},
		function(t, e, n) {
			"use strict";
			const r = [
				96,
				113,
				65,
				84,
				80,
				80,
				92,
				108,
				60,
				16,
				60,
				84,
				108,
				124,
				124,
				124,
				124,
				124,
				124,
				124,
				124,
				124,
				124,
				124,
				124,
				96,
				96,
				96,
				96,
				104,
				34,
				188,
				188,
				188,
				132,
				228,
				84,
				84,
				16,
				98,
				98,
				4,
				98,
				20,
				81,
				80,
				23
			], a = function(t, e) {
				return ~(-1 << t) << e;
			}, u = function(t, e) {
				return ~a(t, e);
			}, l = function(t, e, n, r) {
				return t.code = t.code & u(r, n) | e << n & a(r, n), o(t);
			}, s = function(t, e) {
				return l(t, e, 14, 18);
			}, o = function(t) {
				if ("number" == typeof t) return {
					code: t,
					opcode: t >> 0 & a(6, 0),
					A: t >> 6 & a(8, 0),
					B: t >> 23 & a(9, 0),
					C: t >> 14 & a(9, 0),
					Bx: t >> 14 & a(18, 0),
					Ax: t >> 6 & a(26, 0),
					sBx: (t >> 14 & a(18, 0)) - 131071
				};
				{
					let e = t.code;
					return t.opcode = e >> 0 & a(6, 0), t.A = e >> 6 & a(8, 0), t.B = e >> 23 & a(9, 0), t.C = e >> 14 & a(9, 0), t.Bx = e >> 14 & a(18, 0), t.Ax = e >> 6 & a(26, 0), t.sBx = (e >> 14 & a(18, 0)) - 131071, t;
				}
			};
			t.exports.BITRK = 256, t.exports.CREATE_ABC = function(t, e, n, r) {
				return o(t << 0 | e << 6 | n << 23 | r << 14);
			}, t.exports.CREATE_ABx = function(t, e, n) {
				return o(t << 0 | e << 6 | n << 14);
			}, t.exports.CREATE_Ax = function(t, e) {
				return o(t << 0 | e << 6);
			}, t.exports.GET_OPCODE = function(t) {
				return t.opcode;
			}, t.exports.GETARG_A = function(t) {
				return t.A;
			}, t.exports.GETARG_B = function(t) {
				return t.B;
			}, t.exports.GETARG_C = function(t) {
				return t.C;
			}, t.exports.GETARG_Bx = function(t) {
				return t.Bx;
			}, t.exports.GETARG_Ax = function(t) {
				return t.Ax;
			}, t.exports.GETARG_sBx = function(t) {
				return t.sBx;
			}, t.exports.INDEXK = function(t) {
				return -257 & t;
			}, t.exports.ISK = function(t) {
				return 256 & t;
			}, t.exports.LFIELDS_PER_FLUSH = 50, t.exports.MAXARG_A = 255, t.exports.MAXARG_Ax = 67108863, t.exports.MAXARG_B = 511, t.exports.MAXARG_Bx = 262143, t.exports.MAXARG_C = 511, t.exports.MAXARG_sBx = 131071, t.exports.MAXINDEXRK = 255, t.exports.NO_REG = 255, t.exports.OpArgK = 3, t.exports.OpArgN = 0, t.exports.OpArgR = 2, t.exports.OpArgU = 1, t.exports.OpCodes = [
				"MOVE",
				"LOADK",
				"LOADKX",
				"LOADBOOL",
				"LOADNIL",
				"GETUPVAL",
				"GETTABUP",
				"GETTABLE",
				"SETTABUP",
				"SETUPVAL",
				"SETTABLE",
				"NEWTABLE",
				"SELF",
				"ADD",
				"SUB",
				"MUL",
				"MOD",
				"POW",
				"DIV",
				"IDIV",
				"BAND",
				"BOR",
				"BXOR",
				"SHL",
				"SHR",
				"UNM",
				"BNOT",
				"NOT",
				"LEN",
				"CONCAT",
				"JMP",
				"EQ",
				"LT",
				"LE",
				"TEST",
				"TESTSET",
				"CALL",
				"TAILCALL",
				"RETURN",
				"FORLOOP",
				"FORPREP",
				"TFORCALL",
				"TFORLOOP",
				"SETLIST",
				"CLOSURE",
				"VARARG",
				"EXTRAARG"
			], t.exports.OpCodesI = {
				OP_MOVE: 0,
				OP_LOADK: 1,
				OP_LOADKX: 2,
				OP_LOADBOOL: 3,
				OP_LOADNIL: 4,
				OP_GETUPVAL: 5,
				OP_GETTABUP: 6,
				OP_GETTABLE: 7,
				OP_SETTABUP: 8,
				OP_SETUPVAL: 9,
				OP_SETTABLE: 10,
				OP_NEWTABLE: 11,
				OP_SELF: 12,
				OP_ADD: 13,
				OP_SUB: 14,
				OP_MUL: 15,
				OP_MOD: 16,
				OP_POW: 17,
				OP_DIV: 18,
				OP_IDIV: 19,
				OP_BAND: 20,
				OP_BOR: 21,
				OP_BXOR: 22,
				OP_SHL: 23,
				OP_SHR: 24,
				OP_UNM: 25,
				OP_BNOT: 26,
				OP_NOT: 27,
				OP_LEN: 28,
				OP_CONCAT: 29,
				OP_JMP: 30,
				OP_EQ: 31,
				OP_LT: 32,
				OP_LE: 33,
				OP_TEST: 34,
				OP_TESTSET: 35,
				OP_CALL: 36,
				OP_TAILCALL: 37,
				OP_RETURN: 38,
				OP_FORLOOP: 39,
				OP_FORPREP: 40,
				OP_TFORCALL: 41,
				OP_TFORLOOP: 42,
				OP_SETLIST: 43,
				OP_CLOSURE: 44,
				OP_VARARG: 45,
				OP_EXTRAARG: 46
			}, t.exports.POS_A = 6, t.exports.POS_Ax = 6, t.exports.POS_B = 23, t.exports.POS_Bx = 14, t.exports.POS_C = 14, t.exports.POS_OP = 0, t.exports.RKASK = function(t) {
				return 256 | t;
			}, t.exports.SETARG_A = function(t, e) {
				return l(t, e, 6, 8);
			}, t.exports.SETARG_Ax = function(t, e) {
				return l(t, e, 6, 26);
			}, t.exports.SETARG_B = function(t, e) {
				return l(t, e, 23, 9);
			}, t.exports.SETARG_Bx = s, t.exports.SETARG_C = function(t, e) {
				return l(t, e, 14, 9);
			}, t.exports.SETARG_sBx = function(t, e) {
				return s(t, e + 131071);
			}, t.exports.SET_OPCODE = function(t, e) {
				return t.code = t.code & u(6, 0) | e << 0 & a(6, 0), o(t);
			}, t.exports.SIZE_A = 8, t.exports.SIZE_Ax = 26, t.exports.SIZE_B = 9, t.exports.SIZE_Bx = 18, t.exports.SIZE_C = 9, t.exports.SIZE_OP = 6, t.exports.fullins = o, t.exports.getBMode = function(t) {
				return r[t] >> 4 & 3;
			}, t.exports.getCMode = function(t) {
				return r[t] >> 2 & 3;
			}, t.exports.getOpMode = function(t) {
				return 3 & r[t];
			}, t.exports.iABC = 0, t.exports.iABx = 1, t.exports.iAsBx = 2, t.exports.iAx = 3, t.exports.testAMode = function(t) {
				return 64 & r[t];
			}, t.exports.testTMode = function(t) {
				return 128 & r[t];
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_VERSION_MAJOR: r, LUA_VERSION_MINOR: a } = n(2), u = "_" + r + "_" + a;
			t.exports.LUA_VERSUFFIX = u, t.exports.lua_assert = function(t) {}, t.exports.luaopen_base = n(24).luaopen_base;
			t.exports.LUA_COLIBNAME = "coroutine", t.exports.luaopen_coroutine = n(25).luaopen_coroutine;
			t.exports.LUA_TABLIBNAME = "table", t.exports.luaopen_table = n(26).luaopen_table;
			t.exports.LUA_OSLIBNAME = "os", t.exports.luaopen_os = n(27).luaopen_os;
			t.exports.LUA_STRLIBNAME = "string", t.exports.luaopen_string = n(28).luaopen_string;
			t.exports.LUA_UTF8LIBNAME = "utf8", t.exports.luaopen_utf8 = n(29).luaopen_utf8;
			t.exports.LUA_BITLIBNAME = "bit32";
			t.exports.LUA_MATHLIBNAME = "math", t.exports.luaopen_math = n(30).luaopen_math;
			t.exports.LUA_DBLIBNAME = "debug", t.exports.luaopen_debug = n(31).luaopen_debug;
			t.exports.LUA_LOADLIBNAME = "package", t.exports.luaopen_package = n(32).luaopen_package;
			t.exports.LUA_FENGARILIBNAME = "fengari", t.exports.luaopen_fengari = n(33).luaopen_fengari;
			const l = n(39);
			t.exports.luaL_openlibs = l.luaL_openlibs;
		},
		function(t, e, n) {
			"use strict";
			const { LUA_MULTRET: r, LUA_OPBNOT: a, LUA_OPEQ: u, LUA_OPLE: l, LUA_OPLT: s, LUA_OPUNM: o, LUA_REGISTRYINDEX: i, LUA_RIDX_GLOBALS: c, LUA_VERSION_NUM: _, constant_types: { LUA_NUMTAGS: f, LUA_TBOOLEAN: p, LUA_TCCL: L, LUA_TFUNCTION: h, LUA_TLCF: d, LUA_TLCL: A, LUA_TLIGHTUSERDATA: g, LUA_TLNGSTR: T, LUA_TNIL: x, LUA_TNONE: b, LUA_TNUMFLT: O, LUA_TNUMINT: k, LUA_TSHRSTR: v, LUA_TTABLE: E, LUA_TTHREAD: U, LUA_TUSERDATA: m }, thread_status: { LUA_OK: N }, from_userstring: R, to_luastring: S } = n(1), { api_check: w } = n(4), I = n(11), y = n(8), { luaU_dump: M } = n(37), P = n(13), C = n(6), D = n(12), { luaS_bless: V, luaS_new: B, luaS_newliteral: G } = n(10), K = n(14), { LUAI_MAXSTACK: F } = n(3), j = n(15), H = n(9), { ZIO: X } = n(19), z = C.TValue, Y = C.CClosure, J = function(t) {
				t.top++, w(t, t.top <= t.ci.top, "stack overflow");
			}, Z = function(t, e) {
				w(t, e < t.top - t.ci.funcOff, "not enough elements in the stack");
			}, q = function(t) {
				if (!t) throw TypeError("invalid argument");
			}, W = function(t) {
				q("number" == typeof t && (0 | t) === t);
			}, Q = function(t) {
				return t !== C.luaO_nilobject;
			}, $ = function(t, e) {
				let n = t.ci;
				if (e > 0) {
					let r = n.funcOff + e;
					return w(t, e <= n.top - (n.funcOff + 1), "unacceptable index"), r >= t.top ? C.luaO_nilobject : t.stack[r];
				}
				return e > i ? (w(t, 0 !== e && -e <= t.top, "invalid index"), t.stack[t.top + e]) : e === i ? t.l_G.l_registry : (w(t, (e = i - e) <= P.MAXUPVAL + 1, "upvalue index too large"), n.func.ttislcf() ? C.luaO_nilobject : e <= n.func.value.nupvalues ? n.func.value.upvalue[e - 1] : C.luaO_nilobject);
			}, tt = function(t, e) {
				let n = t.ci;
				if (e > 0) {
					let r = n.funcOff + e;
					return w(t, e <= n.top - (n.funcOff + 1), "unacceptable index"), r >= t.top ? null : r;
				}
				if (e > i) return w(t, 0 !== e && -e <= t.top, "invalid index"), t.top + e;
				throw Error("attempt to use pseudo-index");
			}, et = function(t, e) {
				let n, r = t.ci.funcOff;
				e >= 0 ? (w(t, e <= t.stack_last - (r + 1), "new top too large"), n = r + 1 + e) : (w(t, -(e + 1) <= t.top - (r + 1), "invalid new top"), n = t.top + e + 1), y.adjust_top(t, n);
			}, nt = function(t, e) {
				et(t, -e - 1);
			}, rt = function(t, e, n) {
				for (; e < n; e++, n--) {
					let r = t.stack[e], a = new z(r.type, r.value);
					C.setobjs2s(t, e, n), C.setobj2s(t, n, a);
				}
			}, at = function(t, e, n) {
				let r = t.top - 1, a = tt(t, e), u = t.stack[a];
				w(t, Q(u) && e > i, "index not in the stack"), w(t, (n >= 0 ? n : -n) <= r - a + 1, "invalid 'n'");
				let l = n >= 0 ? r - n : a - n - 1;
				rt(t, a, l), rt(t, l + 1, t.top - 1), rt(t, a, t.top - 1);
			}, ut = function(t, e, n) {
				let r = $(t, e);
				$(t, n).setfrom(r);
			}, lt = function(t, e, n) {
				if (q("function" == typeof e), W(n), 0 === n) t.stack[t.top] = new z(d, e);
				else {
					Z(t, n), w(t, n <= P.MAXUPVAL, "upvalue index too large");
					let r = new Y(t, e, n);
					for (let e = 0; e < n; e++) r.upvalue[e].setfrom(t.stack[t.top - n + e]);
					for (let e = 1; e < n; e++) delete t.stack[--t.top];
					n > 0 && --t.top, t.stack[t.top].setclCvalue(r);
				}
				J(t);
			}, st = lt, ot = function(t, e) {
				lt(t, e, 0);
			}, it = ot, ct = function(t, e, n) {
				let r = B(t, R(n));
				Z(t, 1), C.pushsvalue2s(t, r), w(t, t.top <= t.ci.top, "stack overflow"), j.settable(t, e, t.stack[t.top - 1], t.stack[t.top - 2]), delete t.stack[--t.top], delete t.stack[--t.top];
			}, _t = function(t, e) {
				ct(t, H.luaH_getint(t.l_G.l_registry.value, c), e);
			}, ft = function(t, e, n) {
				let r = B(t, R(n));
				return C.pushsvalue2s(t, r), w(t, t.top <= t.ci.top, "stack overflow"), j.luaV_gettable(t, e, t.stack[t.top - 1], t.top - 1), t.stack[t.top - 1].ttnov();
			}, pt = function(t, e, n) {
				let r = $(t, e);
				return W(n), w(t, r.ttistable(), "table expected"), C.pushobj2s(t, H.luaH_getint(r.value, n)), w(t, t.top <= t.ci.top, "stack overflow"), t.stack[t.top - 1].ttnov();
			}, Lt = function(t, e, n) {
				let r = new C.TValue(E, H.luaH_new(t));
				t.stack[t.top] = r, J(t);
			}, ht = function(t, e, n) {
				switch (W(n), e.ttype()) {
					case L: {
						let t = e.value;
						return 1 <= n && n <= t.nupvalues ? {
							name: S("", !0),
							val: t.upvalue[n - 1]
						} : null;
					}
					case A: {
						let t = e.value, r = t.p;
						if (!(1 <= n && n <= r.upvalues.length)) return null;
						let a = r.upvalues[n - 1].name;
						return {
							name: a ? a.getstr() : S("(*no name)", !0),
							val: t.upvals[n - 1]
						};
					}
					default: return null;
				}
			}, dt = function(t, e) {
				let n = $(t, e);
				if (!n.ttisstring()) {
					if (!j.cvt2str(n)) return null;
					C.luaO_tostring(t, n);
				}
				return n.svalue();
			}, At = dt, gt = function(t, e) {
				return j.tointeger($(t, e));
			}, Tt = function(t, e) {
				return j.tonumber($(t, e));
			}, xt = /* @__PURE__ */ new WeakMap(), bt = function(t, e) {
				y.luaD_callnoyield(t, e.funcOff, e.nresults);
			}, Ot = function(t, e) {
				let n = $(t, e);
				return Q(n) ? n.ttnov() : b;
			}, kt = S("?"), vt = function(t, e, n) {
				w(t, n === r || t.ci.top - t.top >= n - e, "results from function overflow current stack size");
			}, Et = function(t, e, n, a, u) {
				w(t, null === u || !(t.ci.callstatus & D.CIST_LUA), "cannot use continuations inside hooks"), Z(t, e + 1), w(t, t.status === N, "cannot do calls on non-normal thread"), vt(t, e, n);
				let l = t.top - (e + 1);
				null !== u && 0 === t.nny ? (t.ci.c_k = u, t.ci.c_ctx = a, y.luaD_call(t, l, n)) : y.luaD_callnoyield(t, l, n), n === r && t.ci.top < t.top && (t.ci.top = t.top);
			}, Ut = function(t, e, n, a, u, l) {
				let s, o;
				w(t, null === l || !(t.ci.callstatus & D.CIST_LUA), "cannot use continuations inside hooks"), Z(t, e + 1), w(t, t.status === N, "cannot do calls on non-normal thread"), vt(t, e, n), o = 0 === a ? 0 : tt(t, a);
				let i = t.top - (e + 1);
				if (null === l || t.nny > 0) {
					let e = {
						funcOff: i,
						nresults: n
					};
					s = y.luaD_pcall(t, bt, e, i, o);
				} else {
					let e = t.ci;
					e.c_k = l, e.c_ctx = u, e.extra = i, e.c_old_errfunc = t.errfunc, t.errfunc = o, e.callstatus &= ~D.CIST_OAH | t.allowhook, e.callstatus |= D.CIST_YPCALL, y.luaD_call(t, i, n), e.callstatus &= ~D.CIST_YPCALL, t.errfunc = e.c_old_errfunc, s = N;
				}
				return n === r && t.ci.top < t.top && (t.ci.top = t.top), s;
			}, mt = function(t, e, n) {
				let r = $(t, e);
				w(t, r.ttisLclosure(), "Lua function expected");
				let a = r.value;
				return W(n), w(t, 1 <= n && n <= a.p.upvalues.length, "invalid upvalue index"), {
					f: a,
					i: n - 1
				};
			};
			t.exports.api_incr_top = J, t.exports.api_checknelems = Z, t.exports.lua_absindex = function(t, e) {
				return e > 0 || e <= i ? e : t.top - t.ci.funcOff + e;
			}, t.exports.lua_arith = function(t, e) {
				e !== o && e !== a ? Z(t, 2) : (Z(t, 1), C.pushobj2s(t, t.stack[t.top - 1]), w(t, t.top <= t.ci.top, "stack overflow")), C.luaO_arith(t, e, t.stack[t.top - 2], t.stack[t.top - 1], t.stack[t.top - 2]), delete t.stack[--t.top];
			}, t.exports.lua_atpanic = function(t, e) {
				let n = t.l_G.panic;
				return t.l_G.panic = e, n;
			}, t.exports.lua_atnativeerror = function(t, e) {
				let n = t.l_G.atnativeerror;
				return t.l_G.atnativeerror = e, n;
			}, t.exports.lua_call = function(t, e, n) {
				Et(t, e, n, 0, null);
			}, t.exports.lua_callk = Et, t.exports.lua_checkstack = function(t, e) {
				let n, r = t.ci;
				w(t, e >= 0, "negative 'n'"), t.stack_last - t.top > e ? n = !0 : t.top + D.EXTRA_STACK > F - e ? n = !1 : (y.luaD_growstack(t, e), n = !0);
				return n && r.top < t.top + e && (r.top = t.top + e), n;
			}, t.exports.lua_compare = function(t, e, n, r) {
				let a = $(t, e), o = $(t, n), i = 0;
				if (Q(a) && Q(o)) switch (r) {
					case u:
						i = j.luaV_equalobj(t, a, o);
						break;
					case s:
						i = j.luaV_lessthan(t, a, o);
						break;
					case l:
						i = j.luaV_lessequal(t, a, o);
						break;
					default: w(t, !1, "invalid option");
				}
				return i;
			}, t.exports.lua_concat = function(t, e) {
				Z(t, e), e >= 2 ? j.luaV_concat(t, e) : 0 === e && (C.pushsvalue2s(t, V(t, S("", !0))), w(t, t.top <= t.ci.top, "stack overflow"));
			}, t.exports.lua_copy = ut, t.exports.lua_createtable = Lt, t.exports.lua_dump = function(t, e, n, r) {
				Z(t, 1);
				let a = t.stack[t.top - 1];
				return a.ttisLclosure() ? M(t, a.value.p, e, n, r) : 1;
			}, t.exports.lua_error = function(t) {
				Z(t, 1), I.luaG_errormsg(t);
			}, t.exports.lua_gc = function() {}, t.exports.lua_getallocf = function() {
				return console.warn("lua_getallocf is not available"), 0;
			}, t.exports.lua_getextraspace = function() {
				return console.warn("lua_getextraspace is not available"), 0;
			}, t.exports.lua_getfield = function(t, e, n) {
				return ft(t, $(t, e), n);
			}, t.exports.lua_getglobal = function(t, e) {
				return ft(t, H.luaH_getint(t.l_G.l_registry.value, c), e);
			}, t.exports.lua_geti = function(t, e, n) {
				let r = $(t, e);
				return W(n), t.stack[t.top] = new z(k, n), J(t), j.luaV_gettable(t, r, t.stack[t.top - 1], t.top - 1), t.stack[t.top - 1].ttnov();
			}, t.exports.lua_getmetatable = function(t, e) {
				let n, r = $(t, e), a = !1;
				switch (r.ttnov()) {
					case E:
					case m:
						n = r.value.metatable;
						break;
					default: n = t.l_G.mt[r.ttnov()];
				}
				return null !== n && void 0 !== n && (t.stack[t.top] = new z(E, n), J(t), a = !0), a;
			}, t.exports.lua_gettable = function(t, e) {
				let n = $(t, e);
				return j.luaV_gettable(t, n, t.stack[t.top - 1], t.top - 1), t.stack[t.top - 1].ttnov();
			}, t.exports.lua_gettop = function(t) {
				return t.top - (t.ci.funcOff + 1);
			}, t.exports.lua_getupvalue = function(t, e, n) {
				let r = ht(0, $(t, e), n);
				if (r) {
					let e = r.name, n = r.val;
					return C.pushobj2s(t, n), w(t, t.top <= t.ci.top, "stack overflow"), e;
				}
				return null;
			}, t.exports.lua_getuservalue = function(t, e) {
				let n = $(t, e);
				w(t, n.ttisfulluserdata(), "full userdata expected");
				let r = n.value.uservalue;
				return t.stack[t.top] = new z(r.type, r.value), J(t), t.stack[t.top - 1].ttnov();
			}, t.exports.lua_insert = function(t, e) {
				at(t, e, 1);
			}, t.exports.lua_isboolean = function(t, e) {
				return Ot(t, e) === p;
			}, t.exports.lua_iscfunction = function(t, e) {
				let n = $(t, e);
				return n.ttislcf(n) || n.ttisCclosure();
			}, t.exports.lua_isfunction = function(t, e) {
				return Ot(t, e) === h;
			}, t.exports.lua_isinteger = function(t, e) {
				return $(t, e).ttisinteger();
			}, t.exports.lua_islightuserdata = function(t, e) {
				return Ot(t, e) === g;
			}, t.exports.lua_isnil = function(t, e) {
				return Ot(t, e) === x;
			}, t.exports.lua_isnone = function(t, e) {
				return Ot(t, e) === b;
			}, t.exports.lua_isnoneornil = function(t, e) {
				return Ot(t, e) <= 0;
			}, t.exports.lua_isnumber = function(t, e) {
				return !1 !== j.tonumber($(t, e));
			}, t.exports.lua_isproxy = function(t, e) {
				let n = xt.get(t);
				return !!n && (null === e || e.l_G === n);
			}, t.exports.lua_isstring = function(t, e) {
				let n = $(t, e);
				return n.ttisstring() || j.cvt2str(n);
			}, t.exports.lua_istable = function(t, e) {
				return $(t, e).ttistable();
			}, t.exports.lua_isthread = function(t, e) {
				return Ot(t, e) === U;
			}, t.exports.lua_isuserdata = function(t, e) {
				let n = $(t, e);
				return n.ttisfulluserdata(n) || n.ttislightuserdata();
			}, t.exports.lua_len = function(t, e) {
				let n = $(t, e), r = new z();
				j.luaV_objlen(t, r, n), t.stack[t.top] = r, J(t);
			}, t.exports.lua_load = function(t, e, n, r, a) {
				r = r ? R(r) : kt, null !== a && (a = R(a));
				let u = new X(t, e, n), l = y.luaD_protectedparser(t, u, r, a);
				if (l === N) {
					let e = t.stack[t.top - 1].value;
					if (e.nupvalues >= 1) {
						let n = H.luaH_getint(t.l_G.l_registry.value, c);
						e.upvals[0].setfrom(n);
					}
				}
				return l;
			}, t.exports.lua_newtable = function(t) {
				Lt(t);
			}, t.exports.lua_newuserdata = function(t, e) {
				let n = function(t, e) {
					return new C.Udata(t, e);
				}(t, e);
				return t.stack[t.top] = new C.TValue(m, n), J(t), n.data;
			}, t.exports.lua_next = function(t, e) {
				let n = $(t, e);
				return w(t, n.ttistable(), "table expected"), t.stack[t.top] = new z(), H.luaH_next(t, n.value, t.top - 1) ? (J(t), 1) : (delete t.stack[t.top], delete t.stack[--t.top], 0);
			}, t.exports.lua_pcall = function(t, e, n, r) {
				return Ut(t, e, n, r, 0, null);
			}, t.exports.lua_pcallk = Ut, t.exports.lua_pop = nt, t.exports.lua_pushboolean = function(t, e) {
				t.stack[t.top] = new z(p, !!e), J(t);
			}, t.exports.lua_pushcclosure = lt, t.exports.lua_pushcfunction = ot, t.exports.lua_pushfstring = function(t, e, ...n) {
				return e = R(e), C.luaO_pushvfstring(t, e, n);
			}, t.exports.lua_pushglobaltable = function(t) {
				pt(t, i, c);
			}, t.exports.lua_pushinteger = function(t, e) {
				W(e), t.stack[t.top] = new z(k, e), J(t);
			}, t.exports.lua_pushjsclosure = st, t.exports.lua_pushjsfunction = it, t.exports.lua_pushlightuserdata = function(t, e) {
				t.stack[t.top] = new z(g, e), J(t);
			}, t.exports.lua_pushliteral = function(t, e) {
				if (void 0 === e || null === e) t.stack[t.top] = new z(x, null), t.top++;
				else {
					q("string" == typeof e);
					let n = G(t, e);
					C.pushsvalue2s(t, n), e = n.getstr();
				}
				return w(t, t.top <= t.ci.top, "stack overflow"), e;
			}, t.exports.lua_pushlstring = function(t, e, n) {
				let r;
				return W(n), 0 === n ? (e = S("", !0), r = V(t, e)) : (e = R(e), w(t, e.length >= n, "invalid length to lua_pushlstring"), r = B(t, e.subarray(0, n))), C.pushsvalue2s(t, r), w(t, t.top <= t.ci.top, "stack overflow"), r.value;
			}, t.exports.lua_pushnil = function(t) {
				t.stack[t.top] = new z(x, null), J(t);
			}, t.exports.lua_pushnumber = function(t, e) {
				q("number" == typeof e), t.stack[t.top] = new z(O, e), J(t);
			}, t.exports.lua_pushstring = function(t, e) {
				if (void 0 === e || null === e) t.stack[t.top] = new z(x, null), t.top++;
				else {
					let n = B(t, R(e));
					C.pushsvalue2s(t, n), e = n.getstr();
				}
				return w(t, t.top <= t.ci.top, "stack overflow"), e;
			}, t.exports.lua_pushthread = function(t) {
				return t.stack[t.top] = new z(U, t), J(t), t.l_G.mainthread === t;
			}, t.exports.lua_pushvalue = function(t, e) {
				C.pushobj2s(t, $(t, e)), w(t, t.top <= t.ci.top, "stack overflow");
			}, t.exports.lua_pushvfstring = function(t, e, n) {
				return e = R(e), C.luaO_pushvfstring(t, e, n);
			}, t.exports.lua_rawequal = function(t, e, n) {
				let r = $(t, e), a = $(t, n);
				return Q(r) && Q(a) ? j.luaV_equalobj(null, r, a) : 0;
			}, t.exports.lua_rawget = function(t, e) {
				let n = $(t, e);
				return w(t, n.ttistable(n), "table expected"), C.setobj2s(t, t.top - 1, H.luaH_get(t, n.value, t.stack[t.top - 1])), t.stack[t.top - 1].ttnov();
			}, t.exports.lua_rawgeti = pt, t.exports.lua_rawgetp = function(t, e, n) {
				let r = $(t, e);
				w(t, r.ttistable(), "table expected");
				let a = new z(g, n);
				return C.pushobj2s(t, H.luaH_get(t, r.value, a)), w(t, t.top <= t.ci.top, "stack overflow"), t.stack[t.top - 1].ttnov();
			}, t.exports.lua_rawlen = function(t, e) {
				let n = $(t, e);
				switch (n.ttype()) {
					case v:
					case T: return n.vslen();
					case m: return n.value.len;
					case E: return H.luaH_getn(n.value);
					default: return 0;
				}
			}, t.exports.lua_rawset = function(t, e) {
				Z(t, 2);
				let n = $(t, e);
				w(t, n.ttistable(), "table expected");
				let r = t.stack[t.top - 2], a = t.stack[t.top - 1];
				H.luaH_setfrom(t, n.value, r, a), H.invalidateTMcache(n.value), delete t.stack[--t.top], delete t.stack[--t.top];
			}, t.exports.lua_rawseti = function(t, e, n) {
				W(n), Z(t, 1);
				let r = $(t, e);
				w(t, r.ttistable(), "table expected"), H.luaH_setint(r.value, n, t.stack[t.top - 1]), delete t.stack[--t.top];
			}, t.exports.lua_rawsetp = function(t, e, n) {
				Z(t, 1);
				let r = $(t, e);
				w(t, r.ttistable(), "table expected");
				let a = new z(g, n), u = t.stack[t.top - 1];
				H.luaH_setfrom(t, r.value, a, u), delete t.stack[--t.top];
			}, t.exports.lua_register = function(t, e, n) {
				ot(t, n), _t(t, e);
			}, t.exports.lua_remove = function(t, e) {
				at(t, e, -1), nt(t, 1);
			}, t.exports.lua_replace = function(t, e) {
				ut(t, -1, e), nt(t, 1);
			}, t.exports.lua_rotate = at, t.exports.lua_setallocf = function() {
				return console.warn("lua_setallocf is not available"), 0;
			}, t.exports.lua_setfield = function(t, e, n) {
				ct(t, $(t, e), n);
			}, t.exports.lua_setglobal = _t, t.exports.lua_seti = function(t, e, n) {
				W(n), Z(t, 1);
				let r = $(t, e);
				t.stack[t.top] = new z(k, n), J(t), j.settable(t, r, t.stack[t.top - 1], t.stack[t.top - 2]), delete t.stack[--t.top], delete t.stack[--t.top];
			}, t.exports.lua_setmetatable = function(t, e) {
				let n;
				Z(t, 1);
				let r = $(t, e);
				switch (t.stack[t.top - 1].ttisnil() ? n = null : (w(t, t.stack[t.top - 1].ttistable(), "table expected"), n = t.stack[t.top - 1].value), r.ttnov()) {
					case m:
					case E:
						r.value.metatable = n;
						break;
					default: t.l_G.mt[r.ttnov()] = n;
				}
				return delete t.stack[--t.top], !0;
			}, t.exports.lua_settable = function(t, e) {
				Z(t, 2);
				let n = $(t, e);
				j.settable(t, n, t.stack[t.top - 2], t.stack[t.top - 1]), delete t.stack[--t.top], delete t.stack[--t.top];
			}, t.exports.lua_settop = et, t.exports.lua_setupvalue = function(t, e, n) {
				let r = $(t, e);
				Z(t, 1);
				let a = ht(0, r, n);
				if (a) {
					let e = a.name;
					return a.val.setfrom(t.stack[t.top - 1]), delete t.stack[--t.top], e;
				}
				return null;
			}, t.exports.lua_setuservalue = function(t, e) {
				Z(t, 1);
				let n = $(t, e);
				w(t, n.ttisfulluserdata(), "full userdata expected"), n.value.uservalue.setfrom(t.stack[t.top - 1]), delete t.stack[--t.top];
			}, t.exports.lua_status = function(t) {
				return t.status;
			}, t.exports.lua_stringtonumber = function(t, e) {
				let n = new z(), r = C.luaO_str2num(e, n);
				return 0 !== r && (t.stack[t.top] = n, J(t)), r;
			}, t.exports.lua_toboolean = function(t, e) {
				return !$(t, e).l_isfalse();
			}, t.exports.lua_tocfunction = function(t, e) {
				let n = $(t, e);
				return n.ttislcf() || n.ttisCclosure() ? n.value : null;
			}, t.exports.lua_todataview = function(t, e) {
				let n = dt(t, e);
				return new DataView(n.buffer, n.byteOffset, n.byteLength);
			}, t.exports.lua_tointeger = function(t, e) {
				let n = gt(t, e);
				return !1 === n ? 0 : n;
			}, t.exports.lua_tointegerx = gt, t.exports.lua_tojsstring = function(t, e) {
				let n = $(t, e);
				if (!n.ttisstring()) {
					if (!j.cvt2str(n)) return null;
					C.luaO_tostring(t, n);
				}
				return n.jsstring();
			}, t.exports.lua_tolstring = dt, t.exports.lua_tonumber = function(t, e) {
				let n = Tt(t, e);
				return !1 === n ? 0 : n;
			}, t.exports.lua_tonumberx = Tt, t.exports.lua_topointer = function(t, e) {
				let n = $(t, e);
				switch (n.ttype()) {
					case E:
					case A:
					case L:
					case d:
					case U:
					case m:
					case g: return n.value;
					default: return null;
				}
			}, t.exports.lua_toproxy = function(t, e) {
				let n = $(t, e);
				return function(t, e, n) {
					let r = function(r) {
						w(r, r instanceof D.lua_State && t === r.l_G, "must be from same global state"), r.stack[r.top] = new z(e, n), J(r);
					};
					return xt.set(r, t), r;
				}(t.l_G, n.type, n.value);
			}, t.exports.lua_tostring = At, t.exports.lua_tothread = function(t, e) {
				let n = $(t, e);
				return n.ttisthread() ? n.value : null;
			}, t.exports.lua_touserdata = function(t, e) {
				let n = $(t, e);
				switch (n.ttnov()) {
					case m: return n.value.data;
					case g: return n.value;
					default: return null;
				}
			}, t.exports.lua_type = Ot, t.exports.lua_typename = function(t, e) {
				return w(t, b <= e && e < f, "invalid tag"), K.ttypename(e);
			}, t.exports.lua_upvalueid = function(t, e, n) {
				let r = $(t, e);
				switch (r.ttype()) {
					case A: {
						let r = mt(t, e, n);
						return r.f.upvals[r.i];
					}
					case L: {
						let e = r.value;
						return w(t, (0 | n) === n && n > 0 && n <= e.nupvalues, "invalid upvalue index"), e.upvalue[n - 1];
					}
					default: return w(t, !1, "closure expected"), null;
				}
			}, t.exports.lua_upvaluejoin = function(t, e, n, r, a) {
				let u = mt(t, e, n), l = mt(t, r, a), s = l.f.upvals[l.i];
				u.f.upvals[u.i] = s;
			}, t.exports.lua_version = function(t) {
				return null === t ? _ : t.l_G.version;
			}, t.exports.lua_xmove = function(t, e, n) {
				if (t !== e) {
					Z(t, n), w(t, t.l_G === e.l_G, "moving among independent states"), w(t, e.ci.top - e.top >= n, "stack overflow"), t.top -= n;
					for (let r = 0; r < n; r++) e.stack[e.top] = new C.TValue(), C.setobj2s(e, e.top, t.stack[t.top + r]), delete t.stack[t.top + r], e.top++;
				}
			};
		},
		function(t, e, n) {
			"use strict";
			const { lua_assert: r } = n(4);
			const a = function(t) {
				let e = t.reader(t.L, t.data);
				if (null === e) return -1;
				r(e instanceof Uint8Array, "Should only load binary of array of bytes");
				let n = e.length;
				return 0 === n ? -1 : (t.buffer = e, t.off = 0, t.n = n - 1, t.buffer[t.off++]);
			};
			t.exports.EOZ = -1, t.exports.luaZ_buffer = function(t) {
				return t.buffer.subarray(0, t.n);
			}, t.exports.luaZ_buffremove = function(t, e) {
				t.n -= e;
			}, t.exports.luaZ_fill = a, t.exports.luaZ_read = function(t, e, n, r) {
				for (; r;) {
					if (0 === t.n) {
						if (-1 === a(t)) return r;
						t.n++, t.off--;
					}
					let u = r <= t.n ? r : t.n;
					for (let r = 0; r < u; r++) e[n++] = t.buffer[t.off++];
					t.n -= u, 0 === t.n && (t.buffer = null), r -= u;
				}
				return 0;
			}, t.exports.luaZ_resetbuffer = function(t) {
				t.n = 0;
			}, t.exports.luaZ_resizebuffer = function(t, e, n) {
				let r = new Uint8Array(n);
				e.buffer && r.set(e.buffer), e.buffer = r;
			}, t.exports.MBuffer = class {
				constructor() {
					this.buffer = null, this.n = 0;
				}
			}, t.exports.ZIO = class {
				constructor(t, e, n) {
					this.L = t, r("function" == typeof e, "ZIO requires a reader"), this.reader = e, this.data = n, this.n = 0, this.buffer = null, this.off = 0;
				}
				zgetc() {
					return this.n-- > 0 ? this.buffer[this.off++] : a(this);
				}
			};
		},
		function(t, e, n) {
			"use strict";
			const { constant_types: { LUA_TBOOLEAN: r, LUA_TLNGSTR: a }, thread_status: { LUA_ERRSYNTAX: u }, to_luastring: l } = n(1), { LUA_MINBUFFER: s, MAX_INT: o, lua_assert: i } = n(4), c = n(11), _ = n(8), { lisdigit: f, lislalnum: p, lislalpha: L, lisspace: h, lisxdigit: d } = n(22), A = n(6), { luaS_bless: g, luaS_hash: T, luaS_hashlongstr: x, luaS_new: b } = n(10), O = n(9), { EOZ: k, luaZ_buffer: v, luaZ_buffremove: E, luaZ_resetbuffer: U, luaZ_resizebuffer: m } = n(19), N = l("_ENV", !0), R = {
				TK_AND: 257,
				TK_BREAK: 258,
				TK_DO: 259,
				TK_ELSE: 260,
				TK_ELSEIF: 261,
				TK_END: 262,
				TK_FALSE: 263,
				TK_FOR: 264,
				TK_FUNCTION: 265,
				TK_GOTO: 266,
				TK_IF: 267,
				TK_IN: 268,
				TK_LOCAL: 269,
				TK_NIL: 270,
				TK_NOT: 271,
				TK_OR: 272,
				TK_REPEAT: 273,
				TK_RETURN: 274,
				TK_THEN: 275,
				TK_TRUE: 276,
				TK_UNTIL: 277,
				TK_WHILE: 278,
				TK_IDIV: 279,
				TK_CONCAT: 280,
				TK_DOTS: 281,
				TK_EQ: 282,
				TK_GE: 283,
				TK_LE: 284,
				TK_NE: 285,
				TK_SHL: 286,
				TK_SHR: 287,
				TK_DBCOLON: 288,
				TK_EOS: 289,
				TK_FLT: 290,
				TK_INT: 291,
				TK_NAME: 292,
				TK_STRING: 293
			}, S = [
				"and",
				"break",
				"do",
				"else",
				"elseif",
				"end",
				"false",
				"for",
				"function",
				"goto",
				"if",
				"in",
				"local",
				"nil",
				"not",
				"or",
				"repeat",
				"return",
				"then",
				"true",
				"until",
				"while",
				"//",
				"..",
				"...",
				"==",
				">=",
				"<=",
				"~=",
				"<<",
				">>",
				"::",
				"<eof>",
				"<number>",
				"<integer>",
				"<name>",
				"<string>"
			].map((t, e) => l(t));
			class w {
				constructor() {
					this.r = NaN, this.i = NaN, this.ts = null;
				}
			}
			class I {
				constructor() {
					this.token = NaN, this.seminfo = new w();
				}
			}
			const y = function(t, e) {
				let n = t.buff;
				if (n.n + 1 > n.buffer.length) {
					n.buffer.length >= o / 2 && H(t, l("lexical element too long", !0), 0);
					let e = 2 * n.buffer.length;
					m(t.L, n, e);
				}
				n.buffer[n.n++] = e < 0 ? 255 + e + 1 : e;
			}, M = function(t, e) {
				if (e < 257) return A.luaO_pushfstring(t.L, l("'%c'", !0), e);
				{
					let n = S[e - 257];
					return e < 289 ? A.luaO_pushfstring(t.L, l("'%s'", !0), n) : n;
				}
			}, P = function(t) {
				return 10 === t.current || 13 === t.current;
			}, C = function(t) {
				t.current = t.z.zgetc();
			}, D = function(t) {
				y(t, t.current), C(t);
			}, V = new A.TValue(r, !0), B = function(t, e) {
				let n = t.L, r = b(n, e), u = t.h.strong.get(x(r));
				if (u) r = u.key.tsvalue();
				else {
					let e = new A.TValue(a, r);
					O.luaH_setfrom(n, t.h, e, V);
				}
				return r;
			}, G = function(t) {
				let e = t.current;
				i(P(t)), C(t), P(t) && t.current !== e && C(t), ++t.linenumber >= o && H(t, l("chunk has too many lines", !0), 0);
			}, K = function(t, e) {
				return t.current === e && (C(t), !0);
			}, F = function(t, e) {
				return (t.current === e[0].charCodeAt(0) || t.current === e[1].charCodeAt(0)) && (D(t), !0);
			}, j = function(t, e) {
				let n = "Ee", r = t.current;
				for (i(f(t.current)), D(t), 48 === r && F(t, "xX") && (n = "Pp");;) if (F(t, n) && F(t, "-+"), d(t.current)) D(t);
				else {
					if (46 !== t.current) break;
					D(t);
				}
				let a = new A.TValue();
				return 0 === A.luaO_str2num(v(t.buff), a) && H(t, l("malformed number", !0), 290), a.ttisinteger() ? (e.i = a.value, 291) : (i(a.ttisfloat()), e.r = a.value, 290);
			}, H = function(t, e, n) {
				e = c.luaG_addinfo(t.L, e, t.source, t.linenumber), n && A.luaO_pushfstring(t.L, l("%s near %s"), e, function(t, e) {
					switch (e) {
						case 292:
						case 293:
						case 290:
						case 291: return A.luaO_pushfstring(t.L, l("'%s'", !0), v(t.buff));
						default: return M(t, e);
					}
				}(t, n)), _.luaD_throw(t.L, u);
			}, X = function(t) {
				let e = 0, n = t.current;
				for (i(91 === n || 93 === n), D(t); 61 === t.current;) D(t), e++;
				return t.current === n ? e : -e - 1;
			}, z = function(t, e, n) {
				let r = t.linenumber;
				D(t), P(t) && G(t);
				let a = !1;
				for (; !a;) switch (t.current) {
					case k:
						H(t, l(`unfinished long ${e ? "string" : "comment"} (starting at line ${r})`), 289);
						break;
					case 93:
						X(t) === n && (D(t), a = !0);
						break;
					case 10:
					case 13:
						y(t, 10), G(t), e || U(t.buff);
						break;
					default: e ? D(t) : C(t);
				}
				e && (e.ts = B(t, t.buff.buffer.subarray(2 + n, t.buff.n - (2 + n))));
			}, Y = function(t, e, n) {
				e || (t.current !== k && D(t), H(t, n, 293));
			}, J = function(t) {
				return D(t), Y(t, d(t.current), l("hexadecimal digit expected", !0)), A.luaO_hexavalue(t.current);
			}, Z = function(t) {
				let e = J(t);
				return e = (e << 4) + J(t), E(t.buff, 2), e;
			}, q = function(t) {
				let e = new Uint8Array(A.UTF8BUFFSZ), n = A.luaO_utf8esc(e, function(t) {
					let e = 4;
					D(t), Y(t, 123 === t.current, l("missing '{'", !0));
					let n = J(t);
					for (D(t); d(t.current);) e++, n = (n << 4) + A.luaO_hexavalue(t.current), Y(t, n <= 1114111, l("UTF-8 value too large", !0)), D(t);
					return Y(t, 125 === t.current, l("missing '}'", !0)), C(t), E(t.buff, e), n;
				}(t));
				for (; n > 0; n--) y(t, e[A.UTF8BUFFSZ - n]);
			}, W = function(t) {
				let e, n = 0;
				for (e = 0; e < 3 && f(t.current); e++) n = 10 * n + t.current - 48, D(t);
				return Y(t, n <= 255, l("decimal escape too large", !0)), E(t.buff, e), n;
			}, Q = function(t, e, n) {
				for (D(t); t.current !== e;) switch (t.current) {
					case k:
						H(t, l("unfinished string", !0), 289);
						break;
					case 10:
					case 13:
						H(t, l("unfinished string", !0), 293);
						break;
					case 92: {
						let e, n;
						switch (D(t), t.current) {
							case 97:
								n = 7, e = "read_save";
								break;
							case 98:
								n = 8, e = "read_save";
								break;
							case 102:
								n = 12, e = "read_save";
								break;
							case 110:
								n = 10, e = "read_save";
								break;
							case 114:
								n = 13, e = "read_save";
								break;
							case 116:
								n = 9, e = "read_save";
								break;
							case 118:
								n = 11, e = "read_save";
								break;
							case 120:
								n = Z(t), e = "read_save";
								break;
							case 117:
								q(t), e = "no_save";
								break;
							case 10:
							case 13:
								G(t), n = 10, e = "only_save";
								break;
							case 92:
							case 34:
							case 39:
								n = t.current, e = "read_save";
								break;
							case k:
								e = "no_save";
								break;
							case 122:
								for (E(t.buff, 1), C(t); h(t.current);) P(t) ? G(t) : C(t);
								e = "no_save";
								break;
							default: Y(t, f(t.current), l("invalid escape sequence", !0)), n = W(t), e = "only_save";
						}
						"read_save" === e && C(t), "read_save" !== e && "only_save" !== e || (E(t.buff, 1), y(t, n));
						break;
					}
					default: D(t);
				}
				D(t), n.ts = B(t, t.buff.buffer.subarray(1, t.buff.n - 1));
			}, $ = Object.create(null);
			S.forEach((t, e) => $[T(t)] = e);
			const tt = function(t, e) {
				for (U(t.buff);;) switch (i("number" == typeof t.current), t.current) {
					case 10:
					case 13:
						G(t);
						break;
					case 32:
					case 12:
					case 9:
					case 11:
						C(t);
						break;
					case 45:
						if (C(t), 45 !== t.current) return 45;
						if (C(t), 91 === t.current) {
							let e = X(t);
							if (U(t.buff), e >= 0) {
								z(t, null, e), U(t.buff);
								break;
							}
						}
						for (; !P(t) && t.current !== k;) C(t);
						break;
					case 91: {
						let n = X(t);
						return n >= 0 ? (z(t, e, n), 293) : (-1 !== n && H(t, l("invalid long string delimiter", !0), 293), 91);
					}
					case 61: return C(t), K(t, 61) ? 282 : 61;
					case 60: return C(t), K(t, 61) ? 284 : K(t, 60) ? 286 : 60;
					case 62: return C(t), K(t, 61) ? 283 : K(t, 62) ? 287 : 62;
					case 47: return C(t), K(t, 47) ? 279 : 47;
					case 126: return C(t), K(t, 61) ? 285 : 126;
					case 58: return C(t), K(t, 58) ? 288 : 58;
					case 34:
					case 39: return Q(t, t.current, e), 293;
					case 46: return D(t), K(t, 46) ? K(t, 46) ? 281 : 280 : f(t.current) ? j(t, e) : 46;
					case 48:
					case 49:
					case 50:
					case 51:
					case 52:
					case 53:
					case 54:
					case 55:
					case 56:
					case 57: return j(t, e);
					case k: return 289;
					default:
						if (L(t.current)) {
							do
								D(t);
							while (p(t.current));
							let n = B(t, v(t.buff));
							e.ts = n;
							let r = $[x(n)];
							return void 0 !== r && r <= 22 ? r + 257 : 292;
						}
						{
							let e = t.current;
							return C(t), e;
						}
				}
			};
			t.exports.FIRST_RESERVED = 257, t.exports.LUA_ENV = N, t.exports.LexState = class {
				constructor() {
					this.current = NaN, this.linenumber = NaN, this.lastline = NaN, this.t = new I(), this.lookahead = new I(), this.fs = null, this.L = null, this.z = null, this.buff = null, this.h = null, this.dyd = null, this.source = null, this.envn = null;
				}
			}, t.exports.RESERVED = R, t.exports.isreserved = function(t) {
				let e = $[x(t)];
				return void 0 !== e && e <= 22;
			}, t.exports.luaX_lookahead = function(t) {
				return i(289 === t.lookahead.token), t.lookahead.token = tt(t, t.lookahead.seminfo), t.lookahead.token;
			}, t.exports.luaX_newstring = B, t.exports.luaX_next = function(t) {
				t.lastline = t.linenumber, 289 !== t.lookahead.token ? (t.t.token = t.lookahead.token, t.t.seminfo.i = t.lookahead.seminfo.i, t.t.seminfo.r = t.lookahead.seminfo.r, t.t.seminfo.ts = t.lookahead.seminfo.ts, t.lookahead.token = 289) : t.t.token = tt(t, t.t.seminfo);
			}, t.exports.luaX_setinput = function(t, e, n, r, a) {
				e.t = {
					token: 0,
					seminfo: new w()
				}, e.L = t, e.current = a, e.lookahead = {
					token: 289,
					seminfo: new w()
				}, e.z = n, e.fs = null, e.linenumber = 1, e.lastline = 1, e.source = r, e.envn = g(t, N), m(t, e.buff, s);
			}, t.exports.luaX_syntaxerror = function(t, e) {
				H(t, e, t.t.token);
			}, t.exports.luaX_token2str = M, t.exports.luaX_tokens = S;
		},
		function(t, e, n) {
			"use strict";
			const { lua: r, lauxlib: a, lualib: u, to_luastring: l } = n(0), { LUA_MULTRET: s, LUA_OK: o, LUA_REGISTRYINDEX: i, LUA_RIDX_MAINTHREAD: c, LUA_TBOOLEAN: _, LUA_TFUNCTION: f, LUA_TLIGHTUSERDATA: p, LUA_TNIL: L, LUA_TNONE: h, LUA_TNUMBER: d, LUA_TSTRING: A, LUA_TTABLE: g, LUA_TTHREAD: T, LUA_TUSERDATA: x, lua_atnativeerror: b, lua_call: O, lua_getfield: k, lua_gettable: v, lua_gettop: E, lua_isnil: U, lua_isproxy: m, lua_newuserdata: N, lua_pcall: R, lua_pop: S, lua_pushboolean: w, lua_pushcfunction: I, lua_pushinteger: y, lua_pushlightuserdata: M, lua_pushliteral: P, lua_pushnil: C, lua_pushnumber: D, lua_pushstring: V, lua_pushvalue: B, lua_rawgeti: G, lua_rawgetp: K, lua_rawsetp: F, lua_rotate: j, lua_setfield: H, lua_settable: X, lua_settop: z, lua_toboolean: Y, lua_tojsstring: J, lua_tonumber: Z, lua_toproxy: q, lua_tothread: W, lua_touserdata: Q, lua_type: $ } = r, { luaL_argerror: tt, luaL_checkany: et, luaL_checkoption: nt, luaL_checkstack: rt, luaL_checkudata: at, luaL_error: ut, luaL_getmetafield: lt, luaL_newlib: st, luaL_newmetatable: ot, luaL_requiref: it, luaL_setfuncs: ct, luaL_setmetatable: _t, luaL_testudata: ft, luaL_tolstring: pt } = a, { luaopen_base: Lt } = u;
			const ht = "undefined" != typeof window ? window : "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? self : (0, eval)("this");
			let dt, At, gt;
			if ("undefined" != typeof Reflect) dt = Reflect.apply, At = Reflect.construct, gt = Reflect.deleteProperty;
			else {
				const t = Function.apply, e = Function.bind;
				dt = function(e, n, r) {
					return t.call(e, n, r);
				}, At = function(t, n) {
					switch (n.length) {
						case 0: return new t();
						case 1: return new t(n[0]);
						case 2: return new t(n[0], n[1]);
						case 3: return new t(n[0], n[1], n[2]);
						case 4: return new t(n[0], n[1], n[2], n[3]);
					}
					let r = [null];
					return r.push.apply(r, n), new (e.apply(t, r))();
				}, gt = Function("t", "k", "delete t[k]");
			}
			const Tt = String.prototype.concat.bind(""), xt = function(t) {
				return "object" == typeof t ? null !== t : "function" == typeof t;
			}, bt = l("js object"), Ot = function(t, e) {
				let n = ft(t, e, bt);
				return n ? n.data : void 0;
			}, kt = function(t, e) {
				return at(t, e, bt).data;
			}, vt = function(t, e) {
				N(t).data = e, _t(t, bt);
			}, Et = function(t) {
				G(t, i, c);
				let e = W(t, -1);
				return S(t, 1), e;
			}, Ut = /* @__PURE__ */ new WeakMap(), mt = function(t, e) {
				switch (typeof e) {
					case "undefined":
						C(t);
						break;
					case "number":
						D(t, e);
						break;
					case "string":
						V(t, l(e));
						break;
					case "boolean":
						w(t, e);
						break;
					case "symbol":
						M(t, e);
						break;
					case "function": if (m(e, t)) {
						e(t);
						break;
					}
					case "object": if (null === e) {
						if (K(t, i, null) !== x) throw Error("js library not loaded into lua_State");
						break;
					}
					default: {
						let n = Ut.get(Et(t));
						if (!n) throw Error("js library not loaded into lua_State");
						let r = n.get(e);
						r ? r(t) : (vt(t, e), r = q(t, -1), n.set(e, r));
					}
				}
			}, Nt = function(t) {
				let e = Q(t, 1);
				return mt(t, e), 1;
			}, Rt = function(t, e) {
				switch ($(t, e)) {
					case h:
					case L: return;
					case _: return Y(t, e);
					case p: return Q(t, e);
					case d: return Z(t, e);
					case A: return J(t, e);
					case x: {
						let n = Ot(t, e);
						if (void 0 !== n) return n;
					}
					case g:
					case f:
					case T:
					default: return Bt(t, q(t, e));
				}
			}, St = function(t, e) {
				let n = R(t, e, 1, 0), r = Rt(t, -1);
				switch (S(t, 1), n) {
					case o: return r;
					default: throw r;
				}
			}, wt = function(t, e, n, r, a) {
				if (!xt(r)) throw new TypeError("`args` argument must be an object");
				let u = +r.length;
				u >= 0 || (u = 0), rt(t, 2 + u, null);
				let l = E(t);
				e(t), mt(t, n);
				for (let e = 0; e < u; e++) mt(t, r[e]);
				switch (R(t, 1 + u, a, 0)) {
					case o: {
						let e = E(t) - l, n = new Array(e);
						for (let r = 0; r < e; r++) n[r] = Rt(t, l + r + 1);
						return z(t, l), n;
					}
					default: {
						let e = Rt(t, -1);
						throw z(t, l), e;
					}
				}
			}, It = function(t) {
				return v(t, 1), 1;
			}, yt = function(t, e, n) {
				return rt(t, 3, null), I(t, It), e(t), mt(t, n), St(t, 2);
			}, Mt = function(t, e, n) {
				switch (rt(t, 3, null), I(t, It), e(t), mt(t, n), R(t, 2, 1, 0)) {
					case o: {
						let e = U(t, -1);
						return S(t, 1), !e;
					}
					default: {
						let e = Rt(t, -1);
						throw S(t, 1), e;
					}
				}
			}, Pt = function(t, e, n, r) {
				switch (rt(t, 4, null), I(t, function(t) {
					return X(t, 1), 0;
				}), e(t), mt(t, n), mt(t, r), R(t, 3, 0, 0)) {
					case o: return;
					default: {
						let e = Rt(t, -1);
						throw S(t, 1), e;
					}
				}
			}, Ct = function(t, e, n) {
				switch (rt(t, 4, null), I(t, function(t) {
					return X(t, 1), 0;
				}), e(t), mt(t, n), C(t), R(t, 3, 0, 0)) {
					case o: return;
					default: {
						let e = Rt(t, -1);
						throw S(t, 1), e;
					}
				}
			}, Dt = function(t, e) {
				return rt(t, 2, null), I(t, function(t) {
					return pt(t, 1), 1;
				}), e(t), St(t, 1);
			}, Vt = function() {
				let t = this.L;
				rt(t, 3, null);
				let e = E(t);
				switch (this.iter(t), this.state(t), this.last(t), R(t, 2, s, 0)) {
					case o: {
						let n;
						if (this.last = q(t, e + 1), U(t, -1)) n = {
							done: !0,
							value: void 0
						};
						else {
							let r = E(t) - e, a = new Array(r);
							for (let n = 0; n < r; n++) a[n] = Rt(t, e + n + 1);
							n = {
								done: !1,
								value: a
							};
						}
						return z(t, e), n;
					}
					default: {
						let e = Rt(t, -1);
						throw S(t, 1), e;
					}
				}
			}, Bt = function(t, e) {
				const n = Et(t);
				let r = function() {
					return wt(n, e, this, arguments, 1)[0];
				};
				r.apply = function(t, r) {
					return wt(n, e, t, r, 1)[0];
				}, r.invoke = function(t, r) {
					return wt(n, e, t, r, s);
				}, r.get = function(t) {
					return yt(n, e, t);
				}, r.has = function(t) {
					return Mt(n, e, t);
				}, r.set = function(t, r) {
					return Pt(n, e, t, r);
				}, r.delete = function(t) {
					return Ct(n, e, t);
				}, r.toString = function() {
					return Dt(n, e);
				}, "function" == typeof Symbol && (r[Symbol.toStringTag] = "Fengari object", r[Symbol.iterator] = function() {
					return function(t, e) {
						switch (rt(t, 1, null), I(t, function(t) {
							return it(t, l("_G"), Lt, 0), k(t, -1, l("pairs")), e(t), O(t, 1, 3), 3;
						}), R(t, 0, 3, 0)) {
							case o: {
								let e = q(t, -3), n = q(t, -2), r = q(t, -1);
								return S(t, 3), {
									L: t,
									iter: e,
									state: n,
									last: r,
									next: Vt
								};
							}
							default: {
								let e = Rt(t, -1);
								throw S(t, 1), e;
							}
						}
					}(n, e);
				}, Symbol.toPrimitive && (r[Symbol.toPrimitive] = function(t) {
					if ("string" === t) return Dt(n, e);
				}));
				let a = Ut.get(n);
				if (!a) throw Error("js library not loaded into lua_State");
				return a.set(r, e), r;
			}, Gt = {
				new: function(t) {
					let e = Rt(t, 1), n = E(t) - 1, r = new Array(n);
					for (let e = 0; e < n; e++) r[e] = Rt(t, e + 2);
					return mt(t, At(e, r)), 1;
				},
				tonumber: function(t) {
					let e = Rt(t, 1);
					return D(t, +e), 1;
				},
				tostring: function(t) {
					let e = Rt(t, 1);
					return P(t, Tt(e)), 1;
				},
				instanceof: function(t) {
					let e = Rt(t, 1), n = Rt(t, 2);
					return w(t, e instanceof n), 1;
				},
				typeof: function(t) {
					let e = Rt(t, 1);
					return P(t, typeof e), 1;
				}
			};
			if ("function" == typeof Symbol && Symbol.iterator) {
				const t = function(t, e) {
					let n = kt(t, e), r = n[Symbol.iterator];
					r || tt(t, e, l("object not iterable"));
					let a = dt(r, n, []);
					return xt(a) || tt(t, e, l("Result of the Symbol.iterator method is not an object")), a;
				}, e = function(t) {
					let e = Rt(t, 1).next();
					return e.done ? 0 : (mt(t, e.value), 1);
				};
				Gt.of = function(n) {
					let r = t(n, 1);
					return I(n, e), mt(n, r), 2;
				};
			}
			if ("function" == typeof Proxy && "function" == typeof Symbol) {
				const t = Symbol("lua_State"), e = Symbol("fengari-proxy"), n = {
					apply: function(n, r, a) {
						return wt(n[t], n[e], r, a, 1)[0];
					},
					construct: function(n, r) {
						let a = n[t], u = n[e], s = r.length;
						rt(a, 2 + s, null), u(a);
						let o = E(a);
						if (lt(a, o, l("construct")) === L) throw S(a, 1), /* @__PURE__ */ new TypeError("not a constructor");
						j(a, o, 1);
						for (let t = 0; t < s; t++) mt(a, r[t]);
						return St(a, 1 + s);
					},
					defineProperty: function(n, r, a) {
						let u = n[t], s = n[e];
						return rt(u, 4, null), s(u), lt(u, -1, l("defineProperty")) === L ? (S(u, 1), !1) : (j(u, -2, 1), mt(u, r), mt(u, a), St(u, 3));
					},
					deleteProperty: function(n, r) {
						return Ct(n[t], n[e], r);
					},
					get: function(n, r) {
						return yt(n[t], n[e], r);
					},
					getOwnPropertyDescriptor: function(n, r) {
						let a = n[t], u = n[e];
						if (rt(a, 3, null), u(a), lt(a, -1, l("getOwnPropertyDescriptor")) !== L) return j(a, -2, 1), mt(a, r), St(a, 2);
						S(a, 1);
					},
					getPrototypeOf: function(n) {
						let r = n[t], a = n[e];
						return rt(r, 2, null), a(r), lt(r, -1, l("getPrototypeOf")) === L ? (S(r, 1), null) : (j(r, -2, 1), St(r, 1));
					},
					has: function(n, r) {
						return Mt(n[t], n[e], r);
					},
					ownKeys: function(n) {
						let r = n[t], a = n[e];
						if (rt(r, 2, null), a(r), lt(r, -1, l("ownKeys")) === L) throw S(r, 1), Error("ownKeys unknown for fengari object");
						return j(r, -2, 1), St(r, 1);
					},
					set: function(n, r, a) {
						return Pt(n[t], n[e], r, a), !0;
					},
					setPrototypeOf: function(n, r) {
						let a = n[t], u = n[e];
						return rt(a, 3, null), u(a), lt(a, -1, l("setPrototypeOf")) === L ? (S(a, 1), !1) : (j(a, -2, 1), mt(a, r), St(a, 2));
					}
				}, r = function() {
					let t = function() {}.bind();
					return delete t.length, delete t.name, t;
				}, a = Function("return ()=>void 0;"), u = function() {
					let t = a();
					return delete t.length, delete t.name, t;
				}, s = function(a, l, s) {
					const o = Et(a);
					let i;
					switch (s) {
						case "function":
							i = r();
							break;
						case "arrow_function":
							i = u();
							break;
						case "object":
							i = {};
							break;
						default: throw TypeError("invalid type to createproxy");
					}
					return i[e] = l, i[t] = o, new Proxy(i, n);
				}, o = [
					"function",
					"arrow_function",
					"object"
				], i = o.map((t) => l(t));
				Gt.createproxy = function(t) {
					et(t, 1);
					let e = o[nt(t, 2, i[0], i)], n = s(t, q(t, 1), e);
					return mt(t, n), 1;
				};
			}
			let Kt = {
				__index: function(t) {
					let e = kt(t, 1), n = Rt(t, 2);
					return mt(t, e[n]), 1;
				},
				__newindex: function(t) {
					let e = kt(t, 1), n = Rt(t, 2), r = Rt(t, 3);
					return void 0 === r ? gt(e, n) : e[n] = r, 0;
				},
				__tostring: function(t) {
					let e = kt(t, 1), n = Tt(e);
					return V(t, l(n)), 1;
				},
				__call: function(t) {
					let e, n = kt(t, 1), r = E(t) - 1, a = new Array(Math.max(0, r - 1));
					if (r > 0 && (e = Rt(t, 2), r-- > 0)) for (let e = 0; e < r; e++) a[e] = Rt(t, e + 3);
					return mt(t, dt(n, e, a)), 1;
				},
				__pairs: function(t) {
					let e, n, r, a, u = kt(t, 1);
					if ("function" != typeof Symbol || void 0 === (e = u[Symbol.for("__pairs")])) n = function(t) {
						if (this.index >= this.keys.length) return;
						let e = this.keys[this.index++];
						return [e, this.object[e]];
					}, r = {
						object: u,
						keys: Object.keys(u),
						index: 0
					};
					else {
						let s = dt(e, u, []);
						void 0 === s && ut(t, l("bad '__pairs' result (object with keys 'iter', 'state', 'first' expected)")), void 0 === (n = s.iter) && ut(t, l("bad '__pairs' result (object.iter is missing)")), r = s.state, a = s.first;
					}
					return I(t, function() {
						let e = Rt(t, 1), r = Rt(t, 2), a = dt(n, e, [r]);
						if (void 0 === a) return 0;
						Array.isArray(a) || ut(t, l("bad iterator result (Array or undefined expected)")), rt(t, a.length, null);
						for (let e = 0; e < a.length; e++) mt(t, a[e]);
						return a.length;
					}), mt(t, r), mt(t, a), 3;
				},
				__len: function(t) {
					let e, n, r = kt(t, 1);
					return n = "function" != typeof Symbol || void 0 === (e = r[Symbol.for("__len")]) ? r.length : dt(e, r, []), mt(t, n), 1;
				}
			};
			t.exports.FENGARI_INTEROP_VERSION = "0.1", t.exports.FENGARI_INTEROP_VERSION_NUM = 1, t.exports.FENGARI_INTEROP_RELEASE = "0.1.2", t.exports.checkjs = kt, t.exports.testjs = Ot, t.exports.pushjs = vt, t.exports.push = mt, t.exports.tojs = Rt, t.exports.luaopen_js = function(t) {
				return Ut.set(Et(t), /* @__PURE__ */ new WeakMap()), b(t, Nt), st(t, Gt), P(t, "0.1"), H(t, -2, l("_VERSION")), y(t, 1), H(t, -2, l("_VERSION_NUM")), P(t, "0.1.2"), H(t, -2, l("_RELEASE")), ot(t, bt), ct(t, Kt, 0), S(t, 1), vt(t, null), B(t, -1), F(t, i, null), H(t, -2, l("null")), mt(t, ht), H(t, -2, l("global")), 1;
			};
		},
		function(t, e, n) {
			"use strict";
			const { luastring_of: r } = n(1), a = r(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 8, 8, 8, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 4, 4, 4, 4, 4, 4, 4, 21, 21, 21, 21, 21, 21, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 4, 4, 4, 4, 5, 4, 21, 21, 21, 21, 21, 21, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			t.exports.lisdigit = function(t) {
				return 0 != (2 & a[t + 1]);
			}, t.exports.lislalnum = function(t) {
				return 0 != (3 & a[t + 1]);
			}, t.exports.lislalpha = function(t) {
				return 0 != (1 & a[t + 1]);
			}, t.exports.lisprint = function(t) {
				return 0 != (4 & a[t + 1]);
			}, t.exports.lisspace = function(t) {
				return 0 != (8 & a[t + 1]);
			}, t.exports.lisxdigit = function(t) {
				return 0 != (16 & a[t + 1]);
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_MULTRET: r, to_luastring: a } = n(1), { BinOpr: { OPR_ADD: u, OPR_AND: l, OPR_BAND: s, OPR_BOR: o, OPR_BXOR: i, OPR_CONCAT: c, OPR_DIV: _, OPR_EQ: f, OPR_GE: p, OPR_GT: L, OPR_IDIV: h, OPR_LE: d, OPR_LT: A, OPR_MOD: g, OPR_MUL: T, OPR_NE: x, OPR_NOBINOPR: b, OPR_OR: O, OPR_POW: k, OPR_SHL: v, OPR_SHR: E, OPR_SUB: U }, UnOpr: { OPR_BNOT: m, OPR_LEN: N, OPR_MINUS: R, OPR_NOT: S, OPR_NOUNOPR: w }, NO_JUMP: I, getinstruction: y, luaK_checkstack: M, luaK_codeABC: P, luaK_codeABx: C, luaK_codeAsBx: D, luaK_codek: V, luaK_concat: B, luaK_dischargevars: G, luaK_exp2RK: K, luaK_exp2anyreg: F, luaK_exp2anyregup: j, luaK_exp2nextreg: H, luaK_exp2val: X, luaK_fixline: z, luaK_getlabel: Y, luaK_goiffalse: J, luaK_goiftrue: Z, luaK_indexed: q, luaK_infix: W, luaK_intK: Q, luaK_jump: $, luaK_jumpto: tt, luaK_nil: et, luaK_patchclose: nt, luaK_patchlist: rt, luaK_patchtohere: at, luaK_posfix: ut, luaK_prefix: lt, luaK_reserveregs: st, luaK_ret: ot, luaK_self: it, luaK_setlist: ct, luaK_setmultret: _t, luaK_setoneret: ft, luaK_setreturns: pt, luaK_storevar: Lt, luaK_stringK: ht } = n(35), dt = n(8), At = n(13), gt = n(20), { LUAI_MAXCCALLS: Tt, MAX_INT: xt, lua_assert: bt } = n(4), Ot = n(6), { OpCodesI: { OP_CALL: kt, OP_CLOSURE: vt, OP_FORLOOP: Et, OP_FORPREP: Ut, OP_GETUPVAL: mt, OP_MOVE: Nt, OP_NEWTABLE: Rt, OP_SETTABLE: St, OP_TAILCALL: wt, OP_TFORCALL: It, OP_TFORLOOP: yt, OP_VARARG: Mt }, LFIELDS_PER_FLUSH: Pt, SETARG_B: Ct, SETARG_C: Dt, SET_OPCODE: Vt } = n(16), { luaS_eqlngstr: Bt, luaS_new: Gt, luaS_newliteral: Kt } = n(10), Ft = n(9), jt = At.Proto, Ht = gt.RESERVED, Xt = function(t) {
				return t === Jt.VCALL || t === Jt.VVARARG;
			}, zt = function(t, e) {
				return Bt(t, e);
			};
			class Yt {
				constructor() {
					this.previous = null, this.firstlabel = NaN, this.firstgoto = NaN, this.nactvar = NaN, this.upval = NaN, this.isloop = NaN;
				}
			}
			const Jt = {
				VVOID: 0,
				VNIL: 1,
				VTRUE: 2,
				VFALSE: 3,
				VK: 4,
				VKFLT: 5,
				VKINT: 6,
				VNONRELOC: 7,
				VLOCAL: 8,
				VUPVAL: 9,
				VINDEXED: 10,
				VJMP: 11,
				VRELOCABLE: 12,
				VCALL: 13,
				VVARARG: 14
			};
			class Zt {
				constructor() {
					this.k = NaN, this.u = {
						ival: NaN,
						nval: NaN,
						info: NaN,
						ind: {
							idx: NaN,
							t: NaN,
							vt: NaN
						}
					}, this.t = NaN, this.f = NaN;
				}
				to(t) {
					this.k = t.k, this.u = t.u, this.t = t.t, this.f = t.f;
				}
			}
			class qt {
				constructor() {
					this.f = null, this.prev = null, this.ls = null, this.bl = null, this.pc = NaN, this.lasttarget = NaN, this.jpc = NaN, this.nk = NaN, this.np = NaN, this.firstlocal = NaN, this.nlocvars = NaN, this.nactvar = NaN, this.nups = NaN, this.freereg = NaN;
				}
			}
			class Wt {
				constructor() {
					this.arr = [], this.n = NaN, this.size = NaN;
				}
			}
			const Qt = function(t, e) {
				t.t.token = 0, gt.luaX_syntaxerror(t, e);
			}, $t = function(t, e) {
				gt.luaX_syntaxerror(t, Ot.luaO_pushfstring(t.L, a("%s expected", !0), gt.luaX_token2str(t, e)));
			}, te = function(t, e, n, r) {
				e > n && function(t, e, n) {
					let r = t.ls.L, u = t.f.linedefined, l = 0 === u ? a("main function", !0) : Ot.luaO_pushfstring(r, a("function at line %d", !0), u), s = Ot.luaO_pushfstring(r, a("too many %s (limit is %d) in %s", !0), n, e, l);
					gt.luaX_syntaxerror(t.ls, s);
				}(t, n, r);
			}, ee = function(t, e) {
				return t.t.token === e && (gt.luaX_next(t), !0);
			}, ne = function(t, e) {
				t.t.token !== e && $t(t, e);
			}, re = function(t, e) {
				ne(t, e), gt.luaX_next(t);
			}, ae = function(t, e, n) {
				e || gt.luaX_syntaxerror(t, n);
			}, ue = function(t, e, n, r) {
				ee(t, e) || (r === t.linenumber ? $t(t, e) : gt.luaX_syntaxerror(t, Ot.luaO_pushfstring(t.L, a("%s expected (to close %s at line %d)"), gt.luaX_token2str(t, e), gt.luaX_token2str(t, n), r)));
			}, le = function(t) {
				ne(t, Ht.TK_NAME);
				let e = t.t.seminfo.ts;
				return gt.luaX_next(t), e;
			}, se = function(t, e, n) {
				t.f = t.t = I, t.k = e, t.u.info = n;
			}, oe = function(t, e, n) {
				se(e, Jt.VK, ht(t.fs, n));
			}, ie = function(t, e) {
				oe(t, e, le(t));
			}, ce = function(t, e) {
				let n = t.fs, r = t.dyd, u = function(t, e) {
					let n = t.fs, r = n.f;
					return r.locvars[n.nlocvars] = new Ot.LocVar(), r.locvars[n.nlocvars].varname = e, n.nlocvars++;
				}(t, e);
				te(n, r.actvar.n + 1 - n.firstlocal, 200, a("local variables", !0)), r.actvar.arr[r.actvar.n] = new class {
					constructor() {
						this.idx = NaN;
					}
				}(), r.actvar.arr[r.actvar.n].idx = u, r.actvar.n++;
			}, _e = function(t, e) {
				ce(t, gt.luaX_newstring(t, a(e, !0)));
			}, fe = function(t, e) {
				let n = t.ls.dyd.actvar.arr[t.firstlocal + e].idx;
				return bt(n < t.nlocvars), t.f.locvars[n];
			}, pe = function(t, e) {
				let n = t.fs;
				for (n.nactvar = n.nactvar + e; e; e--) fe(n, n.nactvar - e).startpc = n.pc;
			}, Le = function(t, e, n) {
				let r = t.f;
				return te(t, t.nups + 1, At.MAXUPVAL, a("upvalues", !0)), r.upvalues[t.nups] = {
					instack: n.k === Jt.VLOCAL,
					idx: n.u.info,
					name: e
				}, t.nups++;
			}, he = function(t, e, n, r) {
				if (null === t) se(n, Jt.VVOID, 0);
				else {
					let a = function(t, e) {
						for (let n = t.nactvar - 1; n >= 0; n--) if (zt(e, fe(t, n).varname)) return n;
						return -1;
					}(t, e);
					if (a >= 0) se(n, Jt.VLOCAL, a), r || function(t, e) {
						let n = t.bl;
						for (; n.nactvar > e;) n = n.previous;
						n.upval = 1;
					}(t, a);
					else {
						let r = function(t, e) {
							let n = t.f.upvalues;
							for (let r = 0; r < t.nups; r++) if (zt(n[r].name, e)) return r;
							return -1;
						}(t, e);
						if (r < 0) {
							if (he(t.prev, e, n, 0), n.k === Jt.VVOID) return;
							r = Le(t, e, n);
						}
						se(n, Jt.VUPVAL, r);
					}
				}
			}, de = function(t, e) {
				let n = le(t), r = t.fs;
				if (he(r, n, e, 1), e.k === Jt.VVOID) {
					let a = new Zt();
					he(r, t.envn, e, 1), bt(e.k !== Jt.VVOID), oe(t, a, n), q(r, e, a);
				}
			}, Ae = function(t, e, n, r) {
				let a = t.fs, u = e - n;
				if (Xt(r.k)) ++u < 0 && (u = 0), pt(a, r, u), u > 1 && st(a, u - 1);
				else if (r.k !== Jt.VVOID && H(a, r), u > 0) {
					let t = a.freereg;
					st(a, u), et(a, t, u);
				}
				n > e && (t.fs.freereg -= n - e);
			}, ge = function(t) {
				let e = t.L;
				++e.nCcalls, te(t.fs, e.nCcalls, Tt, a("JS levels", !0));
			}, Te = function(t) {
				return t.L.nCcalls--;
			}, xe = function(t, e, n) {
				let r = t.fs, u = t.dyd.gt, l = u.arr[e];
				if (bt(zt(l.name, n.name)), l.nactvar < n.nactvar) {
					let e = fe(r, l.nactvar).varname, n = Ot.luaO_pushfstring(t.L, a("<goto %s> at line %d jumps into the scope of local '%s'"), l.name.getstr(), l.line, e.getstr());
					Qt(t, n);
				}
				rt(r, l.pc, n.pc);
				for (let t = e; t < u.n - 1; t++) u.arr[t] = u.arr[t + 1];
				u.n--;
			}, be = function(t, e) {
				let n = t.fs.bl, r = t.dyd, a = r.gt.arr[e];
				for (let u = n.firstlabel; u < r.label.n; u++) {
					let l = r.label.arr[u];
					if (zt(l.name, a.name)) return a.nactvar > l.nactvar && (n.upval || r.label.n > n.firstlabel) && nt(t.fs, a.pc, l.nactvar), xe(t, e, l), !0;
				}
				return !1;
			}, Oe = function(t, e, n, r, a) {
				let u = e.n;
				return e.arr[u] = new class {
					constructor() {
						this.name = null, this.pc = NaN, this.line = NaN, this.nactvar = NaN;
					}
				}(), e.arr[u].name = n, e.arr[u].line = r, e.arr[u].nactvar = t.fs.nactvar, e.arr[u].pc = a, e.n = u + 1, u;
			}, ke = function(t, e) {
				let n = t.dyd.gt, r = t.fs.bl.firstgoto;
				for (; r < n.n;) zt(n.arr[r].name, e.name) ? xe(t, r, e) : r++;
			}, ve = function(t, e, n) {
				e.isloop = n, e.nactvar = t.nactvar, e.firstlabel = t.ls.dyd.label.n, e.firstgoto = t.ls.dyd.gt.n, e.upval = 0, e.previous = t.bl, t.bl = e, bt(t.freereg === t.nactvar);
			}, Ee = function(t, e, n) {
				e.prev = t.fs, e.ls = t, t.fs = e, e.pc = 0, e.lasttarget = 0, e.jpc = I, e.freereg = 0, e.nk = 0, e.np = 0, e.nups = 0, e.nlocvars = 0, e.nactvar = 0, e.firstlocal = t.dyd.actvar.n, e.bl = null;
				let r = e.f;
				r.source = t.source, r.maxstacksize = 2, ve(e, n, !1);
			}, Ue = function(t) {
				let e = t.bl, n = t.ls;
				if (e.previous && e.upval) {
					let n = $(t);
					nt(t, n, e.nactvar), at(t, n);
				}
				e.isloop && function(t) {
					let e = Kt(t.L, "break"), n = Oe(t, t.dyd.label, e, 0, t.fs.pc);
					ke(t, t.dyd.label.arr[n]);
				}(n), t.bl = e.previous, function(t, e) {
					for (t.ls.dyd.actvar.n -= t.nactvar - e; t.nactvar > e;) fe(t, --t.nactvar).endpc = t.pc;
				}(t, e.nactvar), bt(e.nactvar === t.nactvar), t.freereg = t.nactvar, n.dyd.label.n = e.firstlabel, e.previous ? function(t, e) {
					let n = e.firstgoto, r = t.ls.dyd.gt;
					for (; n < r.n;) {
						let a = r.arr[n];
						a.nactvar > e.nactvar && (e.upval && nt(t, a.pc, e.nactvar), a.nactvar = e.nactvar), be(t.ls, n) || n++;
					}
				}(t, e) : e.firstgoto < n.dyd.gt.n && function(t, e) {
					let n = gt.isreserved(e.name) ? "<%s> at line %d not inside a loop" : "no visible label '%s' for <goto> at line %d";
					n = Ot.luaO_pushfstring(t.L, a(n), e.name.getstr(), e.line), Qt(t, n);
				}(n, n.dyd.gt.arr[e.firstgoto]);
			}, me = function(t) {
				let e = t.fs;
				ot(e, 0, 0), Ue(e), bt(null === e.bl), t.fs = e.prev;
			}, Ne = function(t, e) {
				switch (t.t.token) {
					case Ht.TK_ELSE:
					case Ht.TK_ELSEIF:
					case Ht.TK_END:
					case Ht.TK_EOS: return !0;
					case Ht.TK_UNTIL: return e;
					default: return !1;
				}
			}, Re = function(t) {
				for (; !Ne(t, 1);) {
					if (t.t.token === Ht.TK_RETURN) return void en(t);
					en(t);
				}
			}, Se = function(t, e) {
				let n = t.fs, r = new Zt();
				j(n, e), gt.luaX_next(t), ie(t, r), q(n, e, r);
			}, we = function(t, e) {
				gt.luaX_next(t), je(t, e), X(t.fs, e), re(t, 93);
			};
			const Ie = function(t, e) {
				let n = t.fs, r = t.fs.freereg, u = new Zt(), l = new Zt();
				t.t.token === Ht.TK_NAME ? (te(n, e.nh, xt, a("items in a constructor", !0)), ie(t, u)) : we(t, u), e.nh++, re(t, 61);
				let s = K(n, u);
				je(t, l), P(n, St, e.t.u.info, s, K(n, l)), n.freereg = r;
			}, ye = function(t, e) {
				e.v.k !== Jt.VVOID && (H(t, e.v), e.v.k = Jt.VVOID, e.tostore === Pt && (ct(t, e.t.u.info, e.na, e.tostore), e.tostore = 0));
			}, Me = function(t, e) {
				je(t, e.v), te(t.fs, e.na, xt, a("items in a constructor", !0)), e.na++, e.tostore++;
			}, Pe = function(t, e) {
				switch (t.t.token) {
					case Ht.TK_NAME:
						61 !== gt.luaX_lookahead(t) ? Me(t, e) : Ie(t, e);
						break;
					case 91:
						Ie(t, e);
						break;
					default: Me(t, e);
				}
			}, Ce = function(t, e) {
				let n = t.fs, a = t.linenumber, u = P(n, Rt, 0, 0, 0), l = new class {
					constructor() {
						this.v = new Zt(), this.t = new Zt(), this.nh = NaN, this.na = NaN, this.tostore = NaN;
					}
				}();
				l.na = l.nh = l.tostore = 0, l.t = e, se(e, Jt.VRELOCABLE, u), se(l.v, Jt.VVOID, 0), H(t.fs, e), re(t, 123);
				do {
					if (bt(l.v.k === Jt.VVOID || l.tostore > 0), 125 === t.t.token) break;
					ye(n, l), Pe(t, l);
				} while (ee(t, 44) || ee(t, 59));
				ue(t, 125, 123, a), function(t, e) {
					0 !== e.tostore && (Xt(e.v.k) ? (_t(t, e.v), ct(t, e.t.u.info, e.na, r), e.na--) : (e.v.k !== Jt.VVOID && H(t, e.v), ct(t, e.t.u.info, e.na, e.tostore)));
				}(n, l), Ct(n.f.code[u], Ot.luaO_int2fb(l.na)), Dt(n.f.code[u], Ot.luaO_int2fb(l.nh));
			}, De = function(t, e, n, r) {
				let u = new qt(), l = new Yt();
				u.f = function(t) {
					let e = t.L, n = new jt(e), r = t.fs;
					return r.f.p[r.np++] = n, n;
				}(t), u.f.linedefined = r, Ee(t, u, l), re(t, 40), n && (_e(t, "self"), pe(t, 1)), function(t) {
					let e = t.fs, n = e.f, r = 0;
					if (n.is_vararg = !1, 41 !== t.t.token) do
						switch (t.t.token) {
							case Ht.TK_NAME:
								ce(t, le(t)), r++;
								break;
							case Ht.TK_DOTS:
								gt.luaX_next(t), n.is_vararg = !0;
								break;
							default: gt.luaX_syntaxerror(t, a("<name> or '...' expected", !0));
						}
					while (!n.is_vararg && ee(t, 44));
					pe(t, r), n.numparams = e.nactvar, st(e, e.nactvar);
				}(t), re(t, 41), Re(t), u.f.lastlinedefined = t.linenumber, ue(t, Ht.TK_END, Ht.TK_FUNCTION, r), function(t, e) {
					let n = t.fs.prev;
					se(e, Jt.VRELOCABLE, C(n, vt, 0, n.np - 1)), H(n, e);
				}(t, e), me(t);
			}, Ve = function(t, e) {
				let n = 1;
				for (je(t, e); ee(t, 44);) H(t.fs, e), je(t, e), n++;
				return n;
			}, Be = function(t, e, n) {
				let u, l = t.fs, s = new Zt();
				switch (t.t.token) {
					case 40:
						gt.luaX_next(t), 41 === t.t.token ? s.k = Jt.VVOID : (Ve(t, s), _t(l, s)), ue(t, 41, 40, n);
						break;
					case 123:
						Ce(t, s);
						break;
					case Ht.TK_STRING:
						oe(t, s, t.t.seminfo.ts), gt.luaX_next(t);
						break;
					default: gt.luaX_syntaxerror(t, a("function arguments expected", !0));
				}
				bt(e.k === Jt.VNONRELOC);
				let o = e.u.info;
				Xt(s.k) ? u = r : (s.k !== Jt.VVOID && H(l, s), u = l.freereg - (o + 1)), se(e, Jt.VCALL, P(l, kt, o, u + 1, 2)), z(l, n), l.freereg = o + 1;
			}, Ge = function(t, e) {
				let n = t.fs, r = t.linenumber;
				for (function(t, e) {
					switch (t.t.token) {
						case 40: {
							let n = t.linenumber;
							gt.luaX_next(t), je(t, e), ue(t, 41, 40, n), G(t.fs, e);
							return;
						}
						case Ht.TK_NAME:
							de(t, e);
							return;
						default: gt.luaX_syntaxerror(t, a("unexpected symbol", !0));
					}
				}(t, e);;) switch (t.t.token) {
					case 46:
						Se(t, e);
						break;
					case 91: {
						let r = new Zt();
						j(n, e), we(t, r), q(n, e, r);
						break;
					}
					case 58: {
						let a = new Zt();
						gt.luaX_next(t), ie(t, a), it(n, e, a), Be(t, e, r);
						break;
					}
					case 40:
					case Ht.TK_STRING:
					case 123:
						H(n, e), Be(t, e, r);
						break;
					default: return;
				}
			}, Ke = [
				{
					left: 10,
					right: 10
				},
				{
					left: 10,
					right: 10
				},
				{
					left: 11,
					right: 11
				},
				{
					left: 11,
					right: 11
				},
				{
					left: 14,
					right: 13
				},
				{
					left: 11,
					right: 11
				},
				{
					left: 11,
					right: 11
				},
				{
					left: 6,
					right: 6
				},
				{
					left: 4,
					right: 4
				},
				{
					left: 5,
					right: 5
				},
				{
					left: 7,
					right: 7
				},
				{
					left: 7,
					right: 7
				},
				{
					left: 9,
					right: 8
				},
				{
					left: 3,
					right: 3
				},
				{
					left: 3,
					right: 3
				},
				{
					left: 3,
					right: 3
				},
				{
					left: 3,
					right: 3
				},
				{
					left: 3,
					right: 3
				},
				{
					left: 3,
					right: 3
				},
				{
					left: 2,
					right: 2
				},
				{
					left: 1,
					right: 1
				}
			], Fe = function(t, e, n) {
				ge(t);
				let r = function(t) {
					switch (t) {
						case Ht.TK_NOT: return S;
						case 45: return R;
						case 126: return m;
						case 35: return N;
						default: return w;
					}
				}(t.t.token);
				if (r !== w) {
					let n = t.linenumber;
					gt.luaX_next(t), Fe(t, e, 12), lt(t.fs, r, e, n);
				} else (function(t, e) {
					switch (t.t.token) {
						case Ht.TK_FLT:
							se(e, Jt.VKFLT, 0), e.u.nval = t.t.seminfo.r;
							break;
						case Ht.TK_INT:
							se(e, Jt.VKINT, 0), e.u.ival = t.t.seminfo.i;
							break;
						case Ht.TK_STRING:
							oe(t, e, t.t.seminfo.ts);
							break;
						case Ht.TK_NIL:
							se(e, Jt.VNIL, 0);
							break;
						case Ht.TK_TRUE:
							se(e, Jt.VTRUE, 0);
							break;
						case Ht.TK_FALSE:
							se(e, Jt.VFALSE, 0);
							break;
						case Ht.TK_DOTS: {
							let n = t.fs;
							ae(t, n.f.is_vararg, a("cannot use '...' outside a vararg function", !0)), se(e, Jt.VVARARG, P(n, Mt, 0, 1, 0));
							break;
						}
						case 123:
							Ce(t, e);
							return;
						case Ht.TK_FUNCTION:
							gt.luaX_next(t), De(t, e, 0, t.linenumber);
							return;
						default:
							Ge(t, e);
							return;
					}
					gt.luaX_next(t);
				})(t, e);
				let I = function(t) {
					switch (t) {
						case 43: return u;
						case 45: return U;
						case 42: return T;
						case 37: return g;
						case 94: return k;
						case 47: return _;
						case Ht.TK_IDIV: return h;
						case 38: return s;
						case 124: return o;
						case 126: return i;
						case Ht.TK_SHL: return v;
						case Ht.TK_SHR: return E;
						case Ht.TK_CONCAT: return c;
						case Ht.TK_NE: return x;
						case Ht.TK_EQ: return f;
						case 60: return A;
						case Ht.TK_LE: return d;
						case 62: return L;
						case Ht.TK_GE: return p;
						case Ht.TK_AND: return l;
						case Ht.TK_OR: return O;
						default: return b;
					}
				}(t.t.token);
				for (; I !== b && Ke[I].left > n;) {
					let n = new Zt(), r = t.linenumber;
					gt.luaX_next(t), W(t.fs, I, e);
					let a = Fe(t, n, Ke[I].right);
					ut(t.fs, I, e, n, r), I = a;
				}
				return Te(t), I;
			}, je = function(t, e) {
				Fe(t, e, 0);
			}, He = function(t) {
				let e = t.fs, n = new Yt();
				ve(e, n, 0), Re(t), Ue(e);
			};
			class Xe {
				constructor() {
					this.prev = null, this.v = new Zt();
				}
			}
			const ze = function(t, e, n) {
				let r = new Zt();
				if (ae(t, function(t) {
					return Jt.VLOCAL <= t && t <= Jt.VINDEXED;
				}(e.v.k), a("syntax error", !0)), ee(t, 44)) {
					let r = new Xe();
					r.prev = e, Ge(t, r.v), r.v.k !== Jt.VINDEXED && function(t, e, n) {
						let r = t.fs, a = r.freereg, u = !1;
						for (; e; e = e.prev) e.v.k === Jt.VINDEXED && (e.v.u.ind.vt === n.k && e.v.u.ind.t === n.u.info && (u = !0, e.v.u.ind.vt = Jt.VLOCAL, e.v.u.ind.t = a), n.k === Jt.VLOCAL && e.v.u.ind.idx === n.u.info && (u = !0, e.v.u.ind.idx = a));
						if (u) {
							let t = n.k === Jt.VLOCAL ? Nt : mt;
							P(r, t, a, n.u.info, 0), st(r, 1);
						}
					}(t, e, r.v), te(t.fs, n + t.L.nCcalls, Tt, a("JS levels", !0)), ze(t, r, n + 1);
				} else {
					re(t, 61);
					let a = Ve(t, r);
					if (a === n) return ft(t.fs, r), void Lt(t.fs, e.v, r);
					Ae(t, n, a, r);
				}
				se(r, Jt.VNONRELOC, t.fs.freereg - 1), Lt(t.fs, e.v, r);
			}, Ye = function(t) {
				let e = new Zt();
				return je(t, e), e.k === Jt.VNIL && (e.k = Jt.VFALSE), Z(t.fs, e), e.f;
			}, Je = function(t, e) {
				let n, r = t.linenumber;
				ee(t, Ht.TK_GOTO) ? n = le(t) : (gt.luaX_next(t), n = Kt(t.L, "break"));
				let a = Oe(t, t.dyd.gt, n, r, e);
				be(t, a);
			}, Ze = function(t, e, n) {
				let r, u = t.fs, l = t.dyd.label;
				(function(t, e, n) {
					for (let r = t.bl.firstlabel; r < e.n; r++) if (zt(n, e.arr[r].name)) {
						let u = Ot.luaO_pushfstring(t.ls.L, a("label '%s' already defined on line %d", !0), n.getstr(), e.arr[r].line);
						Qt(t.ls, u);
					}
				})(u, l, e), re(t, Ht.TK_DBCOLON), r = Oe(t, l, e, n, Y(u)), function(t) {
					for (; 59 === t.t.token || t.t.token === Ht.TK_DBCOLON;) en(t);
				}(t), Ne(t, 0) && (l.arr[r].nactvar = u.bl.nactvar), ke(t, l.arr[r]);
			}, qe = function(t) {
				let e = new Zt();
				return je(t, e), H(t.fs, e), bt(e.k === Jt.VNONRELOC), e.u.info;
			}, We = function(t, e, n, r, a) {
				let u, l = new Yt(), s = t.fs;
				pe(t, 3), re(t, Ht.TK_DO);
				let o = a ? D(s, Ut, e, I) : $(s);
				ve(s, l, 0), pe(t, r), st(s, r), He(t), Ue(s), at(s, o), a ? u = D(s, Et, e, I) : (P(s, It, e, 0, r), z(s, n), u = D(s, yt, e + 2, I)), rt(s, u, o + 1), z(s, n);
			}, Qe = function(t, e) {
				let n = t.fs, r = new Yt();
				ve(n, r, 1), gt.luaX_next(t);
				let u = le(t);
				switch (t.t.token) {
					case 61:
						(function(t, e, n) {
							let r = t.fs, a = r.freereg;
							_e(t, "(for index)"), _e(t, "(for limit)"), _e(t, "(for step)"), ce(t, e), re(t, 61), qe(t), re(t, 44), qe(t), ee(t, 44) ? qe(t) : (V(r, r.freereg, Q(r, 1)), st(r, 1)), We(t, a, n, 1, 1);
						})(t, u, e);
						break;
					case 44:
					case Ht.TK_IN:
						(function(t, e) {
							let n = t.fs, r = new Zt(), a = 4, u = n.freereg;
							for (_e(t, "(for generator)"), _e(t, "(for state)"), _e(t, "(for control)"), ce(t, e); ee(t, 44);) ce(t, le(t)), a++;
							re(t, Ht.TK_IN);
							let l = t.linenumber;
							Ae(t, 3, Ve(t, r), r), M(n, 3), We(t, u, l, a - 3, 0);
						})(t, u);
						break;
					default: gt.luaX_syntaxerror(t, a("'=' or 'in' expected", !0));
				}
				ue(t, Ht.TK_END, Ht.TK_FOR, e), Ue(n);
			}, $e = function(t, e) {
				let n, r = new Yt(), a = t.fs, u = new Zt();
				if (gt.luaX_next(t), je(t, u), re(t, Ht.TK_THEN), t.t.token === Ht.TK_GOTO || t.t.token === Ht.TK_BREAK) {
					for (J(t.fs, u), ve(a, r, !1), Je(t, u.t); ee(t, 59););
					if (Ne(t, 0)) return Ue(a), e;
					n = $(a);
				} else Z(t.fs, u), ve(a, r, !1), n = u.f;
				return Re(t), Ue(a), t.t.token !== Ht.TK_ELSE && t.t.token !== Ht.TK_ELSEIF || (e = B(a, e, $(a))), at(a, n), e;
			}, tn = function(t, e) {
				let n = new Zt(), r = new Zt();
				gt.luaX_next(t);
				let a = function(t, e) {
					let n = 0;
					for (de(t, e); 46 === t.t.token;) Se(t, e);
					return 58 === t.t.token && (n = 1, Se(t, e)), n;
				}(t, n);
				De(t, r, a, e), Lt(t.fs, n, r), z(t.fs, e);
			}, en = function(t) {
				let e = t.linenumber;
				switch (ge(t), t.t.token) {
					case 59:
						gt.luaX_next(t);
						break;
					case Ht.TK_IF:
						(function(t, e) {
							let n = t.fs, r = I;
							for (r = $e(t, r); t.t.token === Ht.TK_ELSEIF;) r = $e(t, r);
							ee(t, Ht.TK_ELSE) && He(t), ue(t, Ht.TK_END, Ht.TK_IF, e), at(n, r);
						})(t, e);
						break;
					case Ht.TK_WHILE:
						(function(t, e) {
							let n = t.fs, r = new Yt();
							gt.luaX_next(t);
							let a = Y(n), u = Ye(t);
							ve(n, r, 1), re(t, Ht.TK_DO), He(t), tt(n, a), ue(t, Ht.TK_END, Ht.TK_WHILE, e), Ue(n), at(n, u);
						})(t, e);
						break;
					case Ht.TK_DO:
						gt.luaX_next(t), He(t), ue(t, Ht.TK_END, Ht.TK_DO, e);
						break;
					case Ht.TK_FOR:
						Qe(t, e);
						break;
					case Ht.TK_REPEAT:
						(function(t, e) {
							let n = t.fs, r = Y(n), a = new Yt(), u = new Yt();
							ve(n, a, 1), ve(n, u, 0), gt.luaX_next(t), Re(t), ue(t, Ht.TK_UNTIL, Ht.TK_REPEAT, e);
							let l = Ye(t);
							u.upval && nt(n, l, u.nactvar), Ue(n), rt(n, l, r), Ue(n);
						})(t, e);
						break;
					case Ht.TK_FUNCTION:
						tn(t, e);
						break;
					case Ht.TK_LOCAL:
						gt.luaX_next(t), ee(t, Ht.TK_FUNCTION) ? function(t) {
							let e = new Zt(), n = t.fs;
							ce(t, le(t)), pe(t, 1), De(t, e, 0, t.linenumber), fe(n, e.u.info).startpc = n.pc;
						}(t) : function(t) {
							let e, n = 0, r = new Zt();
							do
								ce(t, le(t)), n++;
							while (ee(t, 44));
							ee(t, 61) ? e = Ve(t, r) : (r.k = Jt.VVOID, e = 0), Ae(t, n, e, r), pe(t, n);
						}(t);
						break;
					case Ht.TK_DBCOLON:
						gt.luaX_next(t), Ze(t, le(t), e);
						break;
					case Ht.TK_RETURN:
						gt.luaX_next(t), function(t) {
							let e, n, a = t.fs, u = new Zt();
							Ne(t, 1) || 59 === t.t.token ? e = n = 0 : (n = Ve(t, u), Xt(u.k) ? (_t(a, u), u.k === Jt.VCALL && 1 === n && (Vt(y(a, u), wt), bt(y(a, u).A === a.nactvar)), e = a.nactvar, n = r) : 1 === n ? e = F(a, u) : (H(a, u), e = a.nactvar, bt(n === a.freereg - e))), ot(a, e, n), ee(t, 59);
						}(t);
						break;
					case Ht.TK_BREAK:
					case Ht.TK_GOTO:
						Je(t, $(t.fs));
						break;
					default: (function(t) {
						let e = t.fs, n = new Xe();
						Ge(t, n.v), 61 === t.t.token || 44 === t.t.token ? (n.prev = null, ze(t, n, 1)) : (ae(t, n.v.k === Jt.VCALL, a("syntax error", !0)), Dt(y(e, n.v), 1));
					})(t);
				}
				bt(t.fs.f.maxstacksize >= t.fs.freereg && t.fs.freereg >= t.fs.nactvar), t.fs.freereg = t.fs.nactvar, Te(t);
			};
			t.exports.Dyndata = class {
				constructor() {
					this.actvar = {
						arr: [],
						n: NaN,
						size: NaN
					}, this.gt = new Wt(), this.label = new Wt();
				}
			}, t.exports.expkind = Jt, t.exports.expdesc = Zt, t.exports.luaY_parser = function(t, e, n, r, a, u) {
				let l = new gt.LexState(), s = new qt(), o = At.luaF_newLclosure(t, 1);
				return dt.luaD_inctop(t), t.stack[t.top - 1].setclLvalue(o), l.h = Ft.luaH_new(t), dt.luaD_inctop(t), t.stack[t.top - 1].sethvalue(l.h), s.f = o.p = new jt(t), s.f.source = Gt(t, a), l.buff = n, l.dyd = r, r.actvar.n = r.gt.n = r.label.n = 0, gt.luaX_setinput(t, l, e, s.f.source, u), function(t, e) {
					let n = new Yt(), r = new Zt();
					Ee(t, e, n), e.f.is_vararg = !0, se(r, Jt.VLOCAL, 0), Le(e, t.envn, r), gt.luaX_next(t), Re(t), ne(t, Ht.TK_EOS), me(t);
				}(l, s), bt(!s.prev && 1 === s.nups && !l.fs), bt(0 === r.actvar.n && 0 === r.gt.n && 0 === r.label.n), delete t.stack[--t.top], o;
			}, t.exports.vkisinreg = function(t) {
				return t === Jt.VNONRELOC || t === Jt.VLOCAL;
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_MULTRET: r, LUA_OK: a, LUA_TFUNCTION: u, LUA_TNIL: l, LUA_TNONE: s, LUA_TNUMBER: o, LUA_TSTRING: i, LUA_TTABLE: c, LUA_VERSION: _, LUA_YIELD: f, lua_call: p, lua_callk: L, lua_concat: h, lua_error: d, lua_getglobal: A, lua_geti: g, lua_getmetatable: T, lua_gettop: x, lua_insert: b, lua_isnil: O, lua_isnone: k, lua_isstring: v, lua_load: E, lua_next: U, lua_pcallk: m, lua_pop: N, lua_pushboolean: R, lua_pushcfunction: S, lua_pushglobaltable: w, lua_pushinteger: I, lua_pushliteral: y, lua_pushnil: M, lua_pushstring: P, lua_pushvalue: C, lua_rawequal: D, lua_rawget: V, lua_rawlen: B, lua_rawset: G, lua_remove: K, lua_replace: F, lua_rotate: j, lua_setfield: H, lua_setmetatable: X, lua_settop: z, lua_setupvalue: Y, lua_stringtonumber: J, lua_toboolean: Z, lua_tolstring: q, lua_tostring: W, lua_type: Q, lua_typename: $ } = n(2), { luaL_argcheck: tt, luaL_checkany: et, luaL_checkinteger: nt, luaL_checkoption: rt, luaL_checkstack: at, luaL_checktype: ut, luaL_error: lt, luaL_getmetafield: st, luaL_loadbufferx: ot, luaL_loadfile: it, luaL_loadfilex: ct, luaL_optinteger: _t, luaL_optstring: ft, luaL_setfuncs: pt, luaL_tolstring: Lt, luaL_where: ht } = n(7), { to_jsstring: dt, to_luastring: At } = n(5);
			let gt, Tt;
			if ("function" == typeof TextDecoder) {
				let t = "", e = new TextDecoder("utf-8");
				gt = function(n) {
					t += e.decode(n, { stream: !0 });
				};
				let n = /* @__PURE__ */ new Uint8Array(0);
				Tt = function() {
					t += e.decode(n), console.log(t), t = "";
				};
			} else {
				let t = [];
				gt = function(e) {
					try {
						e = dt(e);
					} catch (t) {
						let n = new Uint8Array(e.length);
						n.set(e), e = n;
					}
					t.push(e);
				}, Tt = function() {
					console.log.apply(console.log, t), t = [];
				};
			}
			const xt = [
				"stop",
				"restart",
				"collect",
				"count",
				"step",
				"setpause",
				"setstepmul",
				"isrunning"
			].map((t) => At(t)), bt = function(t) {
				return ut(t, 1, c), z(t, 2), U(t, 1) ? 2 : (M(t), 1);
			}, Ot = function(t) {
				let e = nt(t, 2) + 1;
				return I(t, e), g(t, 1, e) === l ? 1 : 2;
			}, kt = function(t) {
				let e = _t(t, 2, 1);
				return z(t, 1), Q(t, 1) === i && e > 0 && (ht(t, e), C(t, 1), h(t, 2)), d(t);
			}, vt = function(t, e, n) {
				return e !== a && e !== f ? (R(t, 0), C(t, -2), 2) : x(t) - n;
			}, Et = function(t, e, n) {
				return e === a ? (0 !== n && (C(t, n), Y(t, -2, 1) || N(t, 1)), 1) : (M(t), b(t, -2), 2);
			}, Ut = function(t, e) {
				return at(t, 2, "too many nested functions"), C(t, 1), p(t, 0, 1), O(t, -1) ? (N(t, 1), null) : (v(t, -1) || lt(t, At("reader function must return a string")), F(t, 5), W(t, 5));
			}, mt = function(t, e, n) {
				return x(t) - 1;
			}, Nt = {
				assert: function(t) {
					return Z(t, 1) ? x(t) : (et(t, 1), K(t, 1), y(t, "assertion failed!"), z(t, 1), kt(t));
				},
				collectgarbage: function(t) {
					rt(t, 1, "collect", xt), _t(t, 2, 0), lt(t, At("lua_gc not implemented"));
				},
				dofile: function(t) {
					let e = ft(t, 1, null);
					return z(t, 1), it(t, e) !== a ? d(t) : (L(t, 0, r, 0, mt), mt(t));
				},
				error: kt,
				getmetatable: function(t) {
					return et(t, 1), T(t, 1) ? (st(t, 1, At("__metatable", !0)), 1) : (M(t), 1);
				},
				ipairs: function(t) {
					return et(t, 1), S(t, Ot), C(t, 1), I(t, 0), 3;
				},
				load: function(t) {
					let e, n = W(t, 1), r = ft(t, 3, "bt"), a = k(t, 4) ? 0 : 4;
					if (null !== n) {
						let a = ft(t, 2, n);
						e = ot(t, n, n.length, a, r);
					} else {
						let n = ft(t, 2, "=(load)");
						ut(t, 1, u), z(t, 5), e = E(t, Ut, null, n, r);
					}
					return Et(t, e, a);
				},
				loadfile: function(t) {
					let e = ft(t, 1, null), n = ft(t, 2, null), r = k(t, 3) ? 0 : 3, a = ct(t, e, n);
					return Et(t, a, r);
				},
				next: bt,
				pairs: function(t) {
					return function(t, e, n, r) {
						return et(t, 1), st(t, 1, e) === l ? (S(t, r), C(t, 1), n ? I(t, 0) : M(t)) : (C(t, 1), p(t, 1, 3)), 3;
					}(t, At("__pairs", !0), 0, bt);
				},
				pcall: function(t) {
					et(t, 1), R(t, 1), b(t, 1);
					let e = m(t, x(t) - 2, r, 0, 0, vt);
					return vt(t, e, 0);
				},
				print: function(t) {
					let e = x(t);
					A(t, At("tostring", !0));
					for (let n = 1; n <= e; n++) {
						C(t, -1), C(t, n), p(t, 1, 1);
						let e = q(t, -1);
						if (null === e) return lt(t, At("'tostring' must return a string to 'print'"));
						n > 1 && gt(At("	")), gt(e), N(t, 1);
					}
					return Tt(), 0;
				},
				rawequal: function(t) {
					return et(t, 1), et(t, 2), R(t, D(t, 1, 2)), 1;
				},
				rawget: function(t) {
					return ut(t, 1, c), et(t, 2), z(t, 2), V(t, 1), 1;
				},
				rawlen: function(t) {
					let e = Q(t, 1);
					return tt(t, e === c || e === i, 1, "table or string expected"), I(t, B(t, 1)), 1;
				},
				rawset: function(t) {
					return ut(t, 1, c), et(t, 2), et(t, 3), z(t, 3), G(t, 1), 1;
				},
				select: function(t) {
					let e = x(t);
					if (Q(t, 1) === i && 35 === W(t, 1)[0]) return I(t, e - 1), 1;
					{
						let n = nt(t, 1);
						return n < 0 ? n = e + n : n > e && (n = e), tt(t, 1 <= n, 1, "index out of range"), e - n;
					}
				},
				setmetatable: function(t) {
					let e = Q(t, 2);
					return ut(t, 1, c), tt(t, e === l || e === c, 2, "nil or table expected"), st(t, 1, At("__metatable", !0)) !== l ? lt(t, At("cannot change a protected metatable")) : (z(t, 2), X(t, 1), 1);
				},
				tonumber: function(t) {
					if (Q(t, 2) <= 0) {
						if (et(t, 1), Q(t, 1) === o) return z(t, 1), 1;
						{
							let e = W(t, 1);
							if (null !== e && J(t, e) === e.length + 1) return 1;
						}
					} else {
						let e = nt(t, 2);
						ut(t, 1, i);
						let n = W(t, 1);
						tt(t, 2 <= e && e <= 36, 2, "base out of range");
						let r = function(t, e) {
							try {
								t = dt(t);
							} catch (t) {
								return null;
							}
							let n = /^[\t\v\f \n\r]*([+-]?)0*([0-9A-Za-z]+)[\t\v\f \n\r]*$/.exec(t);
							if (!n) return null;
							let r = parseInt(n[1] + n[2], e);
							return isNaN(r) ? null : 0 | r;
						}(n, e);
						if (null !== r) return I(t, r), 1;
					}
					return M(t), 1;
				},
				tostring: function(t) {
					return et(t, 1), Lt(t, 1), 1;
				},
				type: function(t) {
					let e = Q(t, 1);
					return tt(t, e !== s, 1, "value expected"), P(t, $(t, e)), 1;
				},
				xpcall: function(t) {
					let e = x(t);
					ut(t, 2, u), R(t, 1), C(t, 1), j(t, 3, 2);
					let n = m(t, e - 2, r, 2, 2, vt);
					return vt(t, n, 2);
				}
			};
			t.exports.luaopen_base = function(t) {
				return w(t), pt(t, Nt, 0), C(t, -1), H(t, -2, At("_G")), y(t, _), H(t, -2, At("_VERSION")), 1;
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_OK: r, LUA_TFUNCTION: a, LUA_TSTRING: u, LUA_YIELD: l, lua_Debug: s, lua_checkstack: o, lua_concat: i, lua_error: c, lua_getstack: _, lua_gettop: f, lua_insert: p, lua_isyieldable: L, lua_newthread: h, lua_pop: d, lua_pushboolean: A, lua_pushcclosure: g, lua_pushliteral: T, lua_pushthread: x, lua_pushvalue: b, lua_resume: O, lua_status: k, lua_tothread: v, lua_type: E, lua_upvalueindex: U, lua_xmove: m, lua_yield: N } = n(2), { luaL_argcheck: R, luaL_checktype: S, luaL_newlib: w, luaL_where: I } = n(7), y = function(t) {
				let e = v(t, 1);
				return R(t, e, 1, "thread expected"), e;
			}, M = function(t, e, n) {
				if (!o(e, n)) return T(t, "too many arguments to resume"), -1;
				if (k(e) === r && 0 === f(e)) return T(t, "cannot resume dead coroutine"), -1;
				m(t, e, n);
				let a = O(e, t, n);
				if (a === r || a === l) {
					let n = f(e);
					return o(t, n + 1) ? (m(e, t, n), n) : (d(e, n), T(t, "too many results to resume"), -1);
				}
				return m(e, t, 1), -1;
			}, P = function(t) {
				let e = v(t, U(1)), n = M(t, e, f(t));
				return n < 0 ? (E(t, -1) === u && (I(t, 1), p(t, -2), i(t, 2)), c(t)) : n;
			}, C = function(t) {
				S(t, 1, a);
				let e = h(t);
				return b(t, 1), m(t, e, 1), 1;
			}, D = {
				create: C,
				isyieldable: function(t) {
					return A(t, L(t)), 1;
				},
				resume: function(t) {
					let e = y(t), n = M(t, e, f(t) - 1);
					return n < 0 ? (A(t, 0), p(t, -2), 2) : (A(t, 1), p(t, -(n + 1)), n + 1);
				},
				running: function(t) {
					return A(t, x(t)), 2;
				},
				status: function(t) {
					let e = y(t);
					if (t === e) T(t, "running");
					else switch (k(e)) {
						case l:
							T(t, "suspended");
							break;
						case r: {
							let n = new s();
							_(e, 0, n) > 0 ? T(t, "normal") : 0 === f(e) ? T(t, "dead") : T(t, "suspended");
							break;
						}
						default: T(t, "dead");
					}
					return 1;
				},
				wrap: function(t) {
					return C(t), g(t, P, 1), 1;
				},
				yield: function(t) {
					return N(t, f(t));
				}
			};
			t.exports.luaopen_coroutine = function(t) {
				return w(t, D), 1;
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_MAXINTEGER: r } = n(3), { LUA_OPEQ: a, LUA_OPLT: u, LUA_TFUNCTION: l, LUA_TNIL: s, LUA_TTABLE: o, lua_call: i, lua_checkstack: c, lua_compare: _, lua_createtable: f, lua_geti: p, lua_getmetatable: L, lua_gettop: h, lua_insert: d, lua_isnil: A, lua_isnoneornil: g, lua_isstring: T, lua_pop: x, lua_pushinteger: b, lua_pushnil: O, lua_pushstring: k, lua_pushvalue: v, lua_rawget: E, lua_setfield: U, lua_seti: m, lua_settop: N, lua_toboolean: R, lua_type: S } = n(2), { luaL_Buffer: w, luaL_addlstring: I, luaL_addvalue: y, luaL_argcheck: M, luaL_buffinit: P, luaL_checkinteger: C, luaL_checktype: D, luaL_error: V, luaL_len: B, luaL_newlib: G, luaL_opt: K, luaL_optinteger: F, luaL_optlstring: j, luaL_pushresult: H, luaL_typename: X } = n(7), z = n(17), { to_luastring: Y } = n(5), J = function(t, e, n) {
				return k(t, e), E(t, -n) !== s;
			}, Z = function(t, e, n) {
				if (S(t, e) !== o) {
					let r = 1;
					!L(t, e) || 1 & n && !J(t, Y("__index", !0), ++r) || 2 & n && !J(t, Y("__newindex", !0), ++r) || 4 & n && !J(t, Y("__len", !0), ++r) ? D(t, e, o) : x(t, r);
				}
			}, q = function(t, e, n) {
				return Z(t, e, 4 | n), B(t, e);
			}, W = function(t, e, n) {
				p(t, 1, n), T(t, -1) || V(t, Y("invalid value (%s) at index %d in table for 'concat'"), X(t, -1), n), y(e);
			}, Q = function(t, e, n) {
				m(t, 1, e), m(t, 1, n);
			}, $ = function(t, e, n) {
				if (A(t, 2)) return _(t, e, n, u);
				{
					v(t, 2), v(t, e - 1), v(t, n - 2), i(t, 2, 1);
					let r = R(t, -1);
					return x(t, 1), r;
				}
			}, tt = function(t, e, n) {
				let r = e, a = n - 1;
				for (;;) {
					for (; p(t, 1, ++r), $(t, -1, -2);) r == n - 1 && V(t, Y("invalid order function for sorting")), x(t, 1);
					for (; p(t, 1, --a), $(t, -3, -1);) a < r && V(t, Y("invalid order function for sorting")), x(t, 1);
					if (a < r) return x(t, 1), Q(t, n - 1, r), r;
					Q(t, r, a);
				}
			}, et = function(t, e, n) {
				let r = Math.floor((e - t) / 4), a = n % (2 * r) + (t + r);
				return z.lua_assert(t + r <= a && a <= e - r), a;
			}, nt = function(t, e, n, r) {
				for (; e < n;) {
					if (p(t, 1, e), p(t, 1, n), $(t, -1, -2) ? Q(t, e, n) : x(t, 2), n - e == 1) return;
					let a, u;
					if (a = n - e < 100 || 0 === r ? Math.floor((e + n) / 2) : et(e, n, r), p(t, 1, a), p(t, 1, e), $(t, -2, -1) ? Q(t, a, e) : (x(t, 1), p(t, 1, n), $(t, -1, -2) ? Q(t, a, n) : x(t, 2)), n - e == 2) return;
					p(t, 1, a), v(t, -1), p(t, 1, n - 1), Q(t, a, n - 1), (a = tt(t, e, n)) - e < n - a ? (nt(t, e, a - 1, r), u = a - e, e = a + 1) : (nt(t, a + 1, n, r), u = n - a, n = a - 1), (n - e) / 128 > u && (r = Math.floor(4294967296 * Math.random()));
				}
			}, rt = {
				concat: function(t) {
					let e = q(t, 1, 1), n = j(t, 2, ""), r = n.length, a = F(t, 3, 1);
					e = F(t, 4, e);
					let u = new w();
					for (P(t, u); a < e; a++) W(t, u, a), I(u, n, r);
					return a === e && W(t, u, a), H(u), 1;
				},
				insert: function(t) {
					let e, n = q(t, 1, 3) + 1;
					switch (h(t)) {
						case 2:
							e = n;
							break;
						case 3:
							e = C(t, 2), M(t, 1 <= e && e <= n, 2, "position out of bounds");
							for (let r = n; r > e; r--) p(t, 1, r - 1), m(t, 1, r);
							break;
						default: return V(t, "wrong number of arguments to 'insert'");
					}
					return m(t, 1, e), 0;
				},
				move: function(t) {
					let e = C(t, 2), n = C(t, 3), u = C(t, 4), l = g(t, 5) ? 1 : 5;
					if (Z(t, 1, 1), Z(t, l, 2), n >= e) {
						M(t, e > 0 || n < r + e, 3, "too many elements to move");
						let s = n - e + 1;
						if (M(t, u <= r - s + 1, 4, "destination wrap around"), u > n || u <= e || 1 !== l && 1 !== _(t, 1, l, a)) for (let n = 0; n < s; n++) p(t, 1, e + n), m(t, l, u + n);
						else for (let n = s - 1; n >= 0; n--) p(t, 1, e + n), m(t, l, u + n);
					}
					return v(t, l), 1;
				},
				pack: function(t) {
					let e = h(t);
					f(t, e, 1), d(t, 1);
					for (let n = e; n >= 1; n--) m(t, 1, n);
					return b(t, e), U(t, 1, Y("n")), 1;
				},
				remove: function(t) {
					let e = q(t, 1, 3), n = F(t, 2, e);
					for (n !== e && M(t, 1 <= n && n <= e + 1, 1, "position out of bounds"), p(t, 1, n); n < e; n++) p(t, 1, n + 1), m(t, 1, n);
					return O(t), m(t, 1, n), 1;
				},
				sort: function(t) {
					let e = q(t, 1, 3);
					return e > 1 && (M(t, e < r, 1, "array too big"), g(t, 2) || D(t, 2, l), N(t, 2), nt(t, 1, e, 0)), 0;
				},
				unpack: function(t) {
					let e = F(t, 2, 1), n = K(t, C, 3, B(t, 1));
					if (e > n) return 0;
					let r = n - e;
					if (r >= Number.MAX_SAFE_INTEGER || !c(t, ++r)) return V(t, Y("too many results to unpack"));
					for (; e < n; e++) p(t, 1, e);
					return p(t, 1, n), r;
				}
			};
			t.exports.luaopen_table = function(t) {
				return G(t, rt), 1;
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_TNIL: r, LUA_TTABLE: a, lua_close: u, lua_createtable: l, lua_getfield: s, lua_isboolean: o, lua_isnoneornil: i, lua_pop: c, lua_pushboolean: _, lua_pushfstring: f, lua_pushinteger: p, lua_pushliteral: L, lua_pushnil: h, lua_pushnumber: d, lua_pushstring: A, lua_setfield: g, lua_settop: T, lua_toboolean: x, lua_tointegerx: b } = n(2), { luaL_Buffer: O, luaL_addchar: k, luaL_addstring: v, luaL_argerror: E, luaL_buffinit: U, luaL_checkinteger: m, luaL_checkstring: N, luaL_checktype: R, luaL_error: S, luaL_execresult: w, luaL_fileresult: I, luaL_newlib: y, luaL_optinteger: M, luaL_optlstring: P, luaL_optstring: C, luaL_pushresult: D } = n(7), { luastring_eq: V, to_jsstring: B, to_luastring: G } = n(5), K = G("aAbBcCdDeFhHIjklmMnpPrRStTuUwWxXyYzZ%"), F = function(t, e, n) {
				p(t, n), g(t, -2, G(e, !0));
			}, j = function(t, e, n) {
				F(t, "sec", n ? e.getUTCSeconds() : e.getSeconds()), F(t, "min", n ? e.getUTCMinutes() : e.getMinutes()), F(t, "hour", n ? e.getUTCHours() : e.getHours()), F(t, "day", n ? e.getUTCDate() : e.getDate()), F(t, "month", (n ? e.getUTCMonth() : e.getMonth()) + 1), F(t, "year", n ? e.getUTCFullYear() : e.getFullYear()), F(t, "wday", (n ? e.getUTCDay() : e.getDay()) + 1), F(t, "yday", Math.floor((e - new Date(e.getFullYear(), 0, 0)) / 864e5));
			}, H = Number.MAX_SAFE_INTEGER / 2, X = function(t, e, n, a) {
				let u = s(t, -1, G(e, !0)), l = b(t, -1);
				if (!1 === l) {
					if (u !== r) return S(t, G("field '%s' is not an integer"), e);
					if (n < 0) return S(t, G("field '%s' missing in date table"), e);
					l = n;
				} else {
					if (!(-H <= l && l <= H)) return S(t, G("field '%s' is out-of-bound"), e);
					l -= a;
				}
				return c(t, 1), l;
			}, z = {
				days: [
					"Sunday",
					"Monday",
					"Tuesday",
					"Wednesday",
					"Thursday",
					"Friday",
					"Saturday"
				].map((t) => G(t)),
				shortDays: [
					"Sun",
					"Mon",
					"Tue",
					"Wed",
					"Thu",
					"Fri",
					"Sat"
				].map((t) => G(t)),
				months: [
					"January",
					"February",
					"March",
					"April",
					"May",
					"June",
					"July",
					"August",
					"September",
					"October",
					"November",
					"December"
				].map((t) => G(t)),
				shortMonths: [
					"Jan",
					"Feb",
					"Mar",
					"Apr",
					"May",
					"Jun",
					"Jul",
					"Aug",
					"Sep",
					"Oct",
					"Nov",
					"Dec"
				].map((t) => G(t)),
				AM: G("AM"),
				PM: G("PM"),
				am: G("am"),
				pm: G("pm"),
				formats: {
					c: G("%a %b %e %H:%M:%S %Y"),
					D: G("%m/%d/%y"),
					F: G("%Y-%m-%d"),
					R: G("%H:%M"),
					r: G("%I:%M:%S %p"),
					T: G("%H:%M:%S"),
					X: G("%T"),
					x: G("%D")
				}
			}, Y = function(t, e) {
				let n = t.getDay();
				"monday" === e && (0 === n ? n = 6 : n--);
				let r = (t - new Date(t.getFullYear(), 0, 1)) / 864e5;
				return Math.floor((r + 7 - n) / 7);
			}, J = function(t, e, n) {
				e < 10 && k(t, n), v(t, G(String(e)));
			}, Z = function(t, e, n, r) {
				let a = 0;
				for (; a < n.length;) if (37 !== n[a]) k(e, n[a++]);
				else {
					let u = q(t, n, ++a);
					switch (n[a]) {
						case 37:
							k(e, 37);
							break;
						case 65:
							v(e, z.days[r.getDay()]);
							break;
						case 66:
							v(e, z.months[r.getMonth()]);
							break;
						case 67:
							J(e, Math.floor(r.getFullYear() / 100), 48);
							break;
						case 68:
							Z(t, e, z.formats.D, r);
							break;
						case 70:
							Z(t, e, z.formats.F, r);
							break;
						case 72:
							J(e, r.getHours(), 48);
							break;
						case 73:
							J(e, (r.getHours() + 11) % 12 + 1, 48);
							break;
						case 77:
							J(e, r.getMinutes(), 48);
							break;
						case 80:
							v(e, r.getHours() < 12 ? z.am : z.pm);
							break;
						case 82:
							Z(t, e, z.formats.R, r);
							break;
						case 83:
							J(e, r.getSeconds(), 48);
							break;
						case 84:
							Z(t, e, z.formats.T, r);
							break;
						case 85:
							J(e, Y(r, "sunday"), 48);
							break;
						case 87:
							J(e, Y(r, "monday"), 48);
							break;
						case 88:
							Z(t, e, z.formats.X, r);
							break;
						case 89:
							v(e, G(String(r.getFullYear())));
							break;
						case 90: {
							let t = r.toString().match(/\(([\w\s]+)\)/);
							t && v(e, G(t[1]));
							break;
						}
						case 97:
							v(e, z.shortDays[r.getDay()]);
							break;
						case 98:
						case 104:
							v(e, z.shortMonths[r.getMonth()]);
							break;
						case 99:
							Z(t, e, z.formats.c, r);
							break;
						case 100:
							J(e, r.getDate(), 48);
							break;
						case 101:
							J(e, r.getDate(), 32);
							break;
						case 106: {
							let t = Math.floor((r - new Date(r.getFullYear(), 0, 1)) / 864e5);
							t < 100 && (t < 10 && k(e, 48), k(e, 48)), v(e, G(String(t)));
							break;
						}
						case 107:
							J(e, r.getHours(), 32);
							break;
						case 108:
							J(e, (r.getHours() + 11) % 12 + 1, 32);
							break;
						case 109:
							J(e, r.getMonth() + 1, 48);
							break;
						case 110:
							k(e, 10);
							break;
						case 112:
							v(e, r.getHours() < 12 ? z.AM : z.PM);
							break;
						case 114:
							Z(t, e, z.formats.r, r);
							break;
						case 115:
							v(e, G(String(Math.floor(r / 1e3))));
							break;
						case 116:
							k(e, 8);
							break;
						case 117: {
							let t = r.getDay();
							v(e, G(String(0 === t ? 7 : t)));
							break;
						}
						case 119:
							v(e, G(String(r.getDay())));
							break;
						case 120:
							Z(t, e, z.formats.x, r);
							break;
						case 121:
							J(e, r.getFullYear() % 100, 48);
							break;
						case 122: {
							let t = r.getTimezoneOffset();
							t > 0 ? k(e, 45) : (t = -t, k(e, 43)), J(e, Math.floor(t / 60), 48), J(e, t % 60, 48);
							break;
						}
					}
					a += u;
				}
			}, q = function(t, e, n) {
				let r = K, a = 0, u = 1;
				for (; a < r.length && u <= e.length - n; a += u) if (r[a] === "|".charCodeAt(0)) u++;
				else if (V(e.subarray(n, n + u), r.subarray(a, a + u))) return u;
				E(t, 1, f(t, G("invalid conversion specifier '%%%s'"), e));
			}, W = function(t, e) {
				return m(t, e);
			}, Q = {
				date: function(t) {
					let e = P(t, 1, "%c"), n = i(t, 2) ? /* @__PURE__ */ new Date() : /* @__PURE__ */ new Date(1e3 * W(t, 2)), r = !1, a = 0;
					if (e[a] === "!".charCodeAt(0) && (r = !0, a++), e[a] === "*".charCodeAt(0) && e[a + 1] === "t".charCodeAt(0)) l(t, 0, 9), j(t, n, r);
					else {
						(/* @__PURE__ */ new Uint8Array(4))[0] = "%".charCodeAt(0);
						let r = new O();
						U(t, r), Z(t, r, e, n), D(r);
					}
					return 1;
				},
				difftime: function(t) {
					let e = W(t, 1), n = W(t, 2);
					return d(t, e - n), 1;
				},
				time: function(t) {
					let e;
					return i(t, 1) ? e = /* @__PURE__ */ new Date() : (R(t, 1, a), T(t, 1), e = new Date(X(t, "year", -1, 0), X(t, "month", -1, 1), X(t, "day", -1, 0), X(t, "hour", 12, 0), X(t, "min", 0, 0), X(t, "sec", 0, 0)), j(t, e)), p(t, Math.floor(e / 1e3)), 1;
				},
				clock: function(t) {
					return d(t, performance.now() / 1e3), 1;
				}
			};
			t.exports.luaopen_os = function(t) {
				return y(t, Q), 1;
			};
		},
		function(t, e, n) {
			"use strict";
			const { sprintf: r } = n(38), { LUA_INTEGER_FMT: a, LUA_INTEGER_FRMLEN: u, LUA_MININTEGER: l, LUA_NUMBER_FMT: s, LUA_NUMBER_FRMLEN: o, frexp: i, lua_getlocaledecpoint: c } = n(3), { LUA_TBOOLEAN: _, LUA_TFUNCTION: f, LUA_TNIL: p, LUA_TNUMBER: L, LUA_TSTRING: h, LUA_TTABLE: d, lua_call: A, lua_createtable: g, lua_dump: T, lua_gettable: x, lua_gettop: b, lua_isinteger: O, lua_isstring: k, lua_pop: v, lua_pushcclosure: E, lua_pushinteger: U, lua_pushlightuserdata: m, lua_pushliteral: N, lua_pushlstring: R, lua_pushnil: S, lua_pushnumber: w, lua_pushstring: I, lua_pushvalue: y, lua_remove: M, lua_setfield: P, lua_setmetatable: C, lua_settop: D, lua_toboolean: V, lua_tointeger: B, lua_tonumber: G, lua_tostring: K, lua_touserdata: F, lua_type: j, lua_upvalueindex: H } = n(2), { luaL_Buffer: X, luaL_addchar: z, luaL_addlstring: Y, luaL_addsize: J, luaL_addstring: Z, luaL_addvalue: q, luaL_argcheck: W, luaL_argerror: Q, luaL_buffinit: $, luaL_buffinitsize: tt, luaL_checkinteger: et, luaL_checknumber: nt, luaL_checkstack: rt, luaL_checkstring: at, luaL_checktype: ut, luaL_error: lt, luaL_newlib: st, luaL_optinteger: ot, luaL_optstring: it, luaL_prepbuffsize: ct, luaL_pushresult: _t, luaL_pushresultsize: ft, luaL_tolstring: pt, luaL_typename: Lt } = n(7), ht = n(17), { luastring_eq: dt, luastring_indexOf: At, to_jsstring: gt, to_luastring: Tt } = n(5), xt = "%".charCodeAt(0), bt = function(t) {
				let e = At(t, 0);
				return e > -1 ? e : t.length;
			}, Ot = function(t, e) {
				return t >= 0 ? t : 0 - t > e ? 0 : e + t + 1;
			}, kt = function(t, e, n, r) {
				return Y(r, e, n), 0;
			}, vt = o.length + 1, Et = function(t, e, n) {
				let a = function(t) {
					if (Object.is(t, 1 / 0)) return Tt("inf");
					if (Object.is(t, -1 / 0)) return Tt("-inf");
					if (Number.isNaN(t)) return Tt("nan");
					if (0 === t) {
						let e = r(s + "x0p+0", t);
						return Object.is(t, -0) && (e = "-" + e), Tt(e);
					}
					{
						let e = "", n = i(t), a = n[0], u = n[1];
						return a < 0 && (e += "-", a = -a), e += "0x", e += (2 * a).toString(16), e += r("p%+d", u -= 1), Tt(e);
					}
				}(n);
				if (65 === e[vt]) for (let t = 0; t < a.length; t++) {
					let e = a[t];
					e >= 97 && (a[t] = 223 & e);
				}
				else 97 !== e[vt] && lt(t, Tt("modifiers for format '%%a'/'%%A' not implemented"));
				return a;
			}, Ut = Tt("-+ #0"), mt = (t) => 97 <= t && t <= 122 || 65 <= t && t <= 90, Nt = (t) => 48 <= t && t <= 57, Rt = (t) => 0 <= t && t <= 31 || 127 === t, St = (t) => 33 <= t && t <= 126, wt = (t) => 97 <= t && t <= 122, It = (t) => 65 <= t && t <= 90, yt = (t) => 97 <= t && t <= 122 || 65 <= t && t <= 90 || 48 <= t && t <= 57, Mt = (t) => St(t) && !yt(t), Pt = (t) => 32 === t || t >= 9 && t <= 13, Ct = (t) => 48 <= t && t <= 57 || 65 <= t && t <= 70 || 97 <= t && t <= 102, Dt = function(t, e, n) {
				switch (j(t, n)) {
					case h: {
						let r = K(t, n);
						(function(t, e, n) {
							z(t, 34);
							let r = 0;
							for (; n--;) {
								if (34 === e[r] || 92 === e[r] || 10 === e[r]) z(t, 92), z(t, e[r]);
								else if (Rt(e[r])) {
									let n = "" + e[r];
									Nt(e[r + 1]) && (n = "0".repeat(3 - n.length) + n), Z(t, Tt("\\" + n));
								} else z(t, e[r]);
								r++;
							}
							z(t, 34);
						})(e, r, r.length);
						break;
					}
					case L: {
						let s;
						if (O(t, n)) {
							let e = B(t, n);
							s = Tt(r(e === l ? "0x%" + u + "x" : a, e));
						} else {
							let e = G(t, n);
							(function(t) {
								if (At(t, 46) < 0) {
									let e = c(), n = At(t, e);
									n && (t[n] = 46);
								}
							})(s = Et(t, Tt(`%${u}a`), e));
						}
						Z(e, s);
						break;
					}
					case p:
					case _:
						pt(t, n), q(e);
						break;
					default: Q(t, n, Tt("value has no literal form"));
				}
			}, Vt = function(t, e, n, r) {
				let a = n;
				for (; 0 !== e[a] && At(Ut, e[a]) >= 0;) a++;
				a - n >= Ut.length && lt(t, Tt("invalid format (repeated flags)")), Nt(e[a]) && a++, Nt(e[a]) && a++, 46 === e[a] && (Nt(e[++a]) && a++, Nt(e[a]) && a++), Nt(e[a]) && lt(t, Tt("invalid format (width or precision too long)")), r[0] = 37;
				for (let t = 0; t < a - n + 1; t++) r[t + 1] = e[n + t];
				return a;
			}, Bt = function(t, e) {
				let n = t.length, r = e.length, a = t[n - 1];
				for (let a = 0; a < r; a++) t[a + n - 1] = e[a];
				t[n + r - 1] = a;
			};
			class Gt {
				constructor(t) {
					this.L = t, this.islittle = !0, this.maxalign = 1;
				}
			}
			const Kt = Nt, Ft = function(t, e) {
				if (t.off >= t.s.length || !Kt(t.s[t.off])) return e;
				{
					let e = 0;
					do
						e = 10 * e + (t.s[t.off++] - 48);
					while (t.off < t.s.length && Kt(t.s[t.off]) && e <= 214748363.8);
					return e;
				}
			}, jt = function(t, e, n) {
				let r = Ft(e, n);
				return (r > 16 || r <= 0) && lt(t.L, Tt("integral size (%d) out of limits [1,%d]"), r, 16), r;
			}, Ht = function(t, e) {
				let n = {
					opt: e.s[e.off++],
					size: 0
				};
				switch (n.opt) {
					case 98: return n.size = 1, n.opt = 0, n;
					case 66: return n.size = 1, n.opt = 1, n;
					case 104: return n.size = 2, n.opt = 0, n;
					case 72: return n.size = 2, n.opt = 1, n;
					case 108: return n.size = 4, n.opt = 0, n;
					case 76: return n.size = 4, n.opt = 1, n;
					case 106: return n.size = 4, n.opt = 0, n;
					case 74:
					case 84: return n.size = 4, n.opt = 1, n;
					case 102: return n.size = 4, n.opt = 2, n;
					case 100:
					case 110: return n.size = 8, n.opt = 2, n;
					case 105: return n.size = jt(t, e, 4), n.opt = 0, n;
					case 73: return n.size = jt(t, e, 4), n.opt = 1, n;
					case 115: return n.size = jt(t, e, 4), n.opt = 4, n;
					case 99: return n.size = Ft(e, -1), -1 === n.size && lt(t.L, Tt("missing size for format option 'c'")), n.opt = 3, n;
					case 122: return n.opt = 5, n;
					case 120: return n.size = 1, n.opt = 6, n;
					case 88: return n.opt = 7, n;
					case 32: break;
					case 60:
						t.islittle = !0;
						break;
					case 62:
						t.islittle = !1;
						break;
					case 61:
						t.islittle = !0;
						break;
					case 33:
						t.maxalign = jt(t, e, 8);
						break;
					default: lt(t.L, Tt("invalid format option '%c'"), n.opt);
				}
				return n.opt = 8, n;
			}, Xt = function(t, e, n) {
				let r = {
					opt: NaN,
					size: NaN,
					ntoalign: NaN
				}, a = Ht(t, n);
				r.size = a.size, r.opt = a.opt;
				let u = r.size;
				if (7 === r.opt) if (n.off >= n.s.length || 0 === n.s[n.off]) Q(t.L, 1, Tt("invalid next option for option 'X'"));
				else {
					let e = Ht(t, n);
					u = e.size, 3 !== (e = e.opt) && 0 !== u || Q(t.L, 1, Tt("invalid next option for option 'X'"));
				}
				return u <= 1 || 3 === r.opt ? r.ntoalign = 0 : (u > t.maxalign && (u = t.maxalign), 0 != (u & u - 1) && Q(t.L, 1, Tt("format asks for alignment not power of 2")), r.ntoalign = u - (e & u - 1) & u - 1), r;
			}, zt = function(t, e, n, r, a) {
				let u = ct(t, r);
				u[n ? 0 : r - 1] = 255 & e;
				for (let t = 1; t < r; t++) e >>= 8, u[n ? t : r - 1 - t] = 255 & e;
				if (a && r > 4) for (let t = 4; t < r; t++) u[n ? t : r - 1 - t] = 255;
				J(t, r);
			}, Yt = function(t, e, n, r, a) {
				let u = 0, l = r <= 4 ? r : 4;
				for (let t = l - 1; t >= 0; t--) u <<= 8, u |= e[n ? t : r - 1 - t];
				if (r < 4) {
					if (a) {
						let t = 1 << 8 * r - 1;
						u = (u ^ t) - t;
					}
				} else if (r > 4) {
					let s = !a || u >= 0 ? 0 : 255;
					for (let a = l; a < r; a++) e[n ? a : r - 1 - a] !== s && lt(t, Tt("%d-byte integer does not fit into Lua Integer"), r);
				}
				return u;
			}, Jt = function(t, e, n, r) {
				ht.lua_assert(e.length >= r);
				let a = new DataView(new ArrayBuffer(r));
				for (let t = 0; t < r; t++) a.setUint8(t, e[t], n);
				return 4 == r ? a.getFloat32(0, n) : a.getFloat64(0, n);
			}, Zt = Tt("^$*+?.([%-");
			class qt {
				constructor(t) {
					this.src = null, this.src_init = null, this.src_end = null, this.p = null, this.p_end = null, this.L = t, this.matchdepth = NaN, this.level = NaN, this.capture = [];
				}
			}
			const Wt = function(t, e) {
				switch (t.p[e++]) {
					case xt: return e === t.p_end && lt(t.L, Tt("malformed pattern (ends with '%%')")), e + 1;
					case 91:
						94 === t.p[e] && e++;
						do
							e === t.p_end && lt(t.L, Tt("malformed pattern (missing ']')")), t.p[e++] === xt && e < t.p_end && e++;
						while (93 !== t.p[e]);
						return e + 1;
					default: return e;
				}
			}, Qt = function(t, e) {
				switch (e) {
					case 97: return mt(t);
					case 65: return !mt(t);
					case 99: return Rt(t);
					case 67: return !Rt(t);
					case 100: return Nt(t);
					case 68: return !Nt(t);
					case 103: return St(t);
					case 71: return !St(t);
					case 108: return wt(t);
					case 76: return !wt(t);
					case 112: return Mt(t);
					case 80: return !Mt(t);
					case 115: return Pt(t);
					case 83: return !Pt(t);
					case 117: return It(t);
					case 85: return !It(t);
					case 119: return yt(t);
					case 87: return !yt(t);
					case 120: return Ct(t);
					case 88: return !Ct(t);
					case 122: return 0 === t;
					case 90: return 0 !== t;
					default: return e === t;
				}
			}, $t = function(t, e, n, r) {
				let a = !0;
				for (94 === t.p[n + 1] && (a = !1, n++); ++n < r;) if (t.p[n] === xt) {
					if (n++, Qt(e, t.p[n])) return a;
				} else if (45 === t.p[n + 1] && n + 2 < r) {
					if (n += 2, t.p[n - 2] <= e && e <= t.p[n]) return a;
				} else if (t.p[n] === e) return a;
				return !a;
			}, te = function(t, e, n, r) {
				if (e >= t.src_end) return !1;
				{
					let a = t.src[e];
					switch (t.p[n]) {
						case 46: return !0;
						case xt: return Qt(a, t.p[n + 1]);
						case 91: return $t(t, a, n, r - 1);
						default: return t.p[n] === a;
					}
				}
			}, ee = function(t, e, n) {
				if (n >= t.p_end - 1 && lt(t.L, Tt("malformed pattern (missing arguments to '%%b'")), t.src[e] !== t.p[n]) return null;
				{
					let r = t.p[n], a = t.p[n + 1], u = 1;
					for (; ++e < t.src_end;) if (t.src[e] === a) {
						if (0 == --u) return e + 1;
					} else t.src[e] === r && u++;
				}
				return null;
			}, ne = function(t, e, n, r) {
				let a = 0;
				for (; te(t, e + a, n, r);) a++;
				for (; a >= 0;) {
					let n = se(t, e + a, r + 1);
					if (n) return n;
					a--;
				}
				return null;
			}, re = function(t, e, n, r) {
				for (;;) {
					let a = se(t, e, r + 1);
					if (null !== a) return a;
					if (!te(t, e, n, r)) return null;
					e++;
				}
			}, ae = function(t, e, n, r) {
				let a, u = t.level;
				return u >= 32 && lt(t.L, Tt("too many captures")), t.capture[u] = t.capture[u] ? t.capture[u] : {}, t.capture[u].init = e, t.capture[u].len = r, t.level = u + 1, null === (a = se(t, e, n)) && t.level--, a;
			}, ue = function(t, e, n) {
				let r, a = function(t) {
					let e = t.level;
					for (e--; e >= 0; e--) if (-1 === t.capture[e].len) return e;
					return lt(t.L, Tt("invalid pattern capture"));
				}(t);
				return t.capture[a].len = e - t.capture[a].init, null === (r = se(t, e, n)) && (t.capture[a].len = -1), r;
			}, le = function(t, e, n) {
				n = function(t, e) {
					return (e -= 49) < 0 || e >= t.level || -1 === t.capture[e].len ? lt(t.L, Tt("invalid capture index %%%d"), e + 1) : e;
				}(t, n);
				let r = t.capture[n].len;
				return t.src_end - e >= r && function(t, e, n, r, a) {
					return dt(t.subarray(e, e + a), n.subarray(r, r + a));
				}(t.src, t.capture[n].init, t.src, e, r) ? e + r : null;
			}, se = function(t, e, n) {
				let r = !1, a = !0;
				for (0 == t.matchdepth-- && lt(t.L, Tt("pattern too complex")); a || r;) if (a = !1, n !== t.p_end) switch (r ? void 0 : t.p[n]) {
					case 40:
						e = 41 === t.p[n + 1] ? ae(t, e, n + 2, -2) : ae(t, e, n + 1, -1);
						break;
					case 41:
						e = ue(t, e, n + 1);
						break;
					case 36:
						if (n + 1 !== t.p_end) {
							r = !0;
							break;
						}
						e = t.src.length - e == 0 ? e : null;
						break;
					case xt:
						switch (t.p[n + 1]) {
							case 98:
								null !== (e = ee(t, e, n + 2)) && (n += 4, a = !0);
								break;
							case 102: {
								n += 2, 91 !== t.p[n] && lt(t.L, Tt("missing '[' after '%%f' in pattern"));
								let r = Wt(t, n), u = e === t.src_init ? 0 : t.src[e - 1];
								if (!$t(t, u, n, r - 1) && $t(t, e === t.src_end ? 0 : t.src[e], n, r - 1)) {
									n = r, a = !0;
									break;
								}
								e = null;
								break;
							}
							case 48:
							case 49:
							case 50:
							case 51:
							case 52:
							case 53:
							case 54:
							case 55:
							case 56:
							case 57:
								null !== (e = le(t, e, t.p[n + 1])) && (n += 2, a = !0);
								break;
							default: r = !0;
						}
						break;
					default: {
						r = !1;
						let u = Wt(t, n);
						if (te(t, e, n, u)) switch (t.p[u]) {
							case 63: {
								let r;
								null !== (r = se(t, e + 1, u + 1)) ? e = r : (n = u + 1, a = !0);
								break;
							}
							case 43: e++;
							case 42:
								e = ne(t, e, n, u);
								break;
							case 45:
								e = re(t, e, n, u);
								break;
							default: e++, n = u, a = !0;
						}
						else {
							if (42 === t.p[u] || 63 === t.p[u] || 45 === t.p[u]) {
								n = u + 1, a = !0;
								break;
							}
							e = null;
						}
						break;
					}
				}
				return t.matchdepth++, e;
			}, oe = function(t, e, n, r) {
				if (e >= t.level) 0 === e ? R(t.L, t.src.subarray(n, r), r - n) : lt(t.L, Tt("invalid capture index %%%d"), e + 1);
				else {
					let n = t.capture[e].len;
					-1 === n && lt(t.L, Tt("unfinished capture")), -2 === n ? U(t.L, t.capture[e].init - t.src_init + 1) : R(t.L, t.src.subarray(t.capture[e].init), n);
				}
			}, ie = function(t, e, n) {
				let r = 0 === t.level && t.src.subarray(e) ? 1 : t.level;
				rt(t.L, r, "too many captures");
				for (let a = 0; a < r; a++) oe(t, a, e, n);
				return r;
			}, ce = function(t, e, n, r, a, u) {
				t.L = e, t.matchdepth = 200, t.src = n, t.src_init = 0, t.src_end = r, t.p = a, t.p_end = u;
			}, _e = function(t) {
				t.level = 0, ht.lua_assert(200 === t.matchdepth);
			}, fe = function(t, e) {
				let n = at(t, 1), r = at(t, 2), a = n.length, u = r.length, l = Ot(ot(t, 3, 1), a);
				if (l < 1) l = 1;
				else if (l > a + 1) return S(t), 1;
				if (e && (V(t, 4) || function(t, e) {
					for (let n = 0; n < e; n++) if (-1 !== At(Zt, t[n])) return !1;
					return !0;
				}(r, u))) {
					let e = function(t, e, n) {
						var r = n >>> 0, a = e.length;
						if (0 === a) return r;
						for (; -1 !== (r = t.indexOf(e[0], r)); r++) if (dt(t.subarray(r, r + a), e)) return r;
						return -1;
					}(n.subarray(l - 1), r, 0);
					if (e > -1) return U(t, l + e), U(t, l + e + u - 1), 2;
				} else {
					let s = new qt(t), o = l - 1, i = 94 === r[0];
					i && (r = r.subarray(1), u--), ce(s, t, n, a, r, u);
					do {
						let n;
						if (_e(s), null !== (n = se(s, o, 0))) return e ? (U(t, o + 1), U(t, n), ie(s, null, 0) + 2) : ie(s, o, n);
					} while (o++ < s.src_end && !i);
				}
				return S(t), 1;
			};
			const pe = function(t) {
				let e = F(t, H(3));
				e.ms.L = t;
				for (let t = e.src; t <= e.ms.src_end; t++) {
					let n;
					if (_e(e.ms), null !== (n = se(e.ms, t, e.p)) && n !== e.lastmatch) return e.src = e.lastmatch = n, ie(e.ms, t, n);
				}
				return 0;
			}, Le = function(t, e, n, r, a) {
				let u = t.L;
				switch (a) {
					case f: {
						y(u, 3);
						let e = ie(t, n, r);
						A(u, e, 1);
						break;
					}
					case d:
						oe(t, 0, n, r), x(u, 3);
						break;
					default:
						(function(t, e, n, r) {
							let a = t.L, u = K(a, 3), l = u.length;
							for (let s = 0; s < l; s++) u[s] !== xt ? z(e, u[s]) : Nt(u[++s]) ? 48 === u[s] ? Y(e, t.src.subarray(n, r), r - n) : (oe(t, u[s] - 49, n, r), pt(a, -1), M(a, -2), q(e)) : (u[s] !== xt && lt(a, Tt("invalid use of '%c' in replacement string"), xt), z(e, u[s]));
						})(t, e, n, r);
						return;
				}
				V(u, -1) ? k(u, -1) || lt(u, Tt("invalid replacement value (a %s)"), Lt(u, -1)) : (v(u, 1), R(u, t.src.subarray(n, r), r - n)), q(e);
			}, he = {
				byte: function(t) {
					let e = at(t, 1), n = e.length, r = Ot(ot(t, 2, 1), n), a = Ot(ot(t, 3, r), n);
					if (r < 1 && (r = 1), a > n && (a = n), r > a) return 0;
					if (a - r >= Number.MAX_SAFE_INTEGER) return lt(t, "string slice too long");
					let u = a - r + 1;
					rt(t, u, "string slice too long");
					for (let n = 0; n < u; n++) U(t, e[r + n - 1]);
					return u;
				},
				char: function(t) {
					let e = b(t), n = new X(), r = tt(t, n, e);
					for (let n = 1; n <= e; n++) {
						let e = et(t, n);
						W(t, e >= 0 && e <= 255, "value out of range"), r[n - 1] = e;
					}
					return ft(n, e), 1;
				},
				dump: function(t) {
					let e = new X(), n = V(t, 2);
					return ut(t, 1, f), D(t, 1), $(t, e), 0 !== T(t, kt, e, n) ? lt(t, Tt("unable to dump given function")) : (_t(e), 1);
				},
				find: function(t) {
					return fe(t, 1);
				},
				format: function(t) {
					let e = b(t), n = 1, a = at(t, n), l = 0, s = new X();
					for ($(t, s); l < a.length;) if (a[l] !== xt) z(s, a[l++]);
					else if (a[++l] === xt) z(s, a[l++]);
					else {
						let o = [];
						switch (++n > e && Q(t, n, Tt("no value")), l = Vt(t, a, l, o), String.fromCharCode(a[l++])) {
							case "c":
								z(s, et(t, n));
								break;
							case "d":
							case "i":
							case "o":
							case "u":
							case "x":
							case "X": {
								let e = et(t, n);
								Bt(o, Tt(u, !0)), Z(s, Tt(r(String.fromCharCode(...o), e)));
								break;
							}
							case "a":
							case "A":
								Bt(o, Tt(u, !0)), Z(s, Et(t, o, nt(t, n)));
								break;
							case "e":
							case "E":
							case "f":
							case "g":
							case "G": {
								let e = nt(t, n);
								Bt(o, Tt(u, !0)), Z(s, Tt(r(String.fromCharCode(...o), e)));
								break;
							}
							case "q":
								Dt(t, s, n);
								break;
							case "s": {
								let e = pt(t, n);
								o.length <= 2 || 0 === o[2] ? q(s) : (W(t, e.length === bt(e), n, "string contains zeros"), At(o, 46) < 0 && e.length >= 100 ? q(s) : (Z(s, Tt(r(String.fromCharCode(...o), gt(e)))), v(t, 1)));
								break;
							}
							default: return lt(t, Tt("invalid option '%%%c' to 'format'"), a[l - 1]);
						}
					}
					return _t(s), 1;
				},
				gmatch: function(t) {
					let e = at(t, 1), n = at(t, 2), r = e.length, a = n.length;
					D(t, 2);
					let u = new class {
						constructor() {
							this.src = NaN, this.p = NaN, this.lastmatch = NaN, this.ms = new qt();
						}
					}();
					return m(t, u), ce(u.ms, t, e, r, n, a), u.src = 0, u.p = 0, u.lastmatch = null, E(t, pe, 3), 1;
				},
				gsub: function(t) {
					let e = at(t, 1), n = e.length, r = at(t, 2), a = r.length, u = null, l = j(t, 3), s = ot(t, 4, n + 1), o = 94 === r[0], i = 0, c = new qt(t), _ = new X();
					for (W(t, l === L || l === h || l === f || l === d, 3, "string/function/table expected"), $(t, _), o && (r = r.subarray(1), a--), ce(c, t, e, n, r, a), e = 0, r = 0; i < s;) {
						let t;
						if (_e(c), null !== (t = se(c, e, r)) && t !== u) i++, Le(c, _, e, t, l), e = u = t;
						else {
							if (!(e < c.src_end)) break;
							z(_, c.src[e++]);
						}
						if (o) break;
					}
					return Y(_, c.src.subarray(e, c.src_end), c.src_end - e), _t(_), U(t, i), 2;
				},
				len: function(t) {
					return U(t, at(t, 1).length), 1;
				},
				lower: function(t) {
					let e = at(t, 1), n = e.length, r = new Uint8Array(n);
					for (let t = 0; t < n; t++) {
						let n = e[t];
						It(n) && (n |= 32), r[t] = n;
					}
					return I(t, r), 1;
				},
				match: function(t) {
					return fe(t, 0);
				},
				pack: function(t) {
					let e = new X(), n = new Gt(t), r = {
						s: at(t, 1),
						off: 0
					}, a = 1, u = 0;
					for (S(t), $(t, e); r.off < r.s.length;) {
						let l = Xt(n, u, r), s = l.opt, o = l.size, i = l.ntoalign;
						for (u += i + o; i-- > 0;) z(e, 0);
						switch (a++, s) {
							case 0: {
								let r = et(t, a);
								if (o < 4) {
									let e = 1 << 8 * o - 1;
									W(t, -e <= r && r < e, a, "integer overflow");
								}
								zt(e, r, n.islittle, o, r < 0);
								break;
							}
							case 1: {
								let r = et(t, a);
								o < 4 && W(t, r >>> 0 < 1 << 8 * o, a, "unsigned overflow"), zt(e, r >>> 0, n.islittle, o, !1);
								break;
							}
							case 2: {
								let r = ct(e, o), u = nt(t, a), l = new DataView(r.buffer, r.byteOffset, r.byteLength);
								4 === o ? l.setFloat32(0, u, n.islittle) : l.setFloat64(0, u, n.islittle), J(e, o);
								break;
							}
							case 3: {
								let n = at(t, a), r = n.length;
								for (W(t, r <= o, a, "string longer than given size"), Y(e, n, r); r++ < o;) z(e, 0);
								break;
							}
							case 4: {
								let r = at(t, a), l = r.length;
								W(t, o >= 4 || l < 1 << 8 * o, a, "string length does not fit in given size"), zt(e, l, n.islittle, o, 0), Y(e, r, l), u += l;
								break;
							}
							case 5: {
								let n = at(t, a), r = n.length;
								W(t, At(n, 0) < 0, a, "strings contains zeros"), Y(e, n, r), z(e, 0), u += r + 1;
								break;
							}
							case 6: z(e, 0);
							case 7:
							case 8: a--;
						}
					}
					return _t(e), 1;
				},
				packsize: function(t) {
					let e = new Gt(t), n = {
						s: at(t, 1),
						off: 0
					}, r = 0;
					for (; n.off < n.s.length;) {
						let a = Xt(e, r, n), u = a.opt, l = a.size, s = a.ntoalign;
						switch (W(t, r <= 2147483647 - (l += s), 1, "format result too large"), r += l, u) {
							case 4:
							case 5: Q(t, 1, "variable-length format");
						}
					}
					return U(t, r), 1;
				},
				rep: function(t) {
					let e = at(t, 1), n = e.length, r = et(t, 2), a = it(t, 3, ""), u = a.length;
					if (r <= 0) N(t, "");
					else {
						if (n + u < n || n + u > 2147483647 / r) return lt(t, Tt("resulting string too large"));
						{
							let l = r * n + (r - 1) * u, s = new X(), o = tt(t, s, l), i = 0;
							for (; r-- > 1;) o.set(e, i), i += n, u > 0 && (o.set(a, i), i += u);
							o.set(e, i), ft(s, l);
						}
					}
					return 1;
				},
				reverse: function(t) {
					let e = at(t, 1), n = e.length, r = new Uint8Array(n);
					for (let t = 0; t < n; t++) r[t] = e[n - 1 - t];
					return I(t, r), 1;
				},
				sub: function(t) {
					let e = at(t, 1), n = e.length, r = Ot(et(t, 2), n), a = Ot(ot(t, 3, -1), n);
					return r < 1 && (r = 1), a > n && (a = n), r <= a ? I(t, e.subarray(r - 1, r - 1 + (a - r + 1))) : N(t, ""), 1;
				},
				unpack: function(t) {
					let e = new Gt(t), n = {
						s: at(t, 1),
						off: 0
					}, r = at(t, 2), a = r.length, u = Ot(ot(t, 3, 1), a) - 1, l = 0;
					for (W(t, u <= a && u >= 0, 3, "initial position out of string"); n.off < n.s.length;) {
						let s = Xt(e, u, n), o = s.opt, i = s.size, c = s.ntoalign;
						switch (u + c + i > a && Q(t, 2, Tt("data string too short")), u += c, rt(t, 2, "too many results"), l++, o) {
							case 0:
							case 1: {
								let n = Yt(t, r.subarray(u), e.islittle, i, 0 === o);
								U(t, n);
								break;
							}
							case 2: {
								let n = Jt(0, r.subarray(u), e.islittle, i);
								w(t, n);
								break;
							}
							case 3:
								I(t, r.subarray(u, u + i));
								break;
							case 4: {
								let n = Yt(t, r.subarray(u), e.islittle, i, 0);
								W(t, u + n + i <= a, 2, "data string too short"), I(t, r.subarray(u + i, u + i + n)), u += n;
								break;
							}
							case 5: {
								let e = At(r, 0, u);
								-1 === e && (e = r.length - u), I(t, r.subarray(u, e)), u = e + 1;
								break;
							}
							case 7:
							case 6:
							case 8: l--;
						}
						u += i;
					}
					return U(t, u + 1), l + 1;
				},
				upper: function(t) {
					let e = at(t, 1), n = e.length, r = new Uint8Array(n);
					for (let t = 0; t < n; t++) {
						let n = e[t];
						wt(n) && (n &= 223), r[t] = n;
					}
					return I(t, r), 1;
				}
			};
			t.exports.luaopen_string = function(t) {
				return st(t, he), function(t) {
					g(t, 0, 1), N(t, ""), y(t, -2), C(t, -2), v(t, 1), y(t, -2), P(t, -2, Tt("__index", !0)), v(t, 1);
				}(t), 1;
			};
		},
		function(t, e, n) {
			"use strict";
			const { lua_gettop: r, lua_pushcfunction: a, lua_pushfstring: u, lua_pushinteger: l, lua_pushnil: s, lua_pushstring: o, lua_pushvalue: i, lua_setfield: c, lua_tointeger: _ } = n(2), { luaL_Buffer: f, luaL_addvalue: p, luaL_argcheck: L, luaL_buffinit: h, luaL_checkinteger: d, luaL_checkstack: A, luaL_checkstring: g, luaL_error: T, luaL_newlib: x, luaL_optinteger: b, luaL_pushresult: O } = n(7), { luastring_of: k, to_luastring: v } = n(5), E = function(t) {
				return 128 === (192 & t);
			}, U = function(t, e) {
				return t >= 0 ? t : 0 - t > e ? 0 : e + t + 1;
			}, m = [
				255,
				127,
				2047,
				65535
			], N = function(t, e) {
				let n = t[e], r = 0;
				if (n < 128) r = n;
				else {
					let a = 0;
					for (; 64 & n;) {
						let u = t[e + ++a];
						if (128 != (192 & u)) return null;
						r = r << 6 | 63 & u, n <<= 1;
					}
					if (r |= (127 & n) << 5 * a, a > 3 || r > 1114111 || r <= m[a]) return null;
					e += a;
				}
				return {
					code: r,
					pos: e + 1
				};
			}, R = v("%U"), S = function(t, e) {
				let n = d(t, e);
				L(t, 0 <= n && n <= 1114111, e, "value out of range"), u(t, R, n);
			}, w = function(t) {
				let e = g(t, 1), n = e.length, r = _(t, 2) - 1;
				if (r < 0) r = 0;
				else if (r < n) for (r++; E(e[r]);) r++;
				if (r >= n) return 0;
				{
					let n = N(e, r);
					return null === n || E(e[n.pos]) ? T(t, v("invalid UTF-8 code")) : (l(t, r + 1), l(t, n.code), 2);
				}
			}, I = {
				char: function(t) {
					let e = r(t);
					if (1 === e) S(t, 1);
					else {
						let n = new f();
						h(t, n);
						for (let r = 1; r <= e; r++) S(t, r), p(n);
						O(n);
					}
					return 1;
				},
				codepoint: function(t) {
					let e = g(t, 1), n = U(b(t, 2, 1), e.length), r = U(b(t, 3, n), e.length);
					if (L(t, n >= 1, 2, "out of range"), L(t, r <= e.length, 3, "out of range"), n > r) return 0;
					if (r - n >= Number.MAX_SAFE_INTEGER) return T(t, "string slice too long");
					let a = r - n + 1;
					for (A(t, a, "string slice too long"), a = 0, n -= 1; n < r;) {
						let r = N(e, n);
						if (null === r) return T(t, "invalid UTF-8 code");
						l(t, r.code), n = r.pos, a++;
					}
					return a;
				},
				codes: function(t) {
					return g(t, 1), a(t, w), i(t, 1), l(t, 0), 3;
				},
				len: function(t) {
					let e = 0, n = g(t, 1), r = n.length, a = U(b(t, 2, 1), r), u = U(b(t, 3, -1), r);
					for (L(t, 1 <= a && --a <= r, 2, "initial position out of string"), L(t, --u < r, 3, "final position out of string"); a <= u;) {
						let r = N(n, a);
						if (null === r) return s(t), l(t, a + 1), 2;
						a = r.pos, e++;
					}
					return l(t, e), 1;
				},
				offset: function(t) {
					let e = g(t, 1), n = d(t, 2), r = n >= 0 ? 1 : e.length + 1;
					if (r = U(b(t, 3, r), e.length), L(t, 1 <= r && --r <= e.length, 3, "position out of range"), 0 === n) for (; r > 0 && E(e[r]);) r--;
					else if (E(e[r]) && T(t, "initial position is a continuation byte"), n < 0) for (; n < 0 && r > 0;) {
						do
							r--;
						while (r > 0 && E(e[r]));
						n++;
					}
					else for (n--; n > 0 && r < e.length;) {
						do
							r++;
						while (E(e[r]));
						n--;
					}
					return 0 === n ? l(t, r + 1) : s(t), 1;
				}
			}, y = k(91, 0, 45, 127, 194, 45, 244, 93, 91, 128, 45, 191, 93, 42);
			t.exports.luaopen_utf8 = function(t) {
				return x(t, I), o(t, y), c(t, -2, v("charpattern", !0)), 1;
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_OPLT: r, LUA_TNUMBER: a, lua_compare: u, lua_gettop: l, lua_isinteger: s, lua_isnoneornil: o, lua_pushboolean: i, lua_pushinteger: c, lua_pushliteral: _, lua_pushnil: f, lua_pushnumber: p, lua_pushvalue: L, lua_setfield: h, lua_settop: d, lua_tointeger: A, lua_tointegerx: g, lua_type: T } = n(2), { luaL_argcheck: x, luaL_argerror: b, luaL_checkany: O, luaL_checkinteger: k, luaL_checknumber: v, luaL_error: E, luaL_newlib: U, luaL_optnumber: m } = n(7), { LUA_MAXINTEGER: N, LUA_MININTEGER: R, lua_numbertointeger: S } = n(3), { to_luastring: w } = n(5);
			let I;
			const y = function() {
				return I = 1103515245 * I + 12345 & 2147483647;
			}, M = function(t, e) {
				let n = S(e);
				!1 !== n ? c(t, n) : p(t, e);
			}, P = {
				abs: function(t) {
					if (s(t, 1)) {
						let e = A(t, 1);
						e < 0 && (e = 0 | -e), c(t, e);
					} else p(t, Math.abs(v(t, 1)));
					return 1;
				},
				acos: function(t) {
					return p(t, Math.acos(v(t, 1))), 1;
				},
				asin: function(t) {
					return p(t, Math.asin(v(t, 1))), 1;
				},
				atan: function(t) {
					let e = v(t, 1), n = m(t, 2, 1);
					return p(t, Math.atan2(e, n)), 1;
				},
				ceil: function(t) {
					return s(t, 1) ? d(t, 1) : M(t, Math.ceil(v(t, 1))), 1;
				},
				cos: function(t) {
					return p(t, Math.cos(v(t, 1))), 1;
				},
				deg: function(t) {
					return p(t, v(t, 1) * (180 / Math.PI)), 1;
				},
				exp: function(t) {
					return p(t, Math.exp(v(t, 1))), 1;
				},
				floor: function(t) {
					return s(t, 1) ? d(t, 1) : M(t, Math.floor(v(t, 1))), 1;
				},
				fmod: function(t) {
					if (s(t, 1) && s(t, 2)) {
						let e = A(t, 2);
						0 === e ? b(t, 2, "zero") : c(t, A(t, 1) % e | 0);
					} else {
						let e = v(t, 1), n = v(t, 2);
						p(t, e % n);
					}
					return 1;
				},
				log: function(t) {
					let e, n = v(t, 1);
					if (o(t, 2)) e = Math.log(n);
					else {
						let r = v(t, 2);
						e = 2 === r ? Math.log2(n) : 10 === r ? Math.log10(n) : Math.log(n) / Math.log(r);
					}
					return p(t, e), 1;
				},
				max: function(t) {
					let e = l(t), n = 1;
					x(t, e >= 1, 1, "value expected");
					for (let a = 2; a <= e; a++) u(t, n, a, r) && (n = a);
					return L(t, n), 1;
				},
				min: function(t) {
					let e = l(t), n = 1;
					x(t, e >= 1, 1, "value expected");
					for (let a = 2; a <= e; a++) u(t, a, n, r) && (n = a);
					return L(t, n), 1;
				},
				modf: function(t) {
					if (s(t, 1)) d(t, 1), p(t, 0);
					else {
						let e = v(t, 1), n = e < 0 ? Math.ceil(e) : Math.floor(e);
						M(t, n), p(t, e === n ? 0 : e - n);
					}
					return 2;
				},
				rad: function(t) {
					return p(t, v(t, 1) * (Math.PI / 180)), 1;
				},
				random: function(t) {
					let e, n, r = void 0 === I ? Math.random() : y() / 2147483648;
					switch (l(t)) {
						case 0: return p(t, r), 1;
						case 1:
							e = 1, n = k(t, 1);
							break;
						case 2:
							e = k(t, 1), n = k(t, 2);
							break;
						default: return E(t, "wrong number of arguments");
					}
					return x(t, e <= n, 1, "interval is empty"), x(t, e >= 0 || n <= N + e, 1, "interval too large"), r *= n - e + 1, c(t, Math.floor(r) + e), 1;
				},
				randomseed: function(t) {
					return function(t) {
						0 == (I = 0 | t) && (I = 1);
					}(v(t, 1)), y(), 0;
				},
				sin: function(t) {
					return p(t, Math.sin(v(t, 1))), 1;
				},
				sqrt: function(t) {
					return p(t, Math.sqrt(v(t, 1))), 1;
				},
				tan: function(t) {
					return p(t, Math.tan(v(t, 1))), 1;
				},
				tointeger: function(t) {
					let e = g(t, 1);
					return !1 !== e ? c(t, e) : (O(t, 1), f(t)), 1;
				},
				type: function(t) {
					return T(t, 1) === a ? s(t, 1) ? _(t, "integer") : _(t, "float") : (O(t, 1), f(t)), 1;
				},
				ult: function(t) {
					let e = k(t, 1), n = k(t, 2);
					return i(t, e >= 0 ? n < 0 || e < n : n < 0 && e < n), 1;
				}
			};
			t.exports.luaopen_math = function(t) {
				return U(t, P), p(t, Math.PI), h(t, -2, w("pi", !0)), p(t, 1 / 0), h(t, -2, w("huge", !0)), c(t, N), h(t, -2, w("maxinteger", !0)), c(t, R), h(t, -2, w("mininteger", !0)), 1;
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_MASKCALL: r, LUA_MASKCOUNT: a, LUA_MASKLINE: u, LUA_MASKRET: l, LUA_REGISTRYINDEX: s, LUA_TFUNCTION: o, LUA_TNIL: i, LUA_TTABLE: c, LUA_TUSERDATA: _, lua_Debug: f, lua_call: p, lua_checkstack: L, lua_gethook: h, lua_gethookcount: d, lua_gethookmask: A, lua_getinfo: g, lua_getlocal: T, lua_getmetatable: x, lua_getstack: b, lua_getupvalue: O, lua_getuservalue: k, lua_insert: v, lua_iscfunction: E, lua_isfunction: U, lua_isnoneornil: m, lua_isthread: N, lua_newtable: R, lua_pcall: S, lua_pop: w, lua_pushboolean: I, lua_pushfstring: y, lua_pushinteger: M, lua_pushlightuserdata: P, lua_pushliteral: C, lua_pushnil: D, lua_pushstring: V, lua_pushvalue: B, lua_rawgetp: G, lua_rawsetp: K, lua_rotate: F, lua_setfield: j, lua_sethook: H, lua_setlocal: X, lua_setmetatable: z, lua_settop: Y, lua_setupvalue: J, lua_setuservalue: Z, lua_tojsstring: q, lua_toproxy: W, lua_tostring: Q, lua_tothread: $, lua_touserdata: tt, lua_type: et, lua_upvalueid: nt, lua_upvaluejoin: rt, lua_xmove: at } = n(2), { luaL_argcheck: ut, luaL_argerror: lt, luaL_checkany: st, luaL_checkinteger: ot, luaL_checkstring: it, luaL_checktype: ct, luaL_error: _t, luaL_loadbuffer: ft, luaL_newlib: pt, luaL_optinteger: Lt, luaL_optstring: ht, luaL_traceback: dt, lua_writestringerror: At } = n(7), gt = n(17), { luastring_indexOf: Tt, to_luastring: xt } = n(5), bt = function(t, e, n) {
				t === e || L(e, n) || _t(t, xt("stack overflow", !0));
			}, Ot = function(t) {
				return N(t, 1) ? {
					arg: 1,
					thread: $(t, 1)
				} : {
					arg: 0,
					thread: t
				};
			}, kt = function(t, e, n) {
				V(t, n), j(t, -2, e);
			}, vt = function(t, e, n) {
				M(t, n), j(t, -2, e);
			}, Et = function(t, e, n) {
				I(t, n), j(t, -2, e);
			}, Ut = function(t, e, n) {
				t == e ? F(t, -2, 1) : at(e, t, 1), j(t, -2, n);
			}, mt = function(t, e) {
				let n = ot(t, 2);
				ct(t, 1, o);
				let r = e ? O(t, 1, n) : J(t, 1, n);
				return null === r ? 0 : (V(t, r), v(t, -(e + 1)), e + 1);
			}, Nt = function(t, e, n) {
				let r = ot(t, n);
				return ct(t, e, o), ut(t, null !== O(t, e, r), n, "invalid upvalue index"), r;
			}, Rt = xt("__hooks__", !0), St = [
				"call",
				"return",
				"line",
				"count",
				"tail call"
			].map((t) => xt(t)), wt = function(t, e) {
				G(t, s, Rt);
				let n = tt(t, -1).get(t);
				n && (n(t), V(t, St[e.event]), e.currentline >= 0 ? M(t, e.currentline) : D(t), gt.lua_assert(g(t, xt("lS"), e)), p(t, 2, 0));
			}, It = {
				gethook: function(t) {
					let e = Ot(t).thread, n = /* @__PURE__ */ new Uint8Array(5), a = A(e), o = h(e);
					null === o ? D(t) : o !== wt ? C(t, "external hook") : (G(t, s, Rt), tt(t, -1).get(e)(t));
					return V(t, function(t, e) {
						let n = 0;
						return t & r && (e[n++] = 99), t & l && (e[n++] = 114), t & u && (e[n++] = 108), e.subarray(0, n);
					}(a, n)), M(t, d(e)), 3;
				},
				getinfo: function(t) {
					let e = new f(), n = Ot(t), r = n.arg, a = n.thread, u = ht(t, r + 2, "flnStu");
					if (bt(t, a, 3), U(t, r + 1)) u = y(t, xt(">%s"), u), B(t, r + 1), at(t, a, 1);
					else if (!b(a, ot(t, r + 1), e)) return D(t), 1;
					return g(a, u, e) || lt(t, r + 2, "invalid option"), R(t), Tt(u, 83) > -1 && (kt(t, xt("source", !0), e.source), kt(t, xt("short_src", !0), e.short_src), vt(t, xt("linedefined", !0), e.linedefined), vt(t, xt("lastlinedefined", !0), e.lastlinedefined), kt(t, xt("what", !0), e.what)), Tt(u, 108) > -1 && vt(t, xt("currentline", !0), e.currentline), Tt(u, 117) > -1 && (vt(t, xt("nups", !0), e.nups), vt(t, xt("nparams", !0), e.nparams), Et(t, xt("isvararg", !0), e.isvararg)), Tt(u, 110) > -1 && (kt(t, xt("name", !0), e.name), kt(t, xt("namewhat", !0), e.namewhat)), Tt(u, 116) > -1 && Et(t, xt("istailcall", !0), e.istailcall), Tt(u, 76) > -1 && Ut(t, a, xt("activelines", !0)), Tt(u, 102) > -1 && Ut(t, a, xt("func", !0)), 1;
				},
				getlocal: function(t) {
					let e = Ot(t), n = e.thread, r = e.arg, a = new f(), u = ot(t, r + 2);
					if (U(t, r + 1)) return B(t, r + 1), V(t, T(t, null, u)), 1;
					{
						let e = ot(t, r + 1);
						if (!b(n, e, a)) return lt(t, r + 1, "level out of range");
						bt(t, n, 1);
						let l = T(n, a, u);
						return l ? (at(n, t, 1), V(t, l), F(t, -2, 1), 2) : (D(t), 1);
					}
				},
				getmetatable: function(t) {
					return st(t, 1), x(t, 1) || D(t), 1;
				},
				getregistry: function(t) {
					return B(t, s), 1;
				},
				getupvalue: function(t) {
					return mt(t, 1);
				},
				getuservalue: function(t) {
					return et(t, 1) !== _ ? D(t) : k(t, 1), 1;
				},
				sethook: function(t) {
					let e, n, c, _, f = Ot(t), p = f.thread, L = f.arg;
					if (m(t, L + 1)) Y(t, L + 1), c = null, e = 0, n = 0;
					else {
						const s = it(t, L + 2);
						ct(t, L + 1, o), n = Lt(t, L + 3, 0), c = wt, e = function(t, e) {
							let n = 0;
							return Tt(t, 99) > -1 && (n |= r), Tt(t, 114) > -1 && (n |= l), Tt(t, 108) > -1 && (n |= u), e > 0 && (n |= a), n;
						}(s, n);
					}
					G(t, s, Rt) === i ? (_ = /* @__PURE__ */ new WeakMap(), P(t, _), K(t, s, Rt)) : _ = tt(t, -1);
					let h = W(t, L + 1);
					return _.set(p, h), H(p, c, e, n), 0;
				},
				setlocal: function(t) {
					let e = Ot(t), n = e.thread, r = e.arg, a = new f(), u = ot(t, r + 1), l = ot(t, r + 2);
					if (!b(n, u, a)) return lt(t, r + 1, "level out of range");
					st(t, r + 3), Y(t, r + 3), bt(t, n, 1), at(t, n, 1);
					let s = X(n, a, l);
					return null === s && w(n, 1), V(t, s), 1;
				},
				setmetatable: function(t) {
					const e = et(t, 2);
					return ut(t, e == i || e == c, 2, "nil or table expected"), Y(t, 2), z(t, 1), 1;
				},
				setupvalue: function(t) {
					return st(t, 3), mt(t, 0);
				},
				setuservalue: function(t) {
					return ct(t, 1, _), st(t, 2), Y(t, 2), Z(t, 1), 1;
				},
				traceback: function(t) {
					let e = Ot(t), n = e.thread, r = e.arg, a = Q(t, r + 1);
					if (null !== a || m(t, r + 1)) {
						let e = Lt(t, r + 2, t === n ? 1 : 0);
						dt(t, n, a, e);
					} else B(t, r + 1);
					return 1;
				},
				upvalueid: function(t) {
					let e = Nt(t, 1, 2);
					return P(t, nt(t, 1, e)), 1;
				},
				upvaluejoin: function(t) {
					let e = Nt(t, 1, 2), n = Nt(t, 3, 4);
					return ut(t, !E(t, 1), 1, "Lua function expected"), ut(t, !E(t, 3), 3, "Lua function expected"), rt(t, 1, e, 3, n), 0;
				}
			};
			let yt;
			"undefined" != typeof window && (yt = function() {
				let t = prompt("lua_debug>", "");
				return null !== t ? t : "";
			}), yt && (It.debug = function(t) {
				for (;;) {
					let e = yt();
					if ("cont" === e) return 0;
					if (0 === e.length) continue;
					let n = xt(e);
					(ft(t, n, n.length, xt("=(debug command)", !0)) || S(t, 0, 0, 0)) && At(q(t, -1), "\n"), Y(t, 0);
				}
			});
			t.exports.luaopen_debug = function(t) {
				return pt(t, It), 1;
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_DIRSEP: r, LUA_EXEC_DIR: a, LUA_JSPATH_DEFAULT: u, LUA_PATH_DEFAULT: l, LUA_PATH_MARK: s, LUA_PATH_SEP: o } = n(3), { LUA_OK: i, LUA_REGISTRYINDEX: c, LUA_TNIL: _, LUA_TTABLE: f, lua_callk: p, lua_createtable: L, lua_getfield: h, lua_insert: d, lua_isfunction: A, lua_isnil: g, lua_isstring: T, lua_newtable: x, lua_pop: b, lua_pushboolean: O, lua_pushcclosure: k, lua_pushcfunction: v, lua_pushfstring: E, lua_pushglobaltable: U, lua_pushlightuserdata: m, lua_pushliteral: N, lua_pushlstring: R, lua_pushnil: S, lua_pushstring: w, lua_pushvalue: I, lua_rawgeti: y, lua_rawgetp: M, lua_rawseti: P, lua_rawsetp: C, lua_remove: D, lua_setfield: V, lua_setmetatable: B, lua_settop: G, lua_toboolean: K, lua_tostring: F, lua_touserdata: j, lua_upvalueindex: H } = n(2), { LUA_LOADED_TABLE: X, LUA_PRELOAD_TABLE: z, luaL_Buffer: Y, luaL_addvalue: J, luaL_buffinit: Z, luaL_checkstring: q, luaL_error: W, luaL_getsubtable: Q, luaL_gsub: $, luaL_len: tt, luaL_loadfile: et, luaL_newlib: nt, luaL_optstring: rt, luaL_pushresult: at, luaL_setfuncs: ut } = n(7), lt = n(17), { luastring_indexOf: st, to_jsstring: ot, to_luastring: it, to_uristring: ct } = n(5), _t = n(0), ft = "undefined" != typeof window ? window : "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? self : (0, eval)("this"), pt = it("__JSLIBS__"), Lt = r, ht = r, dt = it("luaopen_"), At = it("_"), gt = it("");
			let Tt = function(t, e, n) {
				e = ct(e);
				let r = new XMLHttpRequest();
				if (r.open("GET", e, !1), r.send(), r.status < 200 || r.status >= 300) return w(t, it(`${r.status}: ${r.statusText}`)), null;
				let a, u = r.response;
				/\/\/[#@] sourceURL=/.test(u) || (u += " //# sourceURL=" + e);
				try {
					a = Function("fengari", u);
				} catch (e) {
					return w(t, it(`${e.name}: ${e.message}`)), null;
				}
				let l = a(_t);
				return "function" == typeof l || "object" == typeof l && null !== l ? l : void 0 === l ? ft : (w(t, it(`library returned unexpected type (${typeof l})`)), null);
			};
			let xt = function(t) {
				t = ct(t);
				let e = new XMLHttpRequest();
				return e.open("GET", t, !1), e.send(), e.status >= 200 && e.status <= 299;
			};
			const bt = function(t, e, n) {
				let r = vt(t, e);
				if (null === r) {
					if (null === (r = Tt(t, e, n[0] === "*".charCodeAt(0)))) return 1;
					Et(t, e, r);
				}
				if (n[0] === "*".charCodeAt(0)) return O(t, 1), 0;
				{
					let e = function(t, e, n) {
						let r = e[ot(n)];
						return r && "function" == typeof r ? r : (E(t, it("undefined symbol: %s"), n), null);
					}(t, r, n);
					return null === e ? 2 : (v(t, e), 0);
				}
			}, Ot = ft, kt = function(t, e, n, r) {
				let a = `${n}${lt.LUA_VERSUFFIX}`;
				w(t, it(a));
				let u = Ot[a];
				void 0 === u && (u = Ot[n]), void 0 === u || function(t) {
					h(t, c, it("LUA_NOENV"));
					let e = K(t, -1);
					return b(t, 1), e;
				}(t) ? w(t, r) : (u = $(t, it(u), it(o + o, !0), it(o + ot(gt) + o, !0)), $(t, u, gt, r), D(t, -2)), V(t, -3, e), b(t, 1);
			}, vt = function(t, e) {
				M(t, c, pt), h(t, -1, e);
				let n = j(t, -1);
				return b(t, 2), n;
			}, Et = function(t, e, n) {
				M(t, c, pt), m(t, n), I(t, -1), V(t, -3, e), P(t, -2, tt(t, -2) + 1), b(t, 1);
			}, Ut = function(t, e) {
				for (; e[0] === o.charCodeAt(0);) e = e.subarray(1);
				if (0 === e.length) return null;
				let n = st(e, o.charCodeAt(0));
				return n < 0 && (n = e.length), R(t, e, n), e.subarray(n);
			}, mt = function(t, e, n, r, a) {
				let u = new Y();
				for (Z(t, u), 0 !== r[0] && (e = $(t, e, r, a)); null !== (n = Ut(t, n));) {
					let n = $(t, F(t, -1), it(s, !0), e);
					if (D(t, -2), xt(n)) return n;
					E(t, it("\n	no file '%s'"), n), D(t, -2), J(u);
				}
				return at(u), null;
			}, Nt = function(t, e, n, r) {
				h(t, H(1), n);
				let a = F(t, -1);
				return null === a && W(t, it("'package.%s' must be a string"), n), mt(t, e, a, it("."), r);
			}, Rt = function(t, e, n) {
				return e ? (w(t, n), 2) : W(t, it("error loading module '%s' from file '%s':\n	%s"), F(t, 1), n, F(t, -1));
			}, St = function(t) {
				let e = q(t, 1), n = Nt(t, e, it("path", !0), it(ht, !0));
				return null === n ? 1 : Rt(t, et(t, n) === i, n);
			}, wt = function(t, e, n) {
				let r;
				n = $(t, n, it("."), At);
				let a = st(n, "-".charCodeAt(0));
				if (a >= 0) {
					r = R(t, n, a), r = E(t, it("%s%s"), dt, r);
					let u = bt(t, e, r);
					if (2 !== u) return u;
					n = a + 1;
				}
				return r = E(t, it("%s%s"), dt, n), bt(t, e, r);
			}, It = function(t) {
				let e = q(t, 1), n = Nt(t, e, it("jspath", !0), it(Lt, !0));
				return null === n ? 1 : Rt(t, 0 === wt(t, n, e), n);
			}, yt = function(t) {
				let e, n = q(t, 1), r = st(n, ".".charCodeAt(0));
				if (r < 0) return 0;
				R(t, n, r);
				let a = Nt(t, F(t, -1), it("jspath", !0), it(Lt, !0));
				return null === a ? 1 : 0 !== (e = wt(t, a, n)) ? 2 != e ? Rt(t, 0, a) : (w(t, it("\n	no module '%s' in file '%s'"), n, a), 1) : (w(t, a), 2);
			}, Mt = function(t) {
				let e = q(t, 1);
				return h(t, c, z), h(t, -1, e) === _ && E(t, it("\n	no field package.preload['%s']"), e), 1;
			}, Pt = function(t, e, n) {
				for (; e === i ? (y(t, 3, n.i) === _ && (b(t, 1), at(n.msg), W(t, it("module '%s' not found:%s"), n.name, F(t, -1))), w(t, n.name), p(t, 1, 2, n, Pt)) : e = i, !A(t, -2); n.i++) T(t, -2) ? (b(t, 1), J(n.msg)) : b(t, 2);
				return n.k(t, i, n.ctx);
			}, Ct = function(t, e, n) {
				return w(t, n), d(t, -2), p(t, 2, 1, n, Dt), Dt(t, i, n);
			}, Dt = function(t, e, n) {
				let r = n;
				return g(t, -1) || V(t, 2, r), h(t, 2, r) == _ && (O(t, 1), I(t, -1), V(t, 2, r)), 1;
			}, Vt = {
				loadlib: function(t) {
					let e = q(t, 1), n = q(t, 2), r = bt(t, e, n);
					return 0 === r ? 1 : (S(t), d(t, -2), N(t, 1 === r ? "open" : "init"), 3);
				},
				searchpath: function(t) {
					return null !== mt(t, q(t, 1), q(t, 2), rt(t, 3, "."), rt(t, 4, r)) ? 1 : (S(t), d(t, -2), 2);
				}
			}, Bt = { require: function(t) {
				let e = q(t, 1);
				return G(t, 1), h(t, c, X), h(t, 2, e), K(t, -1) ? 1 : (b(t, 1), function(t, e, n, r) {
					let a = new Y();
					return Z(t, a), h(t, H(1), it("searchers", !0)) !== f && W(t, it("'package.searchers' must be a table")), Pt(t, i, {
						name: e,
						i: 1,
						msg: a,
						ctx: n,
						k: r
					});
				}(t, e, e, Ct));
			} };
			t.exports.luaopen_package = function(t) {
				return function(t) {
					x(t), L(t, 0, 1), B(t, -2), C(t, c, pt);
				}(t), nt(t, Vt), function(t) {
					let e = [
						Mt,
						St,
						It,
						yt,
						null
					];
					L(t);
					for (let n = 0; e[n]; n++) I(t, -2), k(t, e[n], 1), P(t, -2, n + 1);
					V(t, -2, it("searchers", !0));
				}(t), kt(t, it("path", !0), "LUA_PATH", l), kt(t, it("jspath", !0), "LUA_JSPATH", u), N(t, r + "\n" + o + "\n" + s + "\n" + a + "\n-\n"), V(t, -2, it("config", !0)), Q(t, c, X), V(t, -2, it("loaded", !0)), Q(t, c, z), V(t, -2, it("preload", !0)), U(t), I(t, -2), ut(t, Bt, 1), b(t, 1), 1;
			};
		},
		function(t, e, n) {
			const { lua_pushinteger: r, lua_pushliteral: a, lua_setfield: u } = n(2), { luaL_newlib: l } = n(7), { FENGARI_AUTHORS: s, FENGARI_COPYRIGHT: o, FENGARI_RELEASE: i, FENGARI_VERSION: c, FENGARI_VERSION_MAJOR: _, FENGARI_VERSION_MINOR: f, FENGARI_VERSION_NUM: p, FENGARI_VERSION_RELEASE: L, to_luastring: h } = n(5);
			t.exports.luaopen_fengari = function(t) {
				return l(t, {}), a(t, s), u(t, -2, h("AUTHORS")), a(t, o), u(t, -2, h("COPYRIGHT")), a(t, i), u(t, -2, h("RELEASE")), a(t, c), u(t, -2, h("VERSION")), a(t, _), u(t, -2, h("VERSION_MAJOR")), a(t, f), u(t, -2, h("VERSION_MINOR")), r(t, p), u(t, -2, h("VERSION_NUM")), a(t, L), u(t, -2, h("VERSION_RELEASE")), 1;
			};
		},
		function(t, e, n) {
			"use strict";
			n.r(e), n.d(e, "L", function() {
				return R;
			}), n.d(e, "load", function() {
				return S;
			});
			var r = n(0);
			n.d(e, "FENGARI_AUTHORS", function() {
				return r.FENGARI_AUTHORS;
			}), n.d(e, "FENGARI_COPYRIGHT", function() {
				return r.FENGARI_COPYRIGHT;
			}), n.d(e, "FENGARI_RELEASE", function() {
				return r.FENGARI_RELEASE;
			}), n.d(e, "FENGARI_VERSION", function() {
				return r.FENGARI_VERSION;
			}), n.d(e, "FENGARI_VERSION_MAJOR", function() {
				return r.FENGARI_VERSION_MAJOR;
			}), n.d(e, "FENGARI_VERSION_MINOR", function() {
				return r.FENGARI_VERSION_MINOR;
			}), n.d(e, "FENGARI_VERSION_NUM", function() {
				return r.FENGARI_VERSION_NUM;
			}), n.d(e, "FENGARI_VERSION_RELEASE", function() {
				return r.FENGARI_VERSION_RELEASE;
			}), n.d(e, "luastring_eq", function() {
				return r.luastring_eq;
			}), n.d(e, "luastring_indexOf", function() {
				return r.luastring_indexOf;
			}), n.d(e, "luastring_of", function() {
				return r.luastring_of;
			}), n.d(e, "to_jsstring", function() {
				return r.to_jsstring;
			}), n.d(e, "to_luastring", function() {
				return r.to_luastring;
			}), n.d(e, "to_uristring", function() {
				return r.to_uristring;
			}), n.d(e, "lua", function() {
				return r.lua;
			}), n.d(e, "lauxlib", function() {
				return r.lauxlib;
			}), n.d(e, "lualib", function() {
				return r.lualib;
			});
			var a = n(21);
			n.d(e, "interop", function() {
				return a;
			});
			const { LUA_ERRRUN: u, LUA_ERRSYNTAX: l, LUA_OK: s, LUA_VERSION_MAJOR: o, LUA_VERSION_MINOR: i, lua_Debug: c, lua_getinfo: _, lua_getstack: f, lua_gettop: p, lua_insert: L, lua_pcall: h, lua_pop: d, lua_pushcfunction: A, lua_pushstring: g, lua_remove: T, lua_setglobal: x, lua_tojsstring: b } = r.lua, { luaL_loadbuffer: O, luaL_newstate: k, luaL_requiref: v } = r.lauxlib, { checkjs: E, luaopen_js: U, push: m, tojs: N } = a, R = k();
			function S(t, e) {
				if ("string" == typeof t) t = Object(r.to_luastring)(t);
				else if (!(t instanceof Uint8Array)) throw new TypeError("expects an array of bytes or javascript string");
				e = e ? Object(r.to_luastring)(e) : null;
				let n, a = O(R, t, null, e);
				if (n = a === l ? new SyntaxError(b(R, -1)) : N(R, -1), d(R, 1), a !== s) throw n;
				return n;
			}
			if (r.lualib.luaL_openlibs(R), v(R, Object(r.to_luastring)("js"), U, 1), d(R, 1), g(R, Object(r.to_luastring)(r.FENGARI_COPYRIGHT)), x(R, Object(r.to_luastring)("_COPYRIGHT")), "undefined" != typeof document && document instanceof HTMLDocument) {
				const t = function(t) {
					switch (t) {
						case "anonymous": return "omit";
						case "use-credentials": return "include";
						default: return "same-origin";
					}
				}, e = function(t) {
					let e = new c();
					return f(t, 2, e) && _(t, Object(r.to_luastring)("Sl"), e), m(t, new ErrorEvent("error", {
						bubbles: !0,
						cancelable: !0,
						message: b(t, 1),
						error: N(t, 1),
						filename: e.short_src ? Object(r.to_jsstring)(e.short_src) : void 0,
						lineno: e.currentline > 0 ? e.currentline : void 0
					})), 1;
				}, n = function(t, n, r) {
					let a, o = O(R, n, null, r);
					if (o === l) {
						let e = b(R, -1), n = t.src ? t.src : document.location, r = void 0, u = new SyntaxError(e, n, r);
						a = new ErrorEvent("error", {
							message: e,
							error: u,
							filename: n,
							lineno: r
						});
					} else if (o === s) {
						let n = p(R);
						A(R, e), L(R, n), Object.defineProperty(document, "currentScript", {
							value: t,
							configurable: !0
						}), o = h(R, 0, 0, n), delete document.currentScript, T(R, n), o === u && (a = E(R, -1));
					}
					o !== s && (void 0 === a && (a = new ErrorEvent("error", {
						message: b(R, -1),
						error: N(R, -1)
					})), d(R, 1), window.dispatchEvent(a) && console.error("uncaught exception", a.error));
				}, a = function(t, e, a) {
					if (t.status >= 200 && t.status < 300) {
						let u = t.response;
						u = "string" == typeof u ? Object(r.to_luastring)(t.response) : new Uint8Array(u), n(e, u, a);
					} else e.dispatchEvent(new Event("error"));
				}, g = function(e) {
					if (e.src) {
						let u = Object(r.to_luastring)("@" + e.src);
						if ("complete" === document.readyState || e.async) if ("function" == typeof fetch) fetch(e.src, {
							method: "GET",
							credentials: t(e.crossorigin),
							redirect: "follow",
							integrity: e.integrity
						}).then(function(t) {
							if (t.ok) return t.arrayBuffer();
							throw new Error("unable to fetch");
						}).then(function(t) {
							let r = new Uint8Array(t);
							n(e, r, u);
						}).catch(function(t) {
							e.dispatchEvent(new Event("error"));
						});
						else {
							let t = new XMLHttpRequest();
							t.open("GET", e.src, !0), t.responseType = "arraybuffer", t.onreadystatechange = function() {
								4 === t.readyState && a(t, e, u);
							}, t.send();
						}
						else {
							let t = new XMLHttpRequest();
							t.open("GET", e.src, !1), t.send(), a(t, e, u);
						}
					} else {
						let t = Object(r.to_luastring)(e.innerHTML), a = e.id ? Object(r.to_luastring)("=" + e.id) : t;
						n(e, t, a);
					}
				}, x = /^(.*?\/.*?)([\t ]*;.*)?$/, k = /^(\d+)\.(\d+)$/, v = function(t) {
					if ("SCRIPT" !== t.tagName) return;
					let e = x.exec(t.type);
					if (!e) return;
					let n = e[1];
					if ("application/lua" === n || "text/lua" === n) {
						if (t.hasAttribute("lua-version")) {
							let e = k.exec(t.getAttribute("lua-version"));
							if (!e || e[1] !== o || e[2] !== i) return;
						}
						g(t);
					}
				};
				"undefined" != typeof MutationObserver ? new MutationObserver(function(t, e) {
					for (let e = 0; e < t.length; e++) {
						let n = t[e];
						for (let t = 0; t < n.addedNodes.length; t++) v(n.addedNodes[t]);
					}
				}).observe(document, {
					childList: !0,
					subtree: !0
				}) : console.warn && console.warn("fengari-web: MutationObserver not found; lua script tags will not be run when inserted");
				Array.prototype.forEach.call(document.querySelectorAll("script[type^=\"application/lua\"], script[type^=\"text/lua\"]"), v);
			}
		},
		function(t, e, n) {
			"use strict";
			const { LUA_MULTRET: r, LUA_OPADD: a, LUA_OPBAND: u, LUA_OPBNOT: l, LUA_OPBOR: s, LUA_OPBXOR: o, LUA_OPDIV: i, LUA_OPIDIV: c, LUA_OPMOD: _, LUA_OPSHL: f, LUA_OPSHR: p, LUA_OPUNM: L, constant_types: { LUA_TBOOLEAN: h, LUA_TLIGHTUSERDATA: d, LUA_TLNGSTR: A, LUA_TNIL: g, LUA_TNUMFLT: T, LUA_TNUMINT: x, LUA_TTABLE: b }, to_luastring: O } = n(1), { lua_assert: k } = n(4), v = n(20), E = n(6), U = n(16), m = n(23), N = n(9), R = n(15), S = U.OpCodesI, w = E.TValue, I = {
				OPR_ADD: 0,
				OPR_SUB: 1,
				OPR_MUL: 2,
				OPR_MOD: 3,
				OPR_POW: 4,
				OPR_DIV: 5,
				OPR_IDIV: 6,
				OPR_BAND: 7,
				OPR_BOR: 8,
				OPR_BXOR: 9,
				OPR_SHL: 10,
				OPR_SHR: 11,
				OPR_CONCAT: 12,
				OPR_EQ: 13,
				OPR_LT: 14,
				OPR_LE: 15,
				OPR_NE: 16,
				OPR_GT: 17,
				OPR_GE: 18,
				OPR_AND: 19,
				OPR_OR: 20,
				OPR_NOBINOPR: 21
			}, y = {
				OPR_MINUS: 0,
				OPR_BNOT: 1,
				OPR_NOT: 2,
				OPR_LEN: 3,
				OPR_NOUNOPR: 4
			}, M = function(t) {
				return t.t !== t.f;
			}, P = function(t, e) {
				let n = m.expkind;
				if (M(t)) return !1;
				switch (t.k) {
					case n.VKINT: return !e || new w(x, t.u.ival);
					case n.VKFLT: return !e || new w(T, t.u.nval);
					default: return !1;
				}
			}, C = function(t, e, n) {
				let r, a = e + n - 1;
				if (t.pc > t.lasttarget && (r = t.f.code[t.pc - 1]).opcode === S.OP_LOADNIL) {
					let t = r.A, n = t + r.B;
					if (t <= e && e <= n + 1 || e <= t && t <= a + 1) return t < e && (e = t), n > a && (a = n), U.SETARG_A(r, e), void U.SETARG_B(r, a - e);
				}
				Q(t, S.OP_LOADNIL, e, n - 1, 0);
			}, D = function(t, e) {
				return t.f.code[e.u.info];
			}, V = function(t, e) {
				let n = t.f.code[e].sBx;
				return -1 === n ? -1 : e + 1 + n;
			}, B = function(t, e, n) {
				let r = t.f.code[e], a = n - (e + 1);
				k(-1 !== n), Math.abs(a) > U.MAXARG_sBx && v.luaX_syntaxerror(t.ls, O("control structure too long", !0)), U.SETARG_sBx(r, a);
			}, G = function(t, e, n) {
				if (-1 === n) return e;
				if (-1 === e) e = n;
				else {
					let r = e, a = V(t, r);
					for (; -1 !== a;) a = V(t, r = a);
					B(t, r, n);
				}
				return e;
			}, K = function(t) {
				let e = t.jpc;
				t.jpc = -1;
				let n = tt(t, S.OP_JMP, 0, -1);
				return n = G(t, n, e);
			}, F = function(t, e, n, r, a) {
				return Q(t, e, n, r, a), K(t);
			}, j = function(t) {
				return t.lasttarget = t.pc, t.pc;
			}, H = function(t, e) {
				return e >= 1 && U.testTMode(t.f.code[e - 1].opcode) ? e - 1 : e;
			}, X = function(t, e) {
				return t.f.code[H(t, e)];
			}, z = function(t, e, n) {
				let r = H(t, e), a = t.f.code[r];
				return a.opcode === S.OP_TESTSET && (n !== U.NO_REG && n !== a.B ? U.SETARG_A(a, n) : t.f.code[r] = U.CREATE_ABC(S.OP_TEST, a.B, 0, a.C), !0);
			}, Y = function(t, e) {
				for (; -1 !== e; e = V(t, e)) z(t, e, U.NO_REG);
			}, J = function(t, e, n, r, a) {
				for (; -1 !== e;) {
					let u = V(t, e);
					z(t, e, r) ? B(t, e, n) : B(t, e, a), e = u;
				}
			}, Z = function(t, e) {
				j(t), t.jpc = G(t, t.jpc, e);
			}, q = function(t, e, n) {
				n === t.pc ? Z(t, e) : (k(n < t.pc), J(t, e, n, U.NO_REG, n));
			}, W = function(t, e) {
				let n = t.f;
				return function(t) {
					J(t, t.jpc, t.pc, U.NO_REG, t.pc), t.jpc = -1;
				}(t), n.code[t.pc] = e, n.lineinfo[t.pc] = t.ls.lastline, t.pc++;
			}, Q = function(t, e, n, r, a) {
				return k(U.getOpMode(e) === U.iABC), k(U.getBMode(e) !== U.OpArgN || 0 === r), k(U.getCMode(e) !== U.OpArgN || 0 === a), k(n <= U.MAXARG_A && r <= U.MAXARG_B && a <= U.MAXARG_C), W(t, U.CREATE_ABC(e, n, r, a));
			}, $ = function(t, e, n, r) {
				return k(U.getOpMode(e) === U.iABx || U.getOpMode(e) === U.iAsBx), k(U.getCMode(e) === U.OpArgN), k(n <= U.MAXARG_A && r <= U.MAXARG_Bx), W(t, U.CREATE_ABx(e, n, r));
			}, tt = function(t, e, n, r) {
				return $(t, e, n, r + U.MAXARG_sBx);
			}, et = function(t, e) {
				return k(e <= U.MAXARG_Ax), W(t, U.CREATE_Ax(S.OP_EXTRAARG, e));
			}, nt = function(t, e, n) {
				if (n <= U.MAXARG_Bx) return $(t, S.OP_LOADK, e, n);
				{
					let r = $(t, S.OP_LOADKX, e, 0);
					return et(t, n), r;
				}
			}, rt = function(t, e) {
				let n = t.freereg + e;
				n > t.f.maxstacksize && (n >= 255 && v.luaX_syntaxerror(t.ls, O("function or expression needs too many registers", !0)), t.f.maxstacksize = n);
			}, at = function(t, e) {
				rt(t, e), t.freereg += e;
			}, ut = function(t, e) {
				!U.ISK(e) && e >= t.nactvar && (t.freereg--, k(e === t.freereg));
			}, lt = function(t, e) {
				e.k === m.expkind.VNONRELOC && ut(t, e.u.info);
			}, st = function(t, e, n) {
				let r = e.k === m.expkind.VNONRELOC ? e.u.info : -1, a = n.k === m.expkind.VNONRELOC ? n.u.info : -1;
				r > a ? (ut(t, r), ut(t, a)) : (ut(t, a), ut(t, r));
			}, ot = function(t, e, n) {
				let r = t.f, a = N.luaH_get(t.L, t.ls.h, e);
				if (a.ttisinteger()) {
					let e = a.value;
					if (e < t.nk && r.k[e].ttype() === n.ttype() && r.k[e].value === n.value) return e;
				}
				let u = t.nk;
				return N.luaH_setfrom(t.L, t.ls.h, e, new E.TValue(x, u)), r.k[u] = n, t.nk++, u;
			}, it = function(t, e) {
				let n = new w(d, e), r = new w(x, e);
				return ot(t, n, r);
			}, ct = function(t, e) {
				let n = new w(T, e);
				return ot(t, n, n);
			}, _t = function(t, e) {
				let n = new w(h, e);
				return ot(t, n, n);
			}, ft = function(t, e, n) {
				let a = m.expkind;
				if (e.k === a.VCALL) U.SETARG_C(D(t, e), n + 1);
				else if (e.k === a.VVARARG) {
					let r = D(t, e);
					U.SETARG_B(r, n + 1), U.SETARG_A(r, t.freereg), at(t, 1);
				} else k(n === r);
			}, pt = function(t, e) {
				let n = m.expkind;
				e.k === n.VCALL ? (k(2 === D(t, e).C), e.k = n.VNONRELOC, e.u.info = D(t, e).A) : e.k === n.VVARARG && (U.SETARG_B(D(t, e), 2), e.k = n.VRELOCABLE);
			}, Lt = function(t, e) {
				let n = m.expkind;
				switch (e.k) {
					case n.VLOCAL:
						e.k = n.VNONRELOC;
						break;
					case n.VUPVAL:
						e.u.info = Q(t, S.OP_GETUPVAL, 0, e.u.info, 0), e.k = n.VRELOCABLE;
						break;
					case n.VINDEXED: {
						let r;
						ut(t, e.u.ind.idx), e.u.ind.vt === n.VLOCAL ? (ut(t, e.u.ind.t), r = S.OP_GETTABLE) : (k(e.u.ind.vt === n.VUPVAL), r = S.OP_GETTABUP), e.u.info = Q(t, r, 0, e.u.ind.t, e.u.ind.idx), e.k = n.VRELOCABLE;
						break;
					}
					case n.VVARARG:
					case n.VCALL: pt(t, e);
				}
			}, ht = function(t, e, n, r) {
				return j(t), Q(t, S.OP_LOADBOOL, e, n, r);
			}, dt = function(t, e, n) {
				let r = m.expkind;
				switch (Lt(t, e), e.k) {
					case r.VNIL:
						C(t, n, 1);
						break;
					case r.VFALSE:
					case r.VTRUE:
						Q(t, S.OP_LOADBOOL, n, e.k === r.VTRUE, 0);
						break;
					case r.VK:
						nt(t, n, e.u.info);
						break;
					case r.VKFLT:
						nt(t, n, ct(t, e.u.nval));
						break;
					case r.VKINT:
						nt(t, n, it(t, e.u.ival));
						break;
					case r.VRELOCABLE: {
						let r = D(t, e);
						U.SETARG_A(r, n);
						break;
					}
					case r.VNONRELOC:
						n !== e.u.info && Q(t, S.OP_MOVE, n, e.u.info, 0);
						break;
					default:
						k(e.k === r.VJMP);
						return;
				}
				e.u.info = n, e.k = r.VNONRELOC;
			}, At = function(t, e) {
				e.k !== m.expkind.VNONRELOC && (at(t, 1), dt(t, e, t.freereg - 1));
			}, gt = function(t, e) {
				for (; -1 !== e; e = V(t, e)) if (X(t, e).opcode !== S.OP_TESTSET) return !0;
				return !1;
			}, Tt = function(t, e, n) {
				let r = m.expkind;
				if (dt(t, e, n), e.k === r.VJMP && (e.t = G(t, e.t, e.u.info)), M(e)) {
					let a, u = -1, l = -1;
					if (gt(t, e.t) || gt(t, e.f)) {
						let a = e.k === r.VJMP ? -1 : K(t);
						u = ht(t, n, 0, 1), l = ht(t, n, 1, 0), Z(t, a);
					}
					a = j(t), J(t, e.f, a, n, u), J(t, e.t, a, n, l);
				}
				e.f = e.t = -1, e.u.info = n, e.k = r.VNONRELOC;
			}, xt = function(t, e) {
				Lt(t, e), lt(t, e), at(t, 1), Tt(t, e, t.freereg - 1);
			}, bt = function(t, e) {
				if (Lt(t, e), e.k === m.expkind.VNONRELOC) {
					if (!M(e)) return e.u.info;
					if (e.u.info >= t.nactvar) return Tt(t, e, e.u.info), e.u.info;
				}
				return xt(t, e), e.u.info;
			}, Ot = function(t, e) {
				M(e) ? bt(t, e) : Lt(t, e);
			}, kt = function(t, e) {
				let n = m.expkind, r = !1;
				switch (Ot(t, e), e.k) {
					case n.VTRUE:
						e.u.info = _t(t, !0), r = !0;
						break;
					case n.VFALSE:
						e.u.info = _t(t, !1), r = !0;
						break;
					case n.VNIL:
						e.u.info = function(t) {
							let e = new w(g, null), n = new w(b, t.ls.h);
							return ot(t, n, e);
						}(t), r = !0;
						break;
					case n.VKINT:
						e.u.info = it(t, e.u.ival), r = !0;
						break;
					case n.VKFLT:
						e.u.info = ct(t, e.u.nval), r = !0;
						break;
					case n.VK: r = !0;
				}
				return r && (e.k = n.VK, e.u.info <= U.MAXINDEXRK) ? U.RKASK(e.u.info) : bt(t, e);
			}, vt = function(t, e) {
				let n = X(t, e.u.info);
				k(U.testTMode(n.opcode) && n.opcode !== S.OP_TESTSET && n.opcode !== S.OP_TEST), U.SETARG_A(n, !n.A);
			}, Et = function(t, e, n) {
				if (e.k === m.expkind.VRELOCABLE) {
					let r = D(t, e);
					if (r.opcode === S.OP_NOT) return t.pc--, F(t, S.OP_TEST, r.B, 0, !n);
				}
				return At(t, e), lt(t, e), F(t, S.OP_TESTSET, U.NO_REG, e.u.info, n);
			}, Ut = function(t, e) {
				let n, r = m.expkind;
				switch (Lt(t, e), e.k) {
					case r.VJMP:
						vt(t, e), n = e.u.info;
						break;
					case r.VK:
					case r.VKFLT:
					case r.VKINT:
					case r.VTRUE:
						n = -1;
						break;
					default: n = Et(t, e, 0);
				}
				e.f = G(t, e.f, n), Z(t, e.t), e.t = -1;
			}, mt = function(t, e) {
				let n, r = m.expkind;
				switch (Lt(t, e), e.k) {
					case r.VJMP:
						n = e.u.info;
						break;
					case r.VNIL:
					case r.VFALSE:
						n = -1;
						break;
					default: n = Et(t, e, 1);
				}
				e.t = G(t, e.t, n), Z(t, e.f), e.f = -1;
			}, Nt = function(t, e, n) {
				let r, a, L = m.expkind;
				if (!(r = P(e, !0)) || !(a = P(n, !0)) || !function(t, e, n) {
					switch (t) {
						case u:
						case s:
						case o:
						case f:
						case p:
						case l: return !1 !== R.tointeger(e) && !1 !== R.tointeger(n);
						case i:
						case c:
						case _: return 0 !== n.value;
						default: return 1;
					}
				}(t, r, a)) return 0;
				let h = new w();
				if (E.luaO_arith(null, t, r, a, h), h.ttisinteger()) e.k = L.VKINT, e.u.ival = h.value;
				else {
					let t = h.value;
					if (isNaN(t) || 0 === t) return !1;
					e.k = L.VKFLT, e.u.nval = t;
				}
				return !0;
			}, Rt = function(t, e, n, r, a) {
				let u = kt(t, r), l = kt(t, n);
				st(t, n, r), n.u.info = Q(t, e, 0, l, u), n.k = m.expkind.VRELOCABLE, St(t, a);
			}, St = function(t, e) {
				t.f.lineinfo[t.pc - 1] = e;
			};
			t.exports.BinOpr = I, t.exports.NO_JUMP = -1, t.exports.UnOpr = y, t.exports.getinstruction = D, t.exports.luaK_checkstack = rt, t.exports.luaK_code = W, t.exports.luaK_codeABC = Q, t.exports.luaK_codeABx = $, t.exports.luaK_codeAsBx = tt, t.exports.luaK_codek = nt, t.exports.luaK_concat = G, t.exports.luaK_dischargevars = Lt, t.exports.luaK_exp2RK = kt, t.exports.luaK_exp2anyreg = bt, t.exports.luaK_exp2anyregup = function(t, e) {
				(e.k !== m.expkind.VUPVAL || M(e)) && bt(t, e);
			}, t.exports.luaK_exp2nextreg = xt, t.exports.luaK_exp2val = Ot, t.exports.luaK_fixline = St, t.exports.luaK_getlabel = j, t.exports.luaK_goiffalse = mt, t.exports.luaK_goiftrue = Ut, t.exports.luaK_indexed = function(t, e, n) {
				let r = m.expkind;
				k(!M(e) && (m.vkisinreg(e.k) || e.k === r.VUPVAL)), e.u.ind.t = e.u.info, e.u.ind.idx = kt(t, n), e.u.ind.vt = e.k === r.VUPVAL ? r.VUPVAL : r.VLOCAL, e.k = r.VINDEXED;
			}, t.exports.luaK_infix = function(t, e, n) {
				switch (e) {
					case I.OPR_AND:
						Ut(t, n);
						break;
					case I.OPR_OR:
						mt(t, n);
						break;
					case I.OPR_CONCAT:
						xt(t, n);
						break;
					case I.OPR_ADD:
					case I.OPR_SUB:
					case I.OPR_MUL:
					case I.OPR_DIV:
					case I.OPR_IDIV:
					case I.OPR_MOD:
					case I.OPR_POW:
					case I.OPR_BAND:
					case I.OPR_BOR:
					case I.OPR_BXOR:
					case I.OPR_SHL:
					case I.OPR_SHR:
						P(n, !1) || kt(t, n);
						break;
					default: kt(t, n);
				}
			}, t.exports.luaK_intK = it, t.exports.luaK_jump = K, t.exports.luaK_jumpto = function(t, e) {
				return q(t, K(t), e);
			}, t.exports.luaK_nil = C, t.exports.luaK_numberK = ct, t.exports.luaK_patchclose = function(t, e, n) {
				for (n++; -1 !== e; e = V(t, e)) {
					let r = t.f.code[e];
					k(r.opcode === S.OP_JMP && (0 === r.A || r.A >= n)), U.SETARG_A(r, n);
				}
			}, t.exports.luaK_patchlist = q, t.exports.luaK_patchtohere = Z, t.exports.luaK_posfix = function(t, e, n, r, u) {
				let l = m.expkind;
				switch (e) {
					case I.OPR_AND:
						k(-1 === n.t), Lt(t, r), r.f = G(t, r.f, n.f), n.to(r);
						break;
					case I.OPR_OR:
						k(-1 === n.f), Lt(t, r), r.t = G(t, r.t, n.t), n.to(r);
						break;
					case I.OPR_CONCAT: {
						Ot(t, r);
						let e = D(t, r);
						r.k === l.VRELOCABLE && e.opcode === S.OP_CONCAT ? (k(n.u.info === e.B - 1), lt(t, n), U.SETARG_B(e, n.u.info), n.k = l.VRELOCABLE, n.u.info = r.u.info) : (xt(t, r), Rt(t, S.OP_CONCAT, n, r, u));
						break;
					}
					case I.OPR_ADD:
					case I.OPR_SUB:
					case I.OPR_MUL:
					case I.OPR_DIV:
					case I.OPR_IDIV:
					case I.OPR_MOD:
					case I.OPR_POW:
					case I.OPR_BAND:
					case I.OPR_BOR:
					case I.OPR_BXOR:
					case I.OPR_SHL:
					case I.OPR_SHR:
						Nt(e + a, n, r) || Rt(t, e + S.OP_ADD, n, r, u);
						break;
					case I.OPR_EQ:
					case I.OPR_LT:
					case I.OPR_LE:
					case I.OPR_NE:
					case I.OPR_GT:
					case I.OPR_GE: (function(t, e, n, r) {
						let a, u = m.expkind;
						n.k === u.VK ? a = U.RKASK(n.u.info) : (k(n.k === u.VNONRELOC), a = n.u.info);
						let l = kt(t, r);
						switch (st(t, n, r), e) {
							case I.OPR_NE:
								n.u.info = F(t, S.OP_EQ, 0, a, l);
								break;
							case I.OPR_GT:
							case I.OPR_GE: {
								let r = e - I.OPR_NE + S.OP_EQ;
								n.u.info = F(t, r, 1, l, a);
								break;
							}
							default: {
								let r = e - I.OPR_EQ + S.OP_EQ;
								n.u.info = F(t, r, 1, a, l);
								break;
							}
						}
						n.k = u.VJMP;
					})(t, e, n, r);
				}
				return n;
			}, t.exports.luaK_prefix = function(t, e, n, r) {
				let a = new m.expdesc();
				switch (a.k = m.expkind.VKINT, a.u.ival = a.u.nval = a.u.info = 0, a.t = -1, a.f = -1, e) {
					case y.OPR_MINUS:
					case y.OPR_BNOT: if (Nt(e + L, n, a)) break;
					case y.OPR_LEN:
						(function(t, e, n, r) {
							let a = bt(t, n);
							lt(t, n), n.u.info = Q(t, e, 0, a, 0), n.k = m.expkind.VRELOCABLE, St(t, r);
						})(t, e + S.OP_UNM, n, r);
						break;
					case y.OPR_NOT: (function(t, e) {
						let n = m.expkind;
						switch (Lt(t, e), e.k) {
							case n.VNIL:
							case n.VFALSE:
								e.k = n.VTRUE;
								break;
							case n.VK:
							case n.VKFLT:
							case n.VKINT:
							case n.VTRUE:
								e.k = n.VFALSE;
								break;
							case n.VJMP:
								vt(t, e);
								break;
							case n.VRELOCABLE:
							case n.VNONRELOC: At(t, e), lt(t, e), e.u.info = Q(t, S.OP_NOT, 0, e.u.info, 0), e.k = n.VRELOCABLE;
						}
						{
							let t = e.f;
							e.f = e.t, e.t = t;
						}
						Y(t, e.f), Y(t, e.t);
					})(t, n);
				}
			}, t.exports.luaK_reserveregs = at, t.exports.luaK_ret = function(t, e, n) {
				Q(t, S.OP_RETURN, e, n + 1, 0);
			}, t.exports.luaK_self = function(t, e, n) {
				bt(t, e);
				let r = e.u.info;
				lt(t, e), e.u.info = t.freereg, e.k = m.expkind.VNONRELOC, at(t, 2), Q(t, S.OP_SELF, e.u.info, r, kt(t, n)), lt(t, n);
			}, t.exports.luaK_setlist = function(t, e, n, a) {
				let u = (n - 1) / U.LFIELDS_PER_FLUSH + 1, l = a === r ? 0 : a;
				k(0 !== a && a <= U.LFIELDS_PER_FLUSH), u <= U.MAXARG_C ? Q(t, S.OP_SETLIST, e, l, u) : u <= U.MAXARG_Ax ? (Q(t, S.OP_SETLIST, e, l, 0), et(t, u)) : v.luaX_syntaxerror(t.ls, O("constructor too long", !0)), t.freereg = e + 1;
			}, t.exports.luaK_setmultret = function(t, e) {
				ft(t, e, r);
			}, t.exports.luaK_setoneret = pt, t.exports.luaK_setreturns = ft, t.exports.luaK_storevar = function(t, e, n) {
				let r = m.expkind;
				switch (e.k) {
					case r.VLOCAL:
						lt(t, n), Tt(t, n, e.u.info);
						return;
					case r.VUPVAL: {
						let r = bt(t, n);
						Q(t, S.OP_SETUPVAL, r, e.u.info, 0);
						break;
					}
					case r.VINDEXED: {
						let a = e.u.ind.vt === r.VLOCAL ? S.OP_SETTABLE : S.OP_SETTABUP, u = kt(t, n);
						Q(t, a, e.u.ind.t, e.u.ind.idx, u);
						break;
					}
				}
				lt(t, n);
			}, t.exports.luaK_stringK = function(t, e) {
				let n = new w(A, e);
				return ot(t, n, n);
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_SIGNATURE: r, constant_types: { LUA_TBOOLEAN: a, LUA_TLNGSTR: u, LUA_TNIL: l, LUA_TNUMFLT: s, LUA_TNUMINT: o, LUA_TSHRSTR: i }, thread_status: { LUA_ERRSYNTAX: c }, is_luastring: _, luastring_eq: f, to_luastring: p } = n(1), L = n(8), h = n(13), d = n(6), { MAXARG_sBx: A, POS_A: g, POS_Ax: T, POS_B: x, POS_Bx: b, POS_C: O, POS_OP: k, SIZE_A: v, SIZE_Ax: E, SIZE_B: U, SIZE_Bx: m, SIZE_C: N, SIZE_OP: R } = n(16), { lua_assert: S } = n(4), { luaS_bless: w } = n(10), { luaZ_read: I, ZIO: y } = n(19);
			let M = [
				25,
				147,
				13,
				10,
				26,
				10
			];
			class P {
				constructor(t, e, n) {
					this.intSize = 4, this.size_tSize = 4, this.instructionSize = 4, this.integerSize = 4, this.numberSize = 8, S(e instanceof y, "BytecodeParser only operates on a ZIO"), S(_(n)), 64 === n[0] || 61 === n[0] ? this.name = n.subarray(1) : n[0] == r[0] ? this.name = p("binary string", !0) : this.name = n, this.L = t, this.Z = e, this.arraybuffer = new ArrayBuffer(Math.max(this.intSize, this.size_tSize, this.instructionSize, this.integerSize, this.numberSize)), this.dv = new DataView(this.arraybuffer), this.u8 = new Uint8Array(this.arraybuffer);
				}
				read(t) {
					let e = new Uint8Array(t);
					return 0 !== I(this.Z, e, 0, t) && this.error("truncated"), e;
				}
				LoadByte() {
					return 0 !== I(this.Z, this.u8, 0, 1) && this.error("truncated"), this.u8[0];
				}
				LoadInt() {
					return 0 !== I(this.Z, this.u8, 0, this.intSize) && this.error("truncated"), this.dv.getInt32(0, !0);
				}
				LoadNumber() {
					return 0 !== I(this.Z, this.u8, 0, this.numberSize) && this.error("truncated"), this.dv.getFloat64(0, !0);
				}
				LoadInteger() {
					return 0 !== I(this.Z, this.u8, 0, this.integerSize) && this.error("truncated"), this.dv.getInt32(0, !0);
				}
				LoadSize_t() {
					return this.LoadInteger();
				}
				LoadString() {
					let t = this.LoadByte();
					return 255 === t && (t = this.LoadSize_t()), 0 === t ? null : w(this.L, this.read(t - 1));
				}
				static MASK1(t, e) {
					return ~(-1 << t) << e;
				}
				LoadCode(t) {
					let e = this.LoadInt(), n = P;
					for (let r = 0; r < e; r++) {
						0 !== I(this.Z, this.u8, 0, this.instructionSize) && this.error("truncated");
						let e = this.dv.getUint32(0, !0);
						t.code[r] = {
							code: e,
							opcode: e >> k & n.MASK1(R, 0),
							A: e >> g & n.MASK1(v, 0),
							B: e >> x & n.MASK1(U, 0),
							C: e >> O & n.MASK1(N, 0),
							Bx: e >> b & n.MASK1(m, 0),
							Ax: e >> T & n.MASK1(E, 0),
							sBx: (e >> b & n.MASK1(m, 0)) - A
						};
					}
				}
				LoadConstants(t) {
					let e = this.LoadInt();
					for (let n = 0; n < e; n++) {
						let e = this.LoadByte();
						switch (e) {
							case l:
								t.k.push(new d.TValue(l, null));
								break;
							case a:
								t.k.push(new d.TValue(a, 0 !== this.LoadByte()));
								break;
							case s:
								t.k.push(new d.TValue(s, this.LoadNumber()));
								break;
							case o:
								t.k.push(new d.TValue(o, this.LoadInteger()));
								break;
							case i:
							case u:
								t.k.push(new d.TValue(u, this.LoadString()));
								break;
							default: this.error(`unrecognized constant '${e}'`);
						}
					}
				}
				LoadProtos(t) {
					let e = this.LoadInt();
					for (let n = 0; n < e; n++) t.p[n] = new h.Proto(this.L), this.LoadFunction(t.p[n], t.source);
				}
				LoadUpvalues(t) {
					let e = this.LoadInt();
					for (let n = 0; n < e; n++) t.upvalues[n] = {
						name: null,
						instack: this.LoadByte(),
						idx: this.LoadByte()
					};
				}
				LoadDebug(t) {
					let e = this.LoadInt();
					for (let n = 0; n < e; n++) t.lineinfo[n] = this.LoadInt();
					e = this.LoadInt();
					for (let n = 0; n < e; n++) t.locvars[n] = {
						varname: this.LoadString(),
						startpc: this.LoadInt(),
						endpc: this.LoadInt()
					};
					e = this.LoadInt();
					for (let n = 0; n < e; n++) t.upvalues[n].name = this.LoadString();
				}
				LoadFunction(t, e) {
					t.source = this.LoadString(), null === t.source && (t.source = e), t.linedefined = this.LoadInt(), t.lastlinedefined = this.LoadInt(), t.numparams = this.LoadByte(), t.is_vararg = 0 !== this.LoadByte(), t.maxstacksize = this.LoadByte(), this.LoadCode(t), this.LoadConstants(t), this.LoadUpvalues(t), this.LoadProtos(t), this.LoadDebug(t);
				}
				checkliteral(t, e) {
					let n = this.read(t.length);
					f(n, t) || this.error(e);
				}
				checkHeader() {
					this.checkliteral(r.subarray(1), "not a"), 83 !== this.LoadByte() && this.error("version mismatch in"), 0 !== this.LoadByte() && this.error("format mismatch in"), this.checkliteral(M, "corrupted"), this.intSize = this.LoadByte(), this.size_tSize = this.LoadByte(), this.instructionSize = this.LoadByte(), this.integerSize = this.LoadByte(), this.numberSize = this.LoadByte(), this.checksize(this.intSize, 4, "int"), this.checksize(this.size_tSize, 4, "size_t"), this.checksize(this.instructionSize, 4, "instruction"), this.checksize(this.integerSize, 4, "integer"), this.checksize(this.numberSize, 8, "number"), 22136 !== this.LoadInteger() && this.error("endianness mismatch in"), 370.5 !== this.LoadNumber() && this.error("float format mismatch in");
				}
				error(t) {
					d.luaO_pushfstring(this.L, p("%s: %s precompiled chunk"), this.name, p(t)), L.luaD_throw(this.L, c);
				}
				checksize(t, e, n) {
					t !== e && this.error(`${n} size mismatch in`);
				}
			}
			t.exports.luaU_undump = function(t, e, n) {
				let r = new P(t, e, n);
				r.checkHeader();
				let a = h.luaF_newLclosure(t, r.LoadByte());
				return L.luaD_inctop(t), t.stack[t.top - 1].setclLvalue(a), a.p = new h.Proto(t), r.LoadFunction(a.p, null), S(a.nupvalues === a.p.upvalues.length), a;
			};
		},
		function(t, e, n) {
			"use strict";
			const { LUA_SIGNATURE: r, LUA_VERSION_MAJOR: a, LUA_VERSION_MINOR: u, constant_types: { LUA_TBOOLEAN: l, LUA_TLNGSTR: s, LUA_TNIL: o, LUA_TNUMFLT: i, LUA_TNUMINT: c, LUA_TSHRSTR: _ }, luastring_of: f } = n(1), p = f(25, 147, 13, 10, 26, 10), L = 16 * Number(a) + Number(u);
			const h = function(t, e, n) {
				0 === n.status && e > 0 && (n.status = n.writer(n.L, t, e, n.data));
			}, d = function(t, e) {
				h(f(t), 1, e);
			}, A = function(t, e) {
				let n = /* @__PURE__ */ new ArrayBuffer(4);
				new DataView(n).setInt32(0, t, !0);
				let r = new Uint8Array(n);
				h(r, 4, e);
			}, g = function(t, e) {
				let n = /* @__PURE__ */ new ArrayBuffer(4);
				new DataView(n).setInt32(0, t, !0);
				let r = new Uint8Array(n);
				h(r, 4, e);
			}, T = function(t, e) {
				let n = /* @__PURE__ */ new ArrayBuffer(8);
				new DataView(n).setFloat64(0, t, !0);
				let r = new Uint8Array(n);
				h(r, 8, e);
			}, x = function(t, e) {
				if (null === t) d(0, e);
				else {
					let n = t.tsslen() + 1, r = t.getstr();
					n < 255 ? d(n, e) : (d(255, e), g(n, e)), h(r, n - 1, e);
				}
			}, b = function(t, e, n) {
				n.strip || t.source === e ? x(null, n) : x(t.source, n), A(t.linedefined, n), A(t.lastlinedefined, n), d(t.numparams, n), d(t.is_vararg ? 1 : 0, n), d(t.maxstacksize, n), function(t, e) {
					let n = t.code.map((t) => t.code);
					A(n.length, e);
					for (let t = 0; t < n.length; t++) A(n[t], e);
				}(t, n), function(t, e) {
					let n = t.k.length;
					A(n, e);
					for (let r = 0; r < n; r++) {
						let n = t.k[r];
						switch (d(n.ttype(), e), n.ttype()) {
							case o: break;
							case l:
								d(n.value ? 1 : 0, e);
								break;
							case i:
								T(n.value, e);
								break;
							case c:
								g(n.value, e);
								break;
							case _:
							case s: x(n.tsvalue(), e);
						}
					}
				}(t, n), function(t, e) {
					let n = t.upvalues.length;
					A(n, e);
					for (let r = 0; r < n; r++) d(t.upvalues[r].instack ? 1 : 0, e), d(t.upvalues[r].idx, e);
				}(t, n), function(t, e) {
					let n = t.p.length;
					A(n, e);
					for (let r = 0; r < n; r++) b(t.p[r], t.source, e);
				}(t, n), function(t, e) {
					let n = e.strip ? 0 : t.lineinfo.length;
					A(n, e);
					for (let r = 0; r < n; r++) A(t.lineinfo[r], e);
					n = e.strip ? 0 : t.locvars.length, A(n, e);
					for (let r = 0; r < n; r++) x(t.locvars[r].varname, e), A(t.locvars[r].startpc, e), A(t.locvars[r].endpc, e);
					n = e.strip ? 0 : t.upvalues.length, A(n, e);
					for (let r = 0; r < n; r++) x(t.upvalues[r].name, e);
				}(t, n);
			};
			t.exports.luaU_dump = function(t, e, n, a, u) {
				let l = new class {
					constructor() {
						this.L = null, this.write = null, this.data = null, this.strip = NaN, this.status = NaN;
					}
				}();
				return l.L = t, l.writer = n, l.data = a, l.strip = u, l.status = 0, function(t) {
					h(r, r.length, t), d(L, t), d(0, t), h(p, p.length, t), d(4, t), d(4, t), d(4, t), d(4, t), d(8, t), g(22136, t), T(370.5, t);
				}(l), d(e.upvalues.length, l), b(e, null, l), l.status;
			};
		},
		function(t, e, n) {
			var r;
			(function() {
				"use strict";
				var a = {
					not_string: /[^s]/,
					not_bool: /[^t]/,
					not_type: /[^T]/,
					not_primitive: /[^v]/,
					number: /[diefg]/,
					numeric_arg: /[bcdiefguxX]/,
					json: /[j]/,
					not_json: /[^j]/,
					text: /^[^\x25]+/,
					modulo: /^\x25{2}/,
					placeholder: /^\x25(?:([1-9]\d*)\$|\(([^\)]+)\))?(\+)?(0|'[^$])?(-)?(\d+)?(?:\.(\d+))?([b-gijostTuvxX])/,
					key: /^([a-z_][a-z_\d]*)/i,
					key_access: /^\.([a-z_][a-z_\d]*)/i,
					index_access: /^\[(\d+)\]/,
					sign: /^[\+\-]/
				};
				function u(t) {
					return function(t, e) {
						var n, r, l, s, o, i, c, _, f, p = 1, L = t.length, h = "";
						for (r = 0; r < L; r++) if ("string" == typeof t[r]) h += t[r];
						else if (Array.isArray(t[r])) {
							if ((s = t[r])[2]) for (n = e[p], l = 0; l < s[2].length; l++) {
								if (!n.hasOwnProperty(s[2][l])) throw new Error(u("[sprintf] property \"%s\" does not exist", s[2][l]));
								n = n[s[2][l]];
							}
							else n = s[1] ? e[s[1]] : e[p++];
							if (a.not_type.test(s[8]) && a.not_primitive.test(s[8]) && n instanceof Function && (n = n()), a.numeric_arg.test(s[8]) && "number" != typeof n && isNaN(n)) throw new TypeError(u("[sprintf] expecting number but found %T", n));
							switch (a.number.test(s[8]) && (_ = n >= 0), s[8]) {
								case "b":
									n = parseInt(n, 10).toString(2);
									break;
								case "c":
									n = String.fromCharCode(parseInt(n, 10));
									break;
								case "d":
								case "i":
									n = parseInt(n, 10);
									break;
								case "j":
									n = JSON.stringify(n, null, s[6] ? parseInt(s[6]) : 0);
									break;
								case "e":
									n = s[7] ? parseFloat(n).toExponential(s[7]) : parseFloat(n).toExponential();
									break;
								case "f":
									n = s[7] ? parseFloat(n).toFixed(s[7]) : parseFloat(n);
									break;
								case "g":
									n = s[7] ? String(Number(n.toPrecision(s[7]))) : parseFloat(n);
									break;
								case "o":
									n = (parseInt(n, 10) >>> 0).toString(8);
									break;
								case "s":
									n = String(n), n = s[7] ? n.substring(0, s[7]) : n;
									break;
								case "t":
									n = String(!!n), n = s[7] ? n.substring(0, s[7]) : n;
									break;
								case "T":
									n = Object.prototype.toString.call(n).slice(8, -1).toLowerCase(), n = s[7] ? n.substring(0, s[7]) : n;
									break;
								case "u":
									n = parseInt(n, 10) >>> 0;
									break;
								case "v":
									n = n.valueOf(), n = s[7] ? n.substring(0, s[7]) : n;
									break;
								case "x":
									n = (parseInt(n, 10) >>> 0).toString(16);
									break;
								case "X": n = (parseInt(n, 10) >>> 0).toString(16).toUpperCase();
							}
							a.json.test(s[8]) ? h += n : (!a.number.test(s[8]) || _ && !s[3] ? f = "" : (f = _ ? "+" : "-", n = n.toString().replace(a.sign, "")), i = s[4] ? "0" === s[4] ? "0" : s[4].charAt(1) : " ", c = s[6] - (f + n).length, o = s[6] && c > 0 ? i.repeat(c) : "", h += s[5] ? f + n + o : "0" === i ? f + o + n : o + f + n);
						}
						return h;
					}(function(t) {
						if (s[t]) return s[t];
						var e, n = t, r = [], u = 0;
						for (; n;) {
							if (null !== (e = a.text.exec(n))) r.push(e[0]);
							else if (null !== (e = a.modulo.exec(n))) r.push("%");
							else {
								if (null === (e = a.placeholder.exec(n))) throw new SyntaxError("[sprintf] unexpected placeholder");
								if (e[2]) {
									u |= 1;
									var l = [], o = e[2], i = [];
									if (null === (i = a.key.exec(o))) throw new SyntaxError("[sprintf] failed to parse named argument key");
									for (l.push(i[1]); "" !== (o = o.substring(i[0].length));) if (null !== (i = a.key_access.exec(o))) l.push(i[1]);
									else {
										if (null === (i = a.index_access.exec(o))) throw new SyntaxError("[sprintf] failed to parse named argument key");
										l.push(i[1]);
									}
									e[2] = l;
								} else u |= 2;
								if (3 === u) throw new Error("[sprintf] mixing positional and named placeholders is not (yet) supported");
								r.push(e);
							}
							n = n.substring(e[0].length);
						}
						return s[t] = r;
					}(t), arguments);
				}
				function l(t, e) {
					return u.apply(null, [t].concat(e || []));
				}
				var s = Object.create(null);
				e.sprintf = u, e.vsprintf = l, "undefined" != typeof window && (window.sprintf = u, window.vsprintf = l, void 0 === (r = function() {
					return {
						sprintf: u,
						vsprintf: l
					};
				}.call(e, n, e, t)) || (t.exports = r));
			})();
		},
		function(t, e, n) {
			"use strict";
			const { lua_pop: r } = n(2), { luaL_requiref: a } = n(7), { to_luastring: u } = n(5), l = {};
			t.exports.luaL_openlibs = function(t) {
				for (let e in l) a(t, u(e), l[e], 1), r(t, 1);
			};
			const s = n(17), { luaopen_base: o } = n(24), { luaopen_coroutine: i } = n(25), { luaopen_debug: c } = n(31), { luaopen_math: _ } = n(30), { luaopen_package: f } = n(32), { luaopen_os: p } = n(27), { luaopen_string: L } = n(28), { luaopen_table: h } = n(26), { luaopen_utf8: d } = n(29);
			l._G = o, l[s.LUA_LOADLIBNAME] = f, l[s.LUA_COLIBNAME] = i, l[s.LUA_TABLIBNAME] = h, l[s.LUA_OSLIBNAME] = p, l[s.LUA_STRLIBNAME] = L, l[s.LUA_MATHLIBNAME] = _, l[s.LUA_UTF8LIBNAME] = d, l[s.LUA_DBLIBNAME] = c;
			const { luaopen_fengari: A } = n(33);
			l[s.LUA_FENGARILIBNAME] = A;
		}
	]);
}));
//#endregion
export { require_fengari_web_bundle as t };
