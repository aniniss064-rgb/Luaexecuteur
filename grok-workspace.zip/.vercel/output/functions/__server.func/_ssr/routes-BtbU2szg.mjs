import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, i as Plus, o as Eraser, r as Trash2, s as BookOpen, t as X } from "../_libs/lucide-react.mjs";
import { t as require_fengari_web_bundle } from "../_libs/fengari-web.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BtbU2szg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_fengari_web_bundle = /* @__PURE__ */ __toESM(require_fengari_web_bundle());
var KEYWORDS = /* @__PURE__ */ new Set([
	"and",
	"break",
	"do",
	"else",
	"elseif",
	"end",
	"false",
	"for",
	"function",
	"goto",
	"if",
	"in",
	"local",
	"nil",
	"not",
	"or",
	"repeat",
	"return",
	"then",
	"true",
	"until",
	"while"
]);
var BUILTINS = /* @__PURE__ */ new Set([
	"assert",
	"collectgarbage",
	"error",
	"getmetatable",
	"ipairs",
	"next",
	"pairs",
	"pcall",
	"print",
	"rawequal",
	"rawget",
	"rawlen",
	"rawset",
	"select",
	"setmetatable",
	"tonumber",
	"tostring",
	"type",
	"xpcall",
	"math",
	"string",
	"table",
	"coroutine",
	"utf8"
]);
function push(tokens, text, kind) {
	if (!text) return;
	const last = tokens[tokens.length - 1];
	if (last && last.kind === kind) last.text += text;
	else tokens.push({
		text,
		kind
	});
}
function highlightLua(code) {
	const tokens = [];
	const length = code.length;
	let index = 0;
	while (index < length) {
		if (code.startsWith("--", index)) {
			if (code.startsWith("--[[", index)) {
				const end = code.indexOf("]]", index + 4);
				const next = end === -1 ? length : end + 2;
				push(tokens, code.slice(index, next), "cmt");
				index = next;
				continue;
			}
			const end = code.indexOf("\n", index);
			const next = end === -1 ? length : end;
			push(tokens, code.slice(index, next), "cmt");
			index = next;
			continue;
		}
		if (code.startsWith("[[", index) || code.startsWith("[", index)) {
			const fence = code.startsWith("[[", index) ? "]]" : null;
			if (fence) {
				const end = code.indexOf(fence, index + 2);
				const next = end === -1 ? length : end + fence.length;
				push(tokens, code.slice(index, next), "str");
				index = next;
				continue;
			}
		}
		const char = code[index] ?? "";
		if (char === "\"" || char === "'") {
			let next = index + 1;
			while (next < length) {
				if (code[next] === "\\") {
					next += 2;
					continue;
				}
				if (code[next] === char || code[next] === "\n") {
					if (code[next] === char) next += 1;
					break;
				}
				next += 1;
			}
			push(tokens, code.slice(index, next), "str");
			index = next;
			continue;
		}
		if (/[0-9]/.test(char) || char === "." && /[0-9]/.test(code[index + 1] ?? "")) {
			let next = index + 1;
			while (next < length && /[0-9a-fA-FxX.]/.test(code[next] ?? "")) next += 1;
			push(tokens, code.slice(index, next), "num");
			index = next;
			continue;
		}
		if (/[A-Za-z_]/.test(char)) {
			let next = index + 1;
			while (next < length && /[A-Za-z0-9_]/.test(code[next] ?? "")) next += 1;
			const word = code.slice(index, next);
			push(tokens, word, KEYWORDS.has(word) ? "kw" : BUILTINS.has(word) ? "fn" : "plain");
			index = next;
			continue;
		}
		push(tokens, char, "plain");
		index += 1;
	}
	return tokens;
}
var KIND_CLASS = {
	plain: "text-fg",
	kw: "text-accent",
	str: "text-danger",
	cmt: "text-muted",
	num: "text-fg",
	fn: "text-accent"
};
function lineAt(code, offset) {
	let line = 0;
	const end = Math.min(offset, code.length);
	for (let index = 0; index < end; index += 1) if (code[index] === "\n") line += 1;
	return line;
}
function LuaEditor({ value, onChange }) {
	const areaRef = (0, import_react.useRef)(null);
	const layerRef = (0, import_react.useRef)(null);
	const gutterRef = (0, import_react.useRef)(null);
	const [cursor, setCursor] = (0, import_react.useState)(0);
	const tokens = (0, import_react.useMemo)(() => highlightLua(value), [value]);
	const lineCount = value.split("\n").length;
	const activeLine = lineAt(value, cursor);
	function syncScroll() {
		const area = areaRef.current;
		const layer = layerRef.current;
		const gutter = gutterRef.current;
		if (!area || !layer || !gutter) return;
		layer.scrollTop = area.scrollTop;
		layer.scrollLeft = area.scrollLeft;
		gutter.scrollTop = area.scrollTop;
	}
	function onKeyDown(event) {
		if (event.key !== "Tab") return;
		event.preventDefault();
		const area = event.currentTarget;
		const start = area.selectionStart;
		const end = area.selectionEnd;
		onChange(`${value.slice(0, start)}  ${value.slice(end)}`);
		requestAnimationFrame(() => {
			area.selectionStart = start + 2;
			area.selectionEnd = start + 2;
			setCursor(start + 2);
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 flex bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: gutterRef,
			"aria-hidden": "true",
			className: "editor-code w-12 shrink-0 overflow-hidden border-r border-border bg-surface py-4 pr-2 text-right font-mono text-base leading-relaxed text-muted",
			children: Array.from({ length: lineCount }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: index === activeLine ? "text-fg" : void 0,
				children: index + 1
			}, index))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("pre", {
				ref: layerRef,
				"aria-hidden": "true",
				className: "editor-code pointer-events-none absolute inset-0 overflow-auto p-4 font-mono text-base leading-relaxed",
				children: [tokens.map((token, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: KIND_CLASS[token.kind],
					children: token.text
				}, index)), value.endsWith("\n") || value.length === 0 ? " " : null]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				ref: areaRef,
				value,
				"aria-label": "Éditeur Lua",
				spellCheck: false,
				autoCapitalize: "off",
				autoCorrect: "off",
				onScroll: syncScroll,
				onKeyDown,
				onChange: (event) => onChange(event.target.value),
				onSelect: (event) => setCursor(event.currentTarget.selectionStart),
				onClick: (event) => setCursor(event.currentTarget.selectionStart),
				className: "editor-code absolute inset-0 resize-none overflow-auto bg-transparent p-4 font-mono text-base leading-relaxed text-transparent caret-accent selection:bg-accent/30"
			})]
		})]
	});
}
var STARTER = `-- Lua 5.3, exécuté dans la page.
-- Ctrl + Entrée pour lancer.

print("Salut")

local function fib(n)
  if n < 2 then return n end
  return fib(n - 1) + fib(n - 2)
end

for i = 0, 12 do
  print(i, fib(i))
end

return "terminé"
`;
var EXAMPLES = [
	{
		name: "Découverte",
		blurb: "Variables, boucle, print",
		code: `local nom = "Niniss"
local annee = 2026

print("bonjour", nom)
print(string.format("%s · %d", nom, annee))

for i = 1, 5 do
  print(string.rep("·", i), i * i)
end
`
	},
	{
		name: "Tables",
		blurb: "Listes, clés, tri",
		code: `local notes = { ada = 18, linus = 15, grace = 20 }

local function moyenne(map)
  local total, n = 0, 0
  for _, note in pairs(map) do
    total = total + note
    n = n + 1
  end
  return total / n
end

print("moyenne", moyenne(notes))

local noms = {}
for nom in pairs(notes) do
  table.insert(noms, nom)
end
table.sort(noms)
for _, nom in ipairs(noms) do
  print(nom, notes[nom])
end
`
	},
	{
		name: "Fonctions",
		blurb: "Retour multiple, fermeture",
		code: `local function divmod(a, b)
  return math.floor(a / b), a % b
end

local q, r = divmod(17, 5)
print("17 =", q, "* 5 +", r)

local function compteur()
  local n = 0
  return function()
    n = n + 1
    return n
  end
end

local suivant = compteur()
print(suivant(), suivant(), suivant())
`
	},
	{
		name: "Coroutines",
		blurb: "yield et reprise",
		code: `local function ping()
  for i = 1, 3 do
    coroutine.yield("ping " .. i)
  end
  return "fini"
end

local co = coroutine.create(ping)
while coroutine.status(co) ~= "dead" do
  local ok, value = coroutine.resume(co)
  print(coroutine.status(co), ok, value)
end
`
	},
	{
		name: "Texte",
		blurb: "Motifs et utf8",
		code: `local phrase = "lua exécute, lua affiche"
local n = 0
for _ in string.gmatch(phrase, "lua") do
  n = n + 1
end
print("occurrences", n)
print("longueur utf8", utf8.len("exécution"))
print(string.upper("acide citron"))
`
	}
];
var { lauxlib, lua, lualib, to_jsstring, to_luastring } = import_fengari_web_bundle.default;
var TIMEOUT_MS = 1500;
var MAX_LINES = 400;
var MAX_CHARS = 2e3;
var LIBS$1 = [
	["_G", lualib.luaopen_base],
	["coroutine", lualib.luaopen_coroutine],
	["table", lualib.luaopen_table],
	["string", lualib.luaopen_string],
	["utf8", lualib.luaopen_utf8],
	["math", lualib.luaopen_math]
];
function clip(text) {
	if (text.length <= MAX_CHARS) return text;
	return `${text.slice(0, MAX_CHARS)}…`;
}
function prettyError(message) {
	const matched = message.match(/^(?:script:)?(\d+):\s*([\s\S]*)$/);
	if (!matched) return message;
	return `ligne ${matched[1]} — ${matched[2]}`;
}
function readString(L, index) {
	lauxlib.luaL_tolstring(L, index, null);
	const value = to_jsstring(lua.lua_tolstring(L, -1));
	lua.lua_pop(L, 1);
	return value;
}
function loadChunk(L, source) {
	if (lauxlib.luaL_loadbufferx(L, to_luastring(source), null, to_luastring("@script"), to_luastring("t")) === lua.LUA_OK) return null;
	const message = to_jsstring(lua.lua_tolstring(L, -1));
	lua.lua_pop(L, 1);
	return message;
}
function execute(code) {
	const lines = [];
	const L = lauxlib.luaL_newstate();
	for (const [name, opener] of LIBS$1) {
		lauxlib.luaL_requiref(L, to_luastring(name), opener, 1);
		lua.lua_pop(L, 1);
	}
	for (const banned of ["dofile", "loadfile"]) {
		lua.lua_pushnil(L);
		lua.lua_setglobal(L, to_luastring(banned));
	}
	lua.lua_pushjsfunction(L, (state) => {
		if (lines.length >= MAX_LINES) lauxlib.luaL_error(state, to_luastring(`sortie coupée à ${MAX_LINES} lignes`));
		const count = lua.lua_gettop(state);
		const parts = [];
		for (let index = 1; index <= count; index += 1) parts.push(readString(state, index));
		lines.push({
			kind: "out",
			text: clip(parts.join("	"))
		});
		return 0;
	});
	lua.lua_setglobal(L, to_luastring("print"));
	const started = Date.now();
	lua.lua_sethook(L, (state) => {
		if (Date.now() - started > TIMEOUT_MS) lauxlib.luaL_error(state, to_luastring("temps dépassé (1,5 s)"));
	}, lua.LUA_MASKCOUNT, 2e3);
	let error = loadChunk(L, code);
	if (error) {
		if (loadChunk(L, `return ${code}`)) return [{
			kind: "err",
			text: prettyError(error)
		}];
	}
	if (lua.lua_pcall(L, 0, lua.LUA_MULTRET, 0) !== lua.LUA_OK) {
		lines.push({
			kind: "err",
			text: prettyError(to_jsstring(lua.lua_tolstring(L, -1)))
		});
		return lines;
	}
	const returns = lua.lua_gettop(L);
	if (returns > 0) {
		const parts = [];
		for (let index = 1; index <= returns; index += 1) parts.push(readString(L, index));
		lines.push({
			kind: "ret",
			text: clip(parts.join("	"))
		});
	}
	if (lines.length === 0) lines.push({
		kind: "meta",
		text: "terminé, rien à afficher"
	});
	return lines;
}
function runLua(code) {
	const started = Date.now();
	if (!code.trim()) return {
		lines: [{
			kind: "meta",
			text: "Le script est vide."
		}],
		ms: 0
	};
	try {
		return {
			lines: execute(code),
			ms: Date.now() - started
		};
	} catch (error) {
		return {
			lines: [{
				kind: "err",
				text: error instanceof Error ? error.message : String(error)
			}],
			ms: Date.now() - started
		};
	}
}
var STORAGE_KEY = "lua-executor.v1";
var LIBS = [
	["print", "affiche des valeurs, séparées par une tabulation"],
	["math", "sin, cos, sqrt, floor, random, pi"],
	["string", "format, sub, upper, gmatch, rep"],
	["table", "insert, remove, sort, concat"],
	["coroutine", "create, resume, yield, status"],
	["utf8", "len, codes, char, offset"]
];
function fresh(name, code) {
	return {
		id: crypto.randomUUID(),
		name,
		code
	};
}
function loadStored() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed.docs?.length) return null;
		if (!parsed.docs.every((doc) => doc.id && typeof doc.code === "string")) return null;
		const activeId = parsed.docs.some((doc) => doc.id === parsed.activeId) ? parsed.activeId : parsed.docs[0].id;
		return {
			docs: parsed.docs,
			activeId
		};
	} catch {
		return null;
	}
}
function Executor() {
	const initial = fresh("fibonacci", STARTER);
	const [docs, setDocs] = (0, import_react.useState)([initial]);
	const [activeId, setActiveId] = (0, import_react.useState)(initial.id);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [lines, setLines] = (0, import_react.useState)([]);
	const [ms, setMs] = (0, import_react.useState)(null);
	const [panel, setPanel] = (0, import_react.useState)(null);
	const consoleRef = (0, import_react.useRef)(null);
	const active = docs.find((doc) => doc.id === activeId) ?? docs[0];
	const failed = lines.some((line) => line.kind === "err");
	(0, import_react.useEffect)(() => {
		const stored = loadStored();
		if (stored) {
			setDocs(stored.docs);
			setActiveId(stored.activeId);
		}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify({
			docs,
			activeId
		}));
	}, [
		docs,
		activeId,
		ready
	]);
	(0, import_react.useEffect)(() => {
		const node = consoleRef.current;
		if (node) node.scrollTop = node.scrollHeight;
	}, [lines]);
	function updateActive(code) {
		setDocs((current) => current.map((doc) => doc.id === active.id ? {
			...doc,
			code
		} : doc));
	}
	function renameActive(name) {
		setDocs((current) => current.map((doc) => doc.id === active.id ? {
			...doc,
			name
		} : doc));
	}
	function run() {
		const result = runLua(active.code);
		setLines(result.lines);
		setMs(result.ms);
	}
	function addDoc(example) {
		const doc = fresh(example?.name ?? "script", example?.code ?? "-- nouveau script\n\n");
		setDocs((current) => [...current, doc]);
		setActiveId(doc.id);
		setPanel(null);
	}
	function removeDoc(id) {
		setDocs((current) => {
			if (current.length === 1) {
				const doc = fresh("script", STARTER);
				setActiveId(doc.id);
				return [doc];
			}
			const next = current.filter((doc) => doc.id !== id);
			if (id === activeId) setActiveId(next[0].id);
			return next;
		});
	}
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (!(event.metaKey || event.ctrlKey) || event.key !== "Enter") return;
			event.preventDefault();
			const result = runLua(active.code);
			setLines(result.lines);
			setMs(result.ms);
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [active.code]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-dvh flex-col overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex shrink-0 items-center gap-3 border-b border-border px-3 py-2 sm:px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-sm font-semibold tracking-widest text-accent",
							children: "LUA"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-sans text-sm font-semibold tracking-wide",
							children: "EXECUTOR"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "5.3 dans la page · pas de fichiers"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-label": "Bibliothèque",
							onClick: () => setPanel(panel === "libs" ? null : "libs"),
							className: "inline-flex h-11 items-center gap-2 rounded-lg border border-border bg-surface px-3 text-sm text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Libs"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setPanel(panel === "examples" ? null : "examples"),
							className: "inline-flex h-11 items-center gap-2 rounded-lg border border-border bg-surface px-3 text-sm text-fg",
							children: "Exemples"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: run,
							className: "inline-flex h-11 items-center gap-2 rounded-lg bg-accent px-4 text-sm font-semibold text-accent-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Exécuter"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 items-center gap-2 overflow-x-auto border-b border-border px-3 py-2",
				children: [docs.map((doc) => {
					const selected = doc.id === active.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-11 shrink-0 items-center rounded-lg border " + (selected ? "border-accent bg-raised" : "border-border bg-surface"),
						children: [selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"aria-label": "Nom du script",
							value: doc.name,
							onChange: (event) => renameActive(event.target.value),
							className: "w-28 bg-transparent px-3 font-mono text-sm text-fg outline-none"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setActiveId(doc.id),
							className: "h-11 px-3 font-mono text-sm text-muted",
							children: doc.name || "script"
						}), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Supprimer le script",
							onClick: () => removeDoc(doc.id),
							className: "mr-1 inline-flex size-9 items-center justify-center text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						}) : null]
					}, doc.id);
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Nouveau script",
					onClick: () => addDoc(),
					className: "inline-flex size-11 shrink-0 items-center justify-center rounded-lg border border-border bg-surface text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col lg:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "relative min-h-0 flex-1 border-b border-border lg:border-r lg:border-b-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LuaEditor, {
						value: active.code,
						onChange: updateActive
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex h-64 shrink-0 flex-col lg:h-auto lg:w-96",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-11 shrink-0 items-center gap-2 border-b border-border px-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs tracking-widest text-muted",
									children: "CONSOLE"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto font-mono text-xs " + (failed ? "text-danger" : "text-muted"),
									children: ms === null ? "prêt" : failed ? `erreur · ${ms} ms` : `ok · ${ms} ms`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Effacer la console",
									onClick: () => {
										setLines([]);
										setMs(null);
									},
									className: "inline-flex size-9 items-center justify-center text-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, { className: "size-4" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: consoleRef,
							className: "min-h-0 flex-1 overflow-auto p-3 font-mono text-sm leading-relaxed",
							children: lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: "Aucune sortie. Écris du Lua, puis exécute."
							}) : lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: line.kind === "err" ? "whitespace-pre-wrap text-danger" : line.kind === "ret" ? "whitespace-pre-wrap text-accent" : line.kind === "meta" ? "whitespace-pre-wrap text-muted" : "whitespace-pre-wrap text-fg",
								children: line.kind === "ret" ? `← ${line.text}` : line.text
							}, index))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "shrink-0 border-t border-border px-3 py-2 font-mono text-xs text-muted",
							children: "Ctrl + Entrée · io, os et les fichiers sont absents"
						})
					]
				})]
			}),
			panel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-end bg-bg/80 p-3 sm:items-center sm:justify-center",
				onClick: () => setPanel(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex max-h-full w-full max-w-lg flex-col overflow-hidden rounded-lg border border-border bg-surface",
					onClick: (event) => event.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-12 items-center border-b border-border px-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: panel === "examples" ? "Exemples" : "Bibliothèque"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Fermer",
							onClick: () => setPanel(null),
							className: "ml-auto inline-flex size-11 items-center justify-center text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-auto p-2",
						children: panel === "examples" ? EXAMPLES.map((example) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => addDoc(example),
							className: "flex w-full flex-col items-start gap-1 rounded-lg px-3 py-3 text-left hover:bg-raised",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-sm text-accent",
								children: example.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: example.blurb
							})]
						}, example.name)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-1 px-1 py-1",
							children: [LIBS.map(([name, detail]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "px-2 py-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-accent",
									children: name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted",
									children: [" — ", detail]
								})]
							}, name)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-2 py-3 text-sm text-muted",
								children: "Pas de io, os, require, dofile ni loadfile. Le script s’arrête au bout de 1,5 s."
							})]
						})
					})]
				})
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Executor, {});
}
//#endregion
export { Home as component };
