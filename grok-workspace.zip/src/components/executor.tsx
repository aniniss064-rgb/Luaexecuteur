import { useEffect, useRef, useState } from "react";
import { BookOpen, Eraser, Play, Plus, Trash2, X } from "lucide-react";
import { LuaEditor } from "@/components/lua-editor";
import { EXAMPLES, STARTER, type Example } from "@/lib/examples";
import { runLua, type LuaLine } from "@/lib/lua-run";

type Doc = {
  id: string;
  name: string;
  code: string;
};

const STORAGE_KEY = "lua-executor.v1";

const LIBS = [
  ["print", "affiche des valeurs, séparées par une tabulation"],
  ["math", "sin, cos, sqrt, floor, random, pi"],
  ["string", "format, sub, upper, gmatch, rep"],
  ["table", "insert, remove, sort, concat"],
  ["coroutine", "create, resume, yield, status"],
  ["utf8", "len, codes, char, offset"],
];

function fresh(name: string, code: string): Doc {
  return { id: crypto.randomUUID(), name, code };
}

function loadStored(): { docs: Doc[]; activeId: string } | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { docs?: Doc[]; activeId?: string };
    if (!parsed.docs?.length) return null;
    if (!parsed.docs.every((doc) => doc.id && typeof doc.code === "string")) return null;
    const activeId = parsed.docs.some((doc) => doc.id === parsed.activeId)
      ? parsed.activeId!
      : parsed.docs[0]!.id;
    return { docs: parsed.docs, activeId };
  } catch {
    return null;
  }
}

export function Executor() {
  const initial = fresh("fibonacci", STARTER);
  const [docs, setDocs] = useState<Doc[]>([initial]);
  const [activeId, setActiveId] = useState(initial.id);
  const [ready, setReady] = useState(false);
  const [lines, setLines] = useState<LuaLine[]>([]);
  const [ms, setMs] = useState<number | null>(null);
  const [panel, setPanel] = useState<"examples" | "libs" | null>(null);
  const consoleRef = useRef<HTMLDivElement>(null);

  const active = docs.find((doc) => doc.id === activeId) ?? docs[0]!;
  const failed = lines.some((line) => line.kind === "err");

  useEffect(() => {
    const stored = loadStored();
    if (stored) {
      setDocs(stored.docs);
      setActiveId(stored.activeId);
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ docs, activeId }));
  }, [docs, activeId, ready]);

  useEffect(() => {
    const node = consoleRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [lines]);

  function updateActive(code: string) {
    setDocs((current) => current.map((doc) => (doc.id === active.id ? { ...doc, code } : doc)));
  }

  function renameActive(name: string) {
    setDocs((current) => current.map((doc) => (doc.id === active.id ? { ...doc, name } : doc)));
  }

  function run() {
    const result = runLua(active.code);
    setLines(result.lines);
    setMs(result.ms);
  }

  function addDoc(example?: Example) {
    const doc = fresh(example?.name ?? "script", example?.code ?? "-- nouveau script\n\n");
    setDocs((current) => [...current, doc]);
    setActiveId(doc.id);
    setPanel(null);
  }

  function removeDoc(id: string) {
    setDocs((current) => {
      if (current.length === 1) {
        const doc = fresh("script", STARTER);
        setActiveId(doc.id);
        return [doc];
      }
      const next = current.filter((doc) => doc.id !== id);
      if (id === activeId) setActiveId(next[0]!.id);
      return next;
    });
  }

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (!(event.metaKey || event.ctrlKey) || event.key !== "Enter") return;
      event.preventDefault();
      const result = runLua(active.code);
      setLines(result.lines);
      setMs(result.ms);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active.code]);

  return (
    <div className="relative flex h-dvh flex-col overflow-hidden bg-bg text-fg">
      <header className="flex shrink-0 items-center gap-3 border-b border-border px-3 py-2 sm:px-4">
        <div className="min-w-0">
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-sm font-semibold tracking-widest text-accent">LUA</span>
            <span className="font-sans text-sm font-semibold tracking-wide">EXECUTOR</span>
          </div>
          <p className="text-xs text-muted">5.3 dans la page · pas de fichiers</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button
            type="button"
            aria-label="Bibliothèque"
            onClick={() => setPanel(panel === "libs" ? null : "libs")}
            className="inline-flex h-11 items-center gap-2 rounded-lg border border-border bg-surface px-3 text-sm text-fg"
          >
            <BookOpen className="size-4 text-muted" />
            <span className="hidden sm:inline">Libs</span>
          </button>
          <button
            type="button"
            onClick={() => setPanel(panel === "examples" ? null : "examples")}
            className="inline-flex h-11 items-center gap-2 rounded-lg border border-border bg-surface px-3 text-sm text-fg"
          >
            Exemples
          </button>
          <button
            type="button"
            onClick={run}
            className="inline-flex h-11 items-center gap-2 rounded-lg bg-accent px-4 text-sm font-semibold text-accent-ink"
          >
            <Play className="size-4" />
            Exécuter
          </button>
        </div>
      </header>

      <div className="flex shrink-0 items-center gap-2 overflow-x-auto border-b border-border px-3 py-2">
        {docs.map((doc) => {
          const selected = doc.id === active.id;
          return (
            <div
              key={doc.id}
              className={
                "flex h-11 shrink-0 items-center rounded-lg border " +
                (selected ? "border-accent bg-raised" : "border-border bg-surface")
              }
            >
              {selected ? (
                <input
                  aria-label="Nom du script"
                  value={doc.name}
                  onChange={(event) => renameActive(event.target.value)}
                  className="w-28 bg-transparent px-3 font-mono text-sm text-fg outline-none"
                />
              ) : (
                <button
                  type="button"
                  onClick={() => setActiveId(doc.id)}
                  className="h-11 px-3 font-mono text-sm text-muted"
                >
                  {doc.name || "script"}
                </button>
              )}
              {selected ? (
                <button
                  type="button"
                  aria-label="Supprimer le script"
                  onClick={() => removeDoc(doc.id)}
                  className="mr-1 inline-flex size-9 items-center justify-center text-muted"
                >
                  <Trash2 className="size-4" />
                </button>
              ) : null}
            </div>
          );
        })}
        <button
          type="button"
          aria-label="Nouveau script"
          onClick={() => addDoc()}
          className="inline-flex size-11 shrink-0 items-center justify-center rounded-lg border border-border bg-surface text-fg"
        >
          <Plus className="size-4" />
        </button>
      </div>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <section className="relative min-h-0 flex-1 border-b border-border lg:border-r lg:border-b-0">
          <LuaEditor value={active.code} onChange={updateActive} />
        </section>
        <section className="flex h-64 shrink-0 flex-col lg:h-auto lg:w-96">
          <div className="flex h-11 shrink-0 items-center gap-2 border-b border-border px-3">
            <span className="font-mono text-xs tracking-widest text-muted">CONSOLE</span>
            <span className={"ml-auto font-mono text-xs " + (failed ? "text-danger" : "text-muted")}>
              {ms === null ? "prêt" : failed ? `erreur · ${ms} ms` : `ok · ${ms} ms`}
            </span>
            <button
              type="button"
              aria-label="Effacer la console"
              onClick={() => {
                setLines([]);
                setMs(null);
              }}
              className="inline-flex size-9 items-center justify-center text-muted"
            >
              <Eraser className="size-4" />
            </button>
          </div>
          <div ref={consoleRef} className="min-h-0 flex-1 overflow-auto p-3 font-mono text-sm leading-relaxed">
            {lines.length === 0 ? (
              <p className="text-muted">Aucune sortie. Écris du Lua, puis exécute.</p>
            ) : (
              lines.map((line, index) => (
                <p
                  key={index}
                  className={
                    line.kind === "err"
                      ? "whitespace-pre-wrap text-danger"
                      : line.kind === "ret"
                        ? "whitespace-pre-wrap text-accent"
                        : line.kind === "meta"
                          ? "whitespace-pre-wrap text-muted"
                          : "whitespace-pre-wrap text-fg"
                  }
                >
                  {line.kind === "ret" ? `← ${line.text}` : line.text}
                </p>
              ))
            )}
          </div>
          <p className="shrink-0 border-t border-border px-3 py-2 font-mono text-xs text-muted">
            Ctrl + Entrée · io, os et les fichiers sont absents
          </p>
        </section>
      </div>

      {panel ? (
        <div
        className="absolute inset-0 z-20 flex items-end bg-bg/80 p-3 sm:items-center sm:justify-center"
        onClick={() => setPanel(null)}
      >
        <div
          className="flex max-h-full w-full max-w-lg flex-col overflow-hidden rounded-lg border border-border bg-surface"
          onClick={(event) => event.stopPropagation()}
        >
            <div className="flex h-12 items-center border-b border-border px-3">
              <h2 className="text-sm font-semibold">{panel === "examples" ? "Exemples" : "Bibliothèque"}</h2>
              <button
                type="button"
                aria-label="Fermer"
                onClick={() => setPanel(null)}
                className="ml-auto inline-flex size-11 items-center justify-center text-muted"
              >
                <X className="size-4" />
              </button>
            </div>
            <div className="overflow-auto p-2">
              {panel === "examples" ? (
                EXAMPLES.map((example) => (
                  <button
                    key={example.name}
                    type="button"
                    onClick={() => addDoc(example)}
                    className="flex w-full flex-col items-start gap-1 rounded-lg px-3 py-3 text-left hover:bg-raised"
                  >
                    <span className="font-mono text-sm text-accent">{example.name}</span>
                    <span className="text-sm text-muted">{example.blurb}</span>
                  </button>
                ))
              ) : (
                <div className="flex flex-col gap-1 px-1 py-1">
                  {LIBS.map(([name, detail]) => (
                    <p key={name} className="px-2 py-2 text-sm">
                      <span className="font-mono text-accent">{name}</span>
                      <span className="text-muted"> — {detail}</span>
                    </p>
                  ))}
                  <p className="px-2 py-3 text-sm text-muted">
                    Pas de io, os, require, dofile ni loadfile. Le script s’arrête au bout de 1,5 s.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
