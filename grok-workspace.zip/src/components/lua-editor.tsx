import { useMemo, useRef, useState, type KeyboardEvent } from "react";
import { highlightLua, type TokenKind } from "@/lib/highlight-lua";

const KIND_CLASS: Record<TokenKind, string> = {
  plain: "text-fg",
  kw: "text-accent",
  str: "text-danger",
  cmt: "text-muted",
  num: "text-fg",
  fn: "text-accent",
};

type LuaEditorProps = {
  value: string;
  onChange: (value: string) => void;
};

function lineAt(code: string, offset: number): number {
  let line = 0;
  const end = Math.min(offset, code.length);
  for (let index = 0; index < end; index += 1) {
    if (code[index] === "\n") line += 1;
  }
  return line;
}

export function LuaEditor({ value, onChange }: LuaEditorProps) {
  const areaRef = useRef<HTMLTextAreaElement>(null);
  const layerRef = useRef<HTMLPreElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);
  const [cursor, setCursor] = useState(0);
  const tokens = useMemo(() => highlightLua(value), [value]);
  const lineCount = value.split("\n").length;
  const activeLine = lineAt(value, cursor);

  function syncScroll() {
    const area = areaRef.current;
    const layer = layerRef.current;
    const gutter = gutterRef.current;
    if (!area || !layer || !gutter) return;
    layer.scrollTop = area.scrollTop;
    layer.scrollLeft = area.scrollLeft;
    gutter.scrollTop = area.scrollTop;
  }

  function onKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key !== "Tab") return;
    event.preventDefault();
    const area = event.currentTarget;
    const start = area.selectionStart;
    const end = area.selectionEnd;
    const next = `${value.slice(0, start)}  ${value.slice(end)}`;
    onChange(next);
    requestAnimationFrame(() => {
      area.selectionStart = start + 2;
      area.selectionEnd = start + 2;
      setCursor(start + 2);
    });
  }

  return (
    <div className="absolute inset-0 flex bg-bg">
      <div
        ref={gutterRef}
        aria-hidden="true"
        className="editor-code w-12 shrink-0 overflow-hidden border-r border-border bg-surface py-4 pr-2 text-right font-mono text-base leading-relaxed text-muted"
      >
        {Array.from({ length: lineCount }, (_, index) => (
          <div key={index} className={index === activeLine ? "text-fg" : undefined}>
            {index + 1}
          </div>
        ))}
      </div>
      <div className="relative min-w-0 flex-1">
        <pre
          ref={layerRef}
          aria-hidden="true"
          className="editor-code pointer-events-none absolute inset-0 overflow-auto p-4 font-mono text-base leading-relaxed"
        >
          {tokens.map((token, index) => (
            <span key={index} className={KIND_CLASS[token.kind]}>
              {token.text}
            </span>
          ))}
          {value.endsWith("\n") || value.length === 0 ? " " : null}
        </pre>
        <textarea
          ref={areaRef}
          value={value}
          aria-label="Éditeur Lua"
          spellCheck={false}
          autoCapitalize="off"
          autoCorrect="off"
          onScroll={syncScroll}
          onKeyDown={onKeyDown}
          onChange={(event) => onChange(event.target.value)}
          onSelect={(event) => setCursor(event.currentTarget.selectionStart)}
          onClick={(event) => setCursor(event.currentTarget.selectionStart)}
          className="editor-code absolute inset-0 resize-none overflow-auto bg-transparent p-4 font-mono text-base leading-relaxed text-transparent caret-accent selection:bg-accent/30"
        />
      </div>
    </div>
  );
}
