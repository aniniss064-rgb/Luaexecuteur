interface FengariState {
  LUA_OK: number;
  LUA_MULTRET: number;
  LUA_MASKCOUNT: number;
  luaL_newstate: () => unknown;
  luaL_requiref: (L: unknown, name: Uint8Array, opener: unknown, global: number) => void;
  luaL_loadbufferx: (
    L: unknown,
    code: Uint8Array,
    size: number | null,
    name: Uint8Array,
    mode: Uint8Array,
  ) => number;
  luaL_tolstring: (L: unknown, index: number, len: null) => Uint8Array;
  luaL_error: (L: unknown, message: Uint8Array) => never;
  luaopen_base: (L: unknown) => number;
  luaopen_coroutine: (L: unknown) => number;
  luaopen_table: (L: unknown) => number;
  luaopen_string: (L: unknown) => number;
  luaopen_utf8: (L: unknown) => number;
  luaopen_math: (L: unknown) => number;
  lua_pop: (L: unknown, n: number) => void;
  lua_pushjsfunction: (L: unknown, fn: (L: unknown) => number) => void;
  lua_pushnil: (L: unknown) => void;
  lua_setglobal: (L: unknown, name: Uint8Array) => void;
  lua_sethook: (L: unknown, hook: (L: unknown) => void, mask: number, count: number) => void;
  lua_pcall: (L: unknown, nargs: number, nresults: number, errfunc: number) => number;
  lua_gettop: (L: unknown) => number;
  lua_settop: (L: unknown, index: number) => void;
  lua_tolstring: (L: unknown, index: number) => Uint8Array;
}

declare module "fengari-web" {
  const fengari: {
    lua: FengariState;
    lauxlib: FengariState;
    lualib: FengariState;
    to_luastring: (value: string) => Uint8Array;
    to_jsstring: (value: Uint8Array) => string;
  };
  export default fengari;
}
