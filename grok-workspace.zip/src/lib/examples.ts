export type Example = {
  name: string;
  blurb: string;
  code: string;
};

export const STARTER = `-- Lua 5.3, exécuté dans la page.
-- Ctrl + Entrée pour lancer.

print("Salut")

local function fib(n)
  if n < 2 then return n end
  return fib(n - 1) + fib(n - 2)
end

for i = 0, 12 do
  print(i, fib(i))
end

return "terminé"
`;

export const EXAMPLES: Example[] = [
  {
    name: "Découverte",
    blurb: "Variables, boucle, print",
    code: `local nom = "Niniss"
local annee = 2026

print("bonjour", nom)
print(string.format("%s · %d", nom, annee))

for i = 1, 5 do
  print(string.rep("·", i), i * i)
end
`,
  },
  {
    name: "Tables",
    blurb: "Listes, clés, tri",
    code: `local notes = { ada = 18, linus = 15, grace = 20 }

local function moyenne(map)
  local total, n = 0, 0
  for _, note in pairs(map) do
    total = total + note
    n = n + 1
  end
  return total / n
end

print("moyenne", moyenne(notes))

local noms = {}
for nom in pairs(notes) do
  table.insert(noms, nom)
end
table.sort(noms)
for _, nom in ipairs(noms) do
  print(nom, notes[nom])
end
`,
  },
  {
    name: "Fonctions",
    blurb: "Retour multiple, fermeture",
    code: `local function divmod(a, b)
  return math.floor(a / b), a % b
end

local q, r = divmod(17, 5)
print("17 =", q, "* 5 +", r)

local function compteur()
  local n = 0
  return function()
    n = n + 1
    return n
  end
end

local suivant = compteur()
print(suivant(), suivant(), suivant())
`,
  },
  {
    name: "Coroutines",
    blurb: "yield et reprise",
    code: `local function ping()
  for i = 1, 3 do
    coroutine.yield("ping " .. i)
  end
  return "fini"
end

local co = coroutine.create(ping)
while coroutine.status(co) ~= "dead" do
  local ok, value = coroutine.resume(co)
  print(coroutine.status(co), ok, value)
end
`,
  },
  {
    name: "Texte",
    blurb: "Motifs et utf8",
    code: `local phrase = "lua exécute, lua affiche"
local n = 0
for _ in string.gmatch(phrase, "lua") do
  n = n + 1
end
print("occurrences", n)
print("longueur utf8", utf8.len("exécution"))
print(string.upper("acide citron"))
`,
  },
];
