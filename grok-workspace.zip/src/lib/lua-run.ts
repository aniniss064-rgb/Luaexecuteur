import fengari from "fengari-web";

const { lauxlib, lua, lualib, to_jsstring, to_luastring } = fengari;

export type LineKind = "out" | "err" | "ret" | "meta";

export type LuaLine = {
  kind: LineKind;
  text: string;
};

const TIMEOUT_MS = 1500;
const MAX_LINES = 400;
const MAX_CHARS = 2000;

const LIBS: [string, (L: unknown) => number][] = [
  ["_G", lualib.luaopen_base],
  ["coroutine", lualib.luaopen_coroutine],
  ["table", lualib.luaopen_table],
  ["string", lualib.luaopen_string],
  ["utf8", lualib.luaopen_utf8],
  ["math", lualib.luaopen_math],
];

function clip(text: string): string {
  if (text.length <= MAX_CHARS) return text;
  return `${text.slice(0, MAX_CHARS)}…`;
}

function prettyError(message: string): string {
  const matched = message.match(/^(?:script:)?(\d+):\s*([\s\S]*)$/);
  if (!matched) return message;
  return `ligne ${matched[1]} — ${matched[2]}`;
}

function readString(L: unknown, index: number): string {
  lauxlib.luaL_tolstring(L, index, null);
  const value = to_jsstring(lua.lua_tolstring(L, -1));
  lua.lua_pop(L, 1);
  return value;
}

function loadChunk(L: unknown, source: string): string | null {
  const status = lauxlib.luaL_loadbufferx(
    L,
    to_luastring(source),
    null,
    to_luastring("@script"),
    to_luastring("t"),
  );
  if (status === lua.LUA_OK) return null;
  const message = to_jsstring(lua.lua_tolstring(L, -1));
  lua.lua_pop(L, 1);
  return message;
}

function execute(code: string): LuaLine[] {
  const lines: LuaLine[] = [];
  const L = lauxlib.luaL_newstate();

  for (const [name, opener] of LIBS) {
    lauxlib.luaL_requiref(L, to_luastring(name), opener, 1);
    lua.lua_pop(L, 1);
  }

  for (const banned of ["dofile", "loadfile"]) {
    lua.lua_pushnil(L);
    lua.lua_setglobal(L, to_luastring(banned));
  }

  lua.lua_pushjsfunction(L, (state) => {
    if (lines.length >= MAX_LINES) {
      lauxlib.luaL_error(state, to_luastring(`sortie coupée à ${MAX_LINES} lignes`));
    }
    const count = lua.lua_gettop(state);
    const parts: string[] = [];
    for (let index = 1; index <= count; index += 1) {
      parts.push(readString(state, index));
    }
    lines.push({ kind: "out", text: clip(parts.join("\t")) });
    return 0;
  });
  lua.lua_setglobal(L, to_luastring("print"));

  const started = Date.now();
  lua.lua_sethook(
    L,
    (state) => {
      if (Date.now() - started > TIMEOUT_MS) {
        lauxlib.luaL_error(state, to_luastring("temps dépassé (1,5 s)"));
      }
    },
    lua.LUA_MASKCOUNT,
    2000,
  );

  let error = loadChunk(L, code);
  if (error) {
    const fallback = loadChunk(L, `return ${code}`);
    if (fallback) return [{ kind: "err", text: prettyError(error) }];
  }

  const status = lua.lua_pcall(L, 0, lua.LUA_MULTRET, 0);
  if (status !== lua.LUA_OK) {
    lines.push({ kind: "err", text: prettyError(to_jsstring(lua.lua_tolstring(L, -1))) });
    return lines;
  }

  const returns = lua.lua_gettop(L);
  if (returns > 0) {
    const parts: string[] = [];
    for (let index = 1; index <= returns; index += 1) {
      parts.push(readString(L, index));
    }
    lines.push({ kind: "ret", text: clip(parts.join("\t")) });
  }

  if (lines.length === 0) {
    lines.push({ kind: "meta", text: "terminé, rien à afficher" });
  }
  return lines;
}

export function runLua(code: string): { lines: LuaLine[]; ms: number } {
  const started = Date.now();
  if (!code.trim()) {
    return {
      lines: [{ kind: "meta", text: "Le script est vide." }],
      ms: 0,
    };
  }
  try {
    return { lines: execute(code), ms: Date.now() - started };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return {
      lines: [{ kind: "err", text: message }],
      ms: Date.now() - started,
    };
  }
}
