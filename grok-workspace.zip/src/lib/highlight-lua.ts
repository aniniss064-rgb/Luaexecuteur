export type TokenKind = "plain" | "kw" | "str" | "cmt" | "num" | "fn";

export type Token = {
  text: string;
  kind: TokenKind;
};

const KEYWORDS = new Set([
  "and",
  "break",
  "do",
  "else",
  "elseif",
  "end",
  "false",
  "for",
  "function",
  "goto",
  "if",
  "in",
  "local",
  "nil",
  "not",
  "or",
  "repeat",
  "return",
  "then",
  "true",
  "until",
  "while",
]);

const BUILTINS = new Set([
  "assert",
  "collectgarbage",
  "error",
  "getmetatable",
  "ipairs",
  "next",
  "pairs",
  "pcall",
  "print",
  "rawequal",
  "rawget",
  "rawlen",
  "rawset",
  "select",
  "setmetatable",
  "tonumber",
  "tostring",
  "type",
  "xpcall",
  "math",
  "string",
  "table",
  "coroutine",
  "utf8",
]);

function push(tokens: Token[], text: string, kind: TokenKind) {
  if (!text) return;
  const last = tokens[tokens.length - 1];
  if (last && last.kind === kind) last.text += text;
  else tokens.push({ text, kind });
}

export function highlightLua(code: string): Token[] {
  const tokens: Token[] = [];
  const length = code.length;
  let index = 0;

  while (index < length) {
    if (code.startsWith("--", index)) {
      if (code.startsWith("--[[", index)) {
        const end = code.indexOf("]]", index + 4);
        const next = end === -1 ? length : end + 2;
        push(tokens, code.slice(index, next), "cmt");
        index = next;
        continue;
      }
      const end = code.indexOf("\n", index);
      const next = end === -1 ? length : end;
      push(tokens, code.slice(index, next), "cmt");
      index = next;
      continue;
    }

    if (code.startsWith("[[", index) || code.startsWith("[", index)) {
      const fence = code.startsWith("[[", index) ? "]]" : null;
      if (fence) {
        const end = code.indexOf(fence, index + 2);
        const next = end === -1 ? length : end + fence.length;
        push(tokens, code.slice(index, next), "str");
        index = next;
        continue;
      }
    }

    const char = code[index] ?? "";
    if (char === '"' || char === "'") {
      let next = index + 1;
      while (next < length) {
        if (code[next] === "\\") {
          next += 2;
          continue;
        }
        if (code[next] === char || code[next] === "\n") {
          if (code[next] === char) next += 1;
          break;
        }
        next += 1;
      }
      push(tokens, code.slice(index, next), "str");
      index = next;
      continue;
    }

    if (/[0-9]/.test(char) || (char === "." && /[0-9]/.test(code[index + 1] ?? ""))) {
      let next = index + 1;
      while (next < length && /[0-9a-fA-FxX.]/.test(code[next] ?? "")) next += 1;
      push(tokens, code.slice(index, next), "num");
      index = next;
      continue;
    }

    if (/[A-Za-z_]/.test(char)) {
      let next = index + 1;
      while (next < length && /[A-Za-z0-9_]/.test(code[next] ?? "")) next += 1;
      const word = code.slice(index, next);
      const kind: TokenKind = KEYWORDS.has(word) ? "kw" : BUILTINS.has(word) ? "fn" : "plain";
      push(tokens, word, kind);
      index = next;
      continue;
    }

    push(tokens, char, "plain");
    index += 1;
  }

  return tokens;
}
