import { createFileRoute } from "@tanstack/react-router";
import { Executor } from "@/components/executor";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Executor />;
}
